package main

import (
	"fmt"
	"os"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/deployrecap"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "usage: deployfailure <phase> <phase-log>")
		os.Exit(2)
	}

	phase := os.Args[1]
	logPath := os.Args[2]

	logFile, err := os.Open(logPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "open phase log: %v\n", err)
		os.Exit(1)
	}
	defer logFile.Close()

	summary, err := deployrecap.ParseFailure(phase, logFile)
	if err != nil {
		fmt.Fprintf(os.Stderr, "summarize failure recap: %v\n", err)
		os.Exit(1)
	}

	fmt.Println(summary.String())
}

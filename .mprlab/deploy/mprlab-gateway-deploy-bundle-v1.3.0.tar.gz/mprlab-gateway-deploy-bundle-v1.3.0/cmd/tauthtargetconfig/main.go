// Command tauthtargetconfig renders one selected TAuth tenant closure for
// local analysis or merges it into a complete deployed registry.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/tauthconfig"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
)

const (
	commandName        = "tauthtargetconfig"
	errorPrefix        = "ERROR: "
	flagBase           = "base"
	flagDispatchTarget = "dispatch-target"
	flagExisting       = "existing"
	flagOutput         = "output"
	flagRepoParent     = "repo-parent"
)

var errInvalidArguments = errors.New("invalid_arguments")

type commandInputs struct {
	basePath       string
	dispatchTarget string
	existingPath   string
	outputPath     string
	repoParents    []string
}

func run(arguments []string, stdout io.Writer, stderr io.Writer) int {
	command := newRootCommand(stdout, stderr)
	command.SetArgs(arguments)
	executeErr := command.Execute()
	if executeErr == nil || errors.Is(executeErr, pflag.ErrHelp) {
		return 0
	}
	_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, executeErr)
	if errors.Is(executeErr, errInvalidArguments) {
		return 2
	}
	return 1
}

func newRootCommand(stdout io.Writer, stderr io.Writer) *cobra.Command {
	command := &cobra.Command{
		Use:           commandName,
		SilenceUsage:  true,
		SilenceErrors: true,
		Args:          rejectArguments,
		RunE: func(_ *cobra.Command, _ []string) error {
			return fmt.Errorf("%w: select render-selected or merge-deployed", errInvalidArguments)
		},
	}
	command.SetOut(stdout)
	command.SetErr(stderr)
	command.SetFlagErrorFunc(func(_ *cobra.Command, flagErr error) error {
		return fmt.Errorf("%w: %v", errInvalidArguments, flagErr)
	})
	command.AddCommand(
		newRenderSelectedCommand(stdout, stderr),
		newMergeDeployedCommand(stdout, stderr),
	)
	return command
}

func newRenderSelectedCommand(stdout io.Writer, stderr io.Writer) *cobra.Command {
	var inputs commandInputs
	command := &cobra.Command{
		Use:           "render-selected",
		SilenceUsage:  true,
		SilenceErrors: true,
		Args:          rejectArguments,
		RunE: func(command *cobra.Command, _ []string) error {
			tenantCount, renderErr := tauthconfig.RenderSelected(
				command.Context(),
				inputs.repoParents,
				inputs.dispatchTarget,
				inputs.basePath,
				inputs.outputPath,
			)
			if renderErr != nil {
				return renderErr
			}
			_, _ = fmt.Fprintf(stdout, "rendered selected TAuth config with %d tenants\n", tenantCount)
			return nil
		},
	}
	addCommonFlags(command, &inputs)
	return command
}

func newMergeDeployedCommand(stdout io.Writer, stderr io.Writer) *cobra.Command {
	var inputs commandInputs
	command := &cobra.Command{
		Use:           "merge-deployed",
		SilenceUsage:  true,
		SilenceErrors: true,
		Args:          rejectArguments,
		RunE: func(command *cobra.Command, _ []string) error {
			tenantCount, mergeErr := tauthconfig.MergeDeployed(
				command.Context(),
				inputs.repoParents,
				inputs.dispatchTarget,
				inputs.basePath,
				inputs.existingPath,
				inputs.outputPath,
			)
			if mergeErr != nil {
				return mergeErr
			}
			_, _ = fmt.Fprintf(stdout, "merged deployed TAuth config with %d tenants\n", tenantCount)
			return nil
		},
	}
	addCommonFlags(command, &inputs)
	command.Flags().StringVar(
		&inputs.existingPath,
		flagExisting,
		"",
		"Complete deployed TAuth config to preserve outside the selected tenant closure",
	)
	return command
}

func addCommonFlags(command *cobra.Command, inputs *commandInputs) {
	var repoParent string
	command.Flags().StringVar(
		&repoParent,
		flagRepoParent,
		"",
		"OS path list of parent directories containing canonical app repositories",
	)
	command.Flags().StringVar(
		&inputs.dispatchTarget,
		flagDispatchTarget,
		"",
		"Canonical selected app dispatch target",
	)
	command.Flags().StringVar(
		&inputs.basePath,
		flagBase,
		"",
		"Gateway-owned neutral TAuth server base config",
	)
	command.Flags().StringVar(
		&inputs.outputPath,
		flagOutput,
		"",
		"Output path for the assembled target registry",
	)
	command.PreRunE = func(_ *cobra.Command, _ []string) error {
		inputs.repoParents = filepath.SplitList(repoParent)
		return validateInputs(inputs, inputs.existingPath != "")
	}
}

func rejectArguments(_ *cobra.Command, arguments []string) error {
	if len(arguments) == 0 {
		return nil
	}
	return fmt.Errorf("%w: %s accepts no positional arguments", errInvalidArguments, commandName)
}

func validateInputs(inputs *commandInputs, existingRequired bool) error {
	for _, field := range []struct {
		name  string
		value string
	}{
		{name: flagDispatchTarget, value: inputs.dispatchTarget},
		{name: flagBase, value: inputs.basePath},
		{name: flagOutput, value: inputs.outputPath},
	} {
		if field.value == "" || field.value != strings.TrimSpace(field.value) {
			return fmt.Errorf("%w: --%s must be one canonical non-empty value", errInvalidArguments, field.name)
		}
	}
	if len(inputs.repoParents) == 0 {
		return fmt.Errorf("%w: --%s must be one canonical non-empty path list", errInvalidArguments, flagRepoParent)
	}
	for _, repoParent := range inputs.repoParents {
		if repoParent == "" || repoParent != strings.TrimSpace(repoParent) {
			return fmt.Errorf("%w: --%s must be one canonical non-empty path list", errInvalidArguments, flagRepoParent)
		}
	}
	if existingRequired && (inputs.existingPath == "" || inputs.existingPath != strings.TrimSpace(inputs.existingPath)) {
		return fmt.Errorf("%w: --%s must be one canonical non-empty path", errInvalidArguments, flagExisting)
	}
	return nil
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

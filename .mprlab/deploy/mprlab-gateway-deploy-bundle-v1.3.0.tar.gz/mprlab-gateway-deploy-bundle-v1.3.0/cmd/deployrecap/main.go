package main

import (
	"fmt"
	"os"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/deployrecap"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: deployrecap <deploy-log>")
		os.Exit(2)
	}

	logFile, err := os.Open(os.Args[1])
	if err != nil {
		fmt.Fprintf(os.Stderr, "open deploy log: %v\n", err)
		os.Exit(1)
	}
	defer logFile.Close()

	summary, err := deployrecap.Parse(logFile)
	if err != nil {
		fmt.Fprintf(os.Stderr, "summarize deploy log: %v\n", err)
		os.Exit(1)
	}

	fmt.Println(summary.String())
}

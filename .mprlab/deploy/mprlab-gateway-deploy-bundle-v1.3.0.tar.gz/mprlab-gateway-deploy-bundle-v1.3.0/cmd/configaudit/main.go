// Command configaudit validates gateway-owned Docker Compose boundaries.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"sort"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/configaudit"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const (
	commandName                   = "configaudit"
	configauditEnvPrefix          = "CONFIGAUDIT"
	errorPrefix                   = "ERROR: "
	flagComposeFile               = "compose-file"
	flagService                   = "service"
	flagWriteSelectedCompose      = "write-selected-compose"
	messageConfigAuditFailed      = "config-audit failed\n"
	messageConfigAuditOK          = "config-audit OK\n"
	messageComposeFileDefault     = "docker-compose.yml"
	messageComposeFileDescription = "Path to the gateway-owned Docker Compose file"
)

var errInvalidArguments = errors.New("invalid_arguments")
var errConfigAuditFailed = errors.New("config_audit_failed")

type configAuditInputs struct {
	composeFile          string
	services             []string
	writeSelectedCompose string
}

func run(arguments []string, stdout io.Writer, stderr io.Writer) int {
	command, commandErr := newRootCommand(stdout, stderr)
	if commandErr != nil {
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, commandErr)
		return 1
	}
	command.SetArgs(arguments)
	executeErr := command.Execute()
	if executeErr == nil || errors.Is(executeErr, pflag.ErrHelp) {
		return 0
	}
	if errors.Is(executeErr, errInvalidArguments) {
		return 2
	}
	return 1
}

func newRootCommand(stdout io.Writer, stderr io.Writer) (*cobra.Command, error) {
	var validatedInputs configAuditInputs
	command := &cobra.Command{
		Use:           commandName,
		SilenceUsage:  true,
		SilenceErrors: true,
		Args: func(_ *cobra.Command, arguments []string) error {
			if len(arguments) == 0 {
				return nil
			}
			_, _ = fmt.Fprintf(stderr, "%s%s accepts no positional arguments\n", errorPrefix, commandName)
			return errInvalidArguments
		},
		PreRunE: func(command *cobra.Command, _ []string) error {
			resolvedInputs, inputErr := readConfigAuditInputs(command)
			if inputErr != nil {
				_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, inputErr)
				return errInvalidArguments
			}
			validatedInputs = resolvedInputs
			return nil
		},
		RunE: func(_ *cobra.Command, _ []string) error {
			return runConfigAudit(validatedInputs, stdout, stderr)
		},
	}
	command.SetOut(stdout)
	command.SetErr(stderr)
	command.SetFlagErrorFunc(func(_ *cobra.Command, flagErr error) error {
		if errors.Is(flagErr, pflag.ErrHelp) {
			return flagErr
		}
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, flagErr)
		return errInvalidArguments
	})
	command.Flags().String(flagComposeFile, messageComposeFileDefault, messageComposeFileDescription)
	command.Flags().StringArray(flagService, nil, "Gateway Compose service to audit; repeat for the complete target closure")
	command.Flags().String(flagWriteSelectedCompose, "", "Canonical staged Compose output for the selected service closure")
	viper.Reset()
	viper.SetEnvPrefix(configauditEnvPrefix)
	viper.SetEnvKeyReplacer(strings.NewReplacer("-", "_"))
	viper.AutomaticEnv()
	if err := viper.BindPFlag(flagComposeFile, command.Flags().Lookup(flagComposeFile)); err != nil {
		return nil, fmt.Errorf("bind %s input: %w", flagComposeFile, err)
	}
	if err := viper.BindPFlag(flagWriteSelectedCompose, command.Flags().Lookup(flagWriteSelectedCompose)); err != nil {
		return nil, fmt.Errorf("bind %s input: %w", flagWriteSelectedCompose, err)
	}
	return command, nil
}

func readConfigAuditInputs(command *cobra.Command) (configAuditInputs, error) {
	if command == nil {
		return configAuditInputs{}, errors.New("command is required")
	}
	composeFile := viper.GetString(flagComposeFile)
	if composeFile == "" || composeFile != strings.TrimSpace(composeFile) {
		return configAuditInputs{}, errors.New("compose file must be one non-empty canonical string")
	}
	services, err := command.Flags().GetStringArray(flagService)
	if err != nil {
		return configAuditInputs{}, fmt.Errorf("read selected services: %w", err)
	}
	writeSelectedCompose := viper.GetString(flagWriteSelectedCompose)
	if writeSelectedCompose != "" && len(services) == 0 {
		return configAuditInputs{}, errors.New("selected Compose output requires at least one selected service")
	}
	return configAuditInputs{
		composeFile:          composeFile,
		services:             services,
		writeSelectedCompose: writeSelectedCompose,
	}, nil
}

func runConfigAudit(inputs configAuditInputs, stdout io.Writer, stderr io.Writer) error {
	var result configaudit.Result
	if inputs.writeSelectedCompose != "" {
		result = configaudit.WriteSelectedCompose(inputs.composeFile, inputs.services, inputs.writeSelectedCompose)
	} else {
		result = configaudit.Run(inputs.composeFile, inputs.services)
	}
	sort.Strings(result.Errors)
	for _, errorMessage := range result.Errors {
		_, _ = fmt.Fprintf(stderr, "ERROR: %s\n", errorMessage)
	}
	if len(result.Errors) > 0 {
		_, _ = fmt.Fprint(stderr, messageConfigAuditFailed)
		return errConfigAuditFailed
	}
	_, _ = fmt.Fprint(stdout, messageConfigAuditOK)
	return nil
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

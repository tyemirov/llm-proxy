package main

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestRunReportsGatewayComposeSuccess(t *testing.T) {
	composePath := writeCommandFixture(t, `
services:
  api:
    image: example.invalid/api:latest
`)
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run([]string{"--compose-file", composePath}, &stdout, &stderr)
	if exitCode != 0 || stdout.String() != "config-audit OK\n" || stderr.Len() != 0 {
		t.Fatalf("unexpected success result code=%d stdout=%q stderr=%q", exitCode, stdout.String(), stderr.String())
	}
}

func TestRunAcceptsComposePathFromEnvironment(t *testing.T) {
	composePath := writeCommandFixture(t, `
services:
  api:
    image: example.invalid/api:latest
`)
	t.Setenv("CONFIGAUDIT_COMPOSE_FILE", composePath)
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run(nil, &stdout, &stderr)
	if exitCode != 0 || stdout.String() != "config-audit OK\n" || stderr.Len() != 0 {
		t.Fatalf("unexpected environment input result code=%d stdout=%q stderr=%q", exitCode, stdout.String(), stderr.String())
	}
}

func TestRunAuditsOnlySelectedServiceClosure(t *testing.T) {
	composePath := writeCommandFixture(t, `
services:
  api:
    image: example.invalid/api:latest
  unrelated:
    image: example.invalid/unrelated:latest
    env_file:
      - ./configs/.env.missing
`)
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run([]string{"--compose-file", composePath, "--service", "api"}, &stdout, &stderr)
	if exitCode != 0 || stdout.String() != "config-audit OK\n" || stderr.Len() != 0 {
		t.Fatalf("unexpected selected-service result code=%d stdout=%q stderr=%q", exitCode, stdout.String(), stderr.String())
	}
}

func TestRunRejectsIncompleteSelectedServiceClosure(t *testing.T) {
	composePath := writeCommandFixture(t, `
services:
  api:
    image: example.invalid/api:latest
    depends_on:
      - database
  database:
    image: example.invalid/database:latest
`)
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run([]string{"--compose-file", composePath, "--service", "api"}, &stdout, &stderr)
	if exitCode != 1 || !strings.Contains(stderr.String(), "selected service api depends on unselected service database") {
		t.Fatalf("expected incomplete selected-service closure failure, got code=%d stdout=%q stderr=%q", exitCode, stdout.String(), stderr.String())
	}
}

func TestRunReportsGatewayComposeFailure(t *testing.T) {
	testCases := []struct {
		name     string
		compose  string
		expected string
	}{
		{
			name: "dangling dependency",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    depends_on:
      - missing
`,
			expected: "depends on unknown service missing",
		},
		{
			name: "missing environment",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    env_file:
      - ./configs/.env.missing
`,
			expected: "environment file is missing",
		},
		{
			name: "missing bind source",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    volumes:
      - ./configs/missing.yml:/app/config.yml:ro
`,
			expected: "bind source is missing",
		},
		{
			name: "build source",
			compose: `
services:
  api:
    build: .
`,
			expected: "must declare one image and no build",
		},
		{
			name: "application tls listener",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    expose:
      - "443"
`,
			expected: "must not own TLS listener port 443",
		},
		{
			name: "application published tls listener",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    ports:
      - "465:8080"
`,
			expected: "must not publish Caddy TLS listener port 465",
		},
		{
			name: "undeclared volume",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    volumes:
      - app-data:/data
`,
			expected: "uses undeclared named volume app-data",
		},
		{
			name: "absolute environment path",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    env_file:
      - /tmp/runtime.env
`,
			expected: "must be one canonical ./-relative path",
		},
		{
			name: "scalar environment input",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    env_file: ./configs/.env.api
`,
			expected: "value must be one scalar list",
		},
		{
			name: "application caddy storage",
			compose: `
services:
  api:
    image: example.invalid/api:latest
    volumes:
      - caddy-data:/data
volumes:
  caddy-data: {}
`,
			expected: "must not mount Caddy-owned storage",
		},
		{
			name: "application derived caddy storage",
			compose: `
services:
  caddy:
    image: example.invalid/caddy:latest
    volumes:
      - edge-state:/data
  api:
    image: example.invalid/api:latest
    volumes:
      - edge-state:/tls
volumes:
  edge-state: {}
`,
			expected: "must not mount Caddy-owned storage edge-state:/tls",
		},
	}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			composePath := writeCommandFixture(t, testCase.compose)
			var stdout bytes.Buffer
			var stderr bytes.Buffer

			exitCode := run([]string{"--compose-file", composePath}, &stdout, &stderr)
			if exitCode != 1 {
				t.Fatalf("expected audit failure exit 1, got %d", exitCode)
			}
			if !strings.Contains(stderr.String(), testCase.expected) || !strings.HasSuffix(stderr.String(), "config-audit failed\n") {
				t.Fatalf("expected actionable audit failure containing %q, got stdout=%q stderr=%q", testCase.expected, stdout.String(), stderr.String())
			}
		})
	}
}

func TestRunRejectsSymlinkedComposeInput(t *testing.T) {
	root := t.TempDir()
	targetPath := filepath.Join(root, "compose-target.yml")
	composePath := filepath.Join(root, "docker-compose.yml")
	if err := os.WriteFile(targetPath, []byte("services:\n  api:\n    image: example.invalid/api:latest\n"), 0o644); err != nil {
		t.Fatalf("write compose target: %v", err)
	}
	if err := os.Symlink(targetPath, composePath); err != nil {
		t.Fatalf("symlink compose: %v", err)
	}
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run([]string{"--compose-file", composePath}, &stdout, &stderr)
	if exitCode != 1 || !strings.Contains(stderr.String(), "must be a regular non-symlink file") {
		t.Fatalf("expected symlink rejection, got code=%d stdout=%q stderr=%q", exitCode, stdout.String(), stderr.String())
	}
}

func TestRunRejectsRemovedProductAuditFlags(t *testing.T) {
	for _, arguments := range [][]string{
		{"--autofix"},
		{"--graph", "json"},
		{"--tauth-cors-host-exceptions", "example.invalid"},
	} {
		var stdout bytes.Buffer
		var stderr bytes.Buffer
		if exitCode := run(arguments, &stdout, &stderr); exitCode != 2 {
			t.Fatalf("expected removed flag %v to return 2, got %d stdout=%q stderr=%q", arguments, exitCode, stdout.String(), stderr.String())
		}
		if !strings.Contains(stderr.String(), "unknown flag") {
			t.Fatalf("expected removed flag %v to be unknown, got %q", arguments, stderr.String())
		}
	}
}

func TestRunRejectsPositionalArguments(t *testing.T) {
	var stdout bytes.Buffer
	var stderr bytes.Buffer

	exitCode := run([]string{"docker-compose.yml"}, &stdout, &stderr)
	if exitCode != 2 {
		t.Fatalf("expected positional argument failure exit 2, got %d", exitCode)
	}
	if stdout.Len() != 0 || !strings.Contains(stderr.String(), "accepts no positional arguments") {
		t.Fatalf("expected actionable positional argument failure, got stdout=%q stderr=%q", stdout.String(), stderr.String())
	}
}

func writeCommandFixture(t *testing.T, compose string) string {
	t.Helper()
	composePath := filepath.Join(t.TempDir(), "docker-compose.yml")
	if err := os.WriteFile(composePath, []byte(compose), 0o644); err != nil {
		t.Fatalf("write compose fixture: %v", err)
	}
	return composePath
}

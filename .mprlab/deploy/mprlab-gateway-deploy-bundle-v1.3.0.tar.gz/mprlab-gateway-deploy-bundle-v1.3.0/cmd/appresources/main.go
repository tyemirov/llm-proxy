// Command appresources emits the canonical committed app deployment inventory.
package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/appresources"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const (
	commandName                  = "appresources"
	configKeyRepoParent          = "repo-parent"
	environmentPrefix            = "APPRESOURCES"
	errorPrefix                  = "ERROR: "
	flagDispatchTarget           = "dispatch-target"
	flagRepoParent               = "repo-parent"
	flagSelectedOnly             = "selected-only"
	flagServiceName              = "service-name"
	messageDispatchTarget        = "Canonical app dispatch target to include; repeat for multiple targets"
	messageRepoParentDescription = "OS path list of parent directories containing app repositories"
	messageRepoParentRequired    = "app repository parent is required"
	messageSelectedOnly          = "Return only selected dispatch targets and container service owners"
	messageServiceName           = "Container service whose owning repository must be included; repeat for multiple services"
)

var errInvalidArguments = errors.New("invalid_arguments")

func run(arguments []string, stdout io.Writer, stderr io.Writer) int {
	command, commandErr := newRootCommand(stdout, stderr)
	if commandErr != nil {
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, commandErr)
		return 1
	}
	command.SetArgs(arguments)
	executeErr := command.Execute()
	if executeErr == nil || errors.Is(executeErr, pflag.ErrHelp) {
		return 0
	}
	if errors.Is(executeErr, errInvalidArguments) {
		return 2
	}
	return 1
}

func newRootCommand(stdout io.Writer, stderr io.Writer) (*cobra.Command, error) {
	if configureErr := configureViper(); configureErr != nil {
		return nil, configureErr
	}
	var repoParents []string
	var dispatchTargets []string
	var serviceNames []string
	var selectedOnly bool
	command := &cobra.Command{
		Use:           commandName,
		SilenceUsage:  true,
		SilenceErrors: true,
		Args: func(_ *cobra.Command, arguments []string) error {
			if len(arguments) == 0 {
				return nil
			}
			_, _ = fmt.Fprintf(stderr, "%s%s accepts no positional arguments\n", errorPrefix, commandName)
			return errInvalidArguments
		},
		PreRunE: func(command *cobra.Command, _ []string) error {
			repoParentValue, inputErr := readFlagOrConfig(command, flagRepoParent, configKeyRepoParent)
			if inputErr != nil {
				_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, inputErr)
				return errInvalidArguments
			}
			if repoParentValue == "" || repoParentValue != strings.TrimSpace(repoParentValue) {
				_, _ = fmt.Fprintf(stderr, "%s%s\n", errorPrefix, messageRepoParentRequired)
				return errInvalidArguments
			}
			repoParents = filepath.SplitList(repoParentValue)
			return nil
		},
		RunE: func(command *cobra.Command, _ []string) error {
			if selectedOnly || len(dispatchTargets) > 0 || len(serviceNames) > 0 {
				discovery, discoveryErr := appresources.DiscoverSelected(
					command.Context(),
					repoParents,
					dispatchTargets,
					serviceNames,
				)
				return writeDiscovery(stdout, stderr, discovery, discoveryErr)
			}
			discovery, discoveryErr := appresources.Discover(command.Context(), repoParents)
			return writeDiscovery(stdout, stderr, discovery, discoveryErr)
		},
	}
	command.SetOut(stdout)
	command.SetErr(stderr)
	command.SetFlagErrorFunc(func(_ *cobra.Command, flagErr error) error {
		if errors.Is(flagErr, pflag.ErrHelp) {
			return flagErr
		}
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, flagErr)
		return errInvalidArguments
	})
	command.Flags().StringArrayVar(
		&dispatchTargets,
		flagDispatchTarget,
		nil,
		messageDispatchTarget,
	)
	command.Flags().String(flagRepoParent, "", messageRepoParentDescription)
	command.Flags().BoolVar(&selectedOnly, flagSelectedOnly, false, messageSelectedOnly)
	command.Flags().StringArrayVar(
		&serviceNames,
		flagServiceName,
		nil,
		messageServiceName,
	)
	return command, nil
}

func writeDiscovery(
	stdout io.Writer,
	stderr io.Writer,
	discovery any,
	discoveryErr error,
) error {
	if discoveryErr != nil {
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, discoveryErr)
		return discoveryErr
	}
	encoder := json.NewEncoder(stdout)
	encoder.SetEscapeHTML(false)
	if encodeErr := encoder.Encode(discovery); encodeErr != nil {
		return fmt.Errorf("encode app resource discovery: %w", encodeErr)
	}
	return nil
}

func configureViper() error {
	viper.Reset()
	viper.SetEnvPrefix(environmentPrefix)
	viper.SetEnvKeyReplacer(strings.NewReplacer("-", "_"))
	viper.AutomaticEnv()
	if bindErr := viper.BindEnv(configKeyRepoParent); bindErr != nil {
		return fmt.Errorf("bind env %s: %w", configKeyRepoParent, bindErr)
	}
	return nil
}

func readFlagOrConfig(command *cobra.Command, flagName string, configKey string) (string, error) {
	flags := command.Flags()
	if flags != nil && flags.Changed(flagName) {
		return flags.GetString(flagName)
	}
	return viper.GetString(configKey), nil
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

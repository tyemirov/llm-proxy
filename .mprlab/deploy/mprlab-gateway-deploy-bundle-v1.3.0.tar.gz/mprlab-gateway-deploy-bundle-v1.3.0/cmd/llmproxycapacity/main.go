// Command llmproxycapacity prints the committed app-owned LLM Proxy request
// budget capacity for the canonical ready repository.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/appresources"
	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/llmproxycontract"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const (
	commandName                  = "llmproxycapacity"
	configKeyRepositoryParents   = "repository-parents"
	environmentRepositoryParents = "MPRLAB_APP_REPO_PARENTS"
	errorPrefix                  = "ERROR: "
	messageRepositoryRequired    = "app repository parent is required"
)

var errInvalidArguments = errors.New("invalid_arguments")

func run(arguments []string, stdout io.Writer, stderr io.Writer) int {
	command, commandErr := newRootCommand(stdout, stderr)
	if commandErr != nil {
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, commandErr)
		return 1
	}
	command.SetArgs(arguments)
	executeErr := command.Execute()
	if executeErr == nil || errors.Is(executeErr, pflag.ErrHelp) {
		return 0
	}
	_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, executeErr)
	if errors.Is(executeErr, errInvalidArguments) {
		return 2
	}
	return 1
}

func newRootCommand(stdout io.Writer, stderr io.Writer) (*cobra.Command, error) {
	viper.Reset()
	if bindErr := viper.BindEnv(configKeyRepositoryParents, environmentRepositoryParents); bindErr != nil {
		return nil, fmt.Errorf("bind repository parents: %w", bindErr)
	}
	var repositoryParents string
	command := &cobra.Command{
		Use:           commandName,
		SilenceUsage:  true,
		SilenceErrors: true,
		Args: func(_ *cobra.Command, arguments []string) error {
			if len(arguments) == 0 {
				return nil
			}
			return fmt.Errorf("%w: %s accepts no arguments", errInvalidArguments, commandName)
		},
		PreRunE: func(_ *cobra.Command, _ []string) error {
			repositoryParents = viper.GetString(configKeyRepositoryParents)
			if repositoryParents == "" || repositoryParents != strings.TrimSpace(repositoryParents) {
				return fmt.Errorf("%w: %s", errInvalidArguments, messageRepositoryRequired)
			}
			return nil
		},
		RunE: func(command *cobra.Command, _ []string) error {
			discovery, discoveryErr := appresources.DiscoverSelected(
				command.Context(),
				filepath.SplitList(repositoryParents),
				[]string{"llm-proxy"},
				nil,
			)
			if discoveryErr != nil {
				return discoveryErr
			}
			resolution, resolutionErr := llmproxycontract.Resolve(
				command.Context(),
				discovery.RepositorySnapshots(),
			)
			if resolutionErr != nil {
				return resolutionErr
			}
			if !resolution.Ready {
				return fmt.Errorf(
					"llm-proxy repository is not ready: %s",
					strings.Join(resolution.Reasons, "; "),
				)
			}
			_, outputErr := fmt.Fprintln(stdout, resolution.MaximumSeconds)
			return outputErr
		},
	}
	command.SetOut(stdout)
	command.SetErr(stderr)
	command.SetFlagErrorFunc(func(_ *cobra.Command, flagErr error) error {
		if errors.Is(flagErr, pflag.ErrHelp) {
			return flagErr
		}
		return fmt.Errorf("%w: %v", errInvalidArguments, flagErr)
	})
	return command, nil
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

// Command tauthconfig assembles the complete gateway-owned TAuth configuration.
package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/tauthconfig"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

const (
	commandName                  = "tauthconfig"
	configKeyBase                = "base"
	configKeyOutput              = "output"
	configKeyRepoParent          = "repo-parent"
	defaultBasePath              = "configs/config.tauth.base.yml"
	defaultOutputPath            = "configs/config.tauth.yml"
	environmentPrefix            = "TAUTHCONFIG"
	errorPrefix                  = "ERROR: "
	flagBase                     = "base"
	flagOutput                   = "output"
	flagRepoParent               = "repo-parent"
	messageBaseDescription       = "Path to the gateway-owned TAuth server base configuration"
	messageBaseRequired          = "base config path must be one non-empty canonical path"
	messageOutputDescription     = "Path for the assembled complete TAuth configuration"
	messageOutputRequired        = "output config path must be one non-empty canonical path"
	messageRenderedFormat        = "rendered TAuth config with %d tenants\n"
	messageRepoParentDescription = "OS path list of parent directories containing canonical sibling app repositories"
	messageRepoParentRequired    = "app repository parent must be one non-empty canonical OS path list"
)

var errInvalidArguments = errors.New("invalid_arguments")

type commandInputs struct {
	repoParent string
	basePath   string
	outputPath string
}

func run(arguments []string, stdout io.Writer, stderr io.Writer) int {
	command, commandErr := newRootCommand(stdout, stderr)
	if commandErr != nil {
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, commandErr)
		return 1
	}
	command.SetArgs(arguments)
	executeErr := command.Execute()
	if executeErr == nil || errors.Is(executeErr, pflag.ErrHelp) {
		return 0
	}
	if errors.Is(executeErr, errInvalidArguments) {
		return 2
	}
	return 1
}

func newRootCommand(stdout io.Writer, stderr io.Writer) (*cobra.Command, error) {
	if configureErr := configureViper(); configureErr != nil {
		return nil, configureErr
	}
	var validatedInputs commandInputs
	command := &cobra.Command{
		Use:           commandName,
		SilenceUsage:  true,
		SilenceErrors: true,
		Args: func(_ *cobra.Command, arguments []string) error {
			if len(arguments) == 0 {
				return nil
			}
			_, _ = fmt.Fprintf(stderr, "%s%s accepts no positional arguments\n", errorPrefix, commandName)
			return errInvalidArguments
		},
		PreRunE: func(command *cobra.Command, _ []string) error {
			resolvedInputs, inputErr := readInputs(command)
			if inputErr != nil {
				_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, inputErr)
				return errInvalidArguments
			}
			if validationErr := validateInputs(&resolvedInputs); validationErr != nil {
				_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, validationErr)
				return errInvalidArguments
			}
			validatedInputs = resolvedInputs
			return nil
		},
		RunE: func(command *cobra.Command, _ []string) error {
			tenantCount, generateErr := tauthconfig.Generate(
				command.Context(),
				filepath.SplitList(validatedInputs.repoParent),
				validatedInputs.basePath,
				validatedInputs.outputPath,
			)
			if generateErr != nil {
				_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, generateErr)
				return generateErr
			}
			_, _ = fmt.Fprintf(stdout, messageRenderedFormat, tenantCount)
			return nil
		},
	}
	command.SetOut(stdout)
	command.SetErr(stderr)
	command.SetFlagErrorFunc(func(_ *cobra.Command, flagErr error) error {
		if errors.Is(flagErr, pflag.ErrHelp) {
			return flagErr
		}
		_, _ = fmt.Fprintf(stderr, "%s%v\n", errorPrefix, flagErr)
		return errInvalidArguments
	})
	flags := command.Flags()
	flags.String(flagRepoParent, "", messageRepoParentDescription)
	flags.String(flagBase, defaultBasePath, messageBaseDescription)
	flags.String(flagOutput, defaultOutputPath, messageOutputDescription)
	return command, nil
}

func configureViper() error {
	viper.Reset()
	viper.SetEnvPrefix(environmentPrefix)
	viper.SetEnvKeyReplacer(strings.NewReplacer("-", "_"))
	viper.SetDefault(configKeyBase, defaultBasePath)
	viper.SetDefault(configKeyOutput, defaultOutputPath)
	viper.AutomaticEnv()
	for _, configKey := range []string{configKeyRepoParent, configKeyBase, configKeyOutput} {
		if bindErr := viper.BindEnv(configKey); bindErr != nil {
			return fmt.Errorf("bind env %s: %w", configKey, bindErr)
		}
	}
	return nil
}

func readInputs(command *cobra.Command) (commandInputs, error) {
	repoParent, repoParentErr := readFlagOrConfig(command, flagRepoParent, configKeyRepoParent)
	if repoParentErr != nil {
		return commandInputs{}, repoParentErr
	}
	basePath, baseErr := readFlagOrConfig(command, flagBase, configKeyBase)
	if baseErr != nil {
		return commandInputs{}, baseErr
	}
	outputPath, outputErr := readFlagOrConfig(command, flagOutput, configKeyOutput)
	if outputErr != nil {
		return commandInputs{}, outputErr
	}
	return commandInputs{repoParent: repoParent, basePath: basePath, outputPath: outputPath}, nil
}

func readFlagOrConfig(command *cobra.Command, flagName string, configKey string) (string, error) {
	flags := command.Flags()
	if flags != nil && flags.Changed(flagName) {
		return flags.GetString(flagName)
	}
	return viper.GetString(configKey), nil
}

func validateInputs(inputs *commandInputs) error {
	if inputs.repoParent == "" || inputs.repoParent != strings.TrimSpace(inputs.repoParent) {
		return errors.New(messageRepoParentRequired)
	}
	if inputs.basePath == "" || inputs.basePath != strings.TrimSpace(inputs.basePath) {
		return errors.New(messageBaseRequired)
	}
	if inputs.outputPath == "" || inputs.outputPath != strings.TrimSpace(inputs.outputPath) {
		return errors.New(messageOutputRequired)
	}
	return nil
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

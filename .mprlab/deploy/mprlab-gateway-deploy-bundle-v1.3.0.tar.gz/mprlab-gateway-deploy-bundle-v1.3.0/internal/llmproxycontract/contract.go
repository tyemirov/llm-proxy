// Package llmproxycontract resolves the committed LLM Proxy request budget
// capacity owned by the canonical app repository.
package llmproxycontract

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/appresources"
	"gopkg.in/yaml.v3"
)

const (
	repositoryID       = "llm-proxy"
	serviceName        = "llm-proxy"
	configurationPath  = "configs/config.yml"
	capacityReaderPath = "scripts/read-request-timeout-capacity.sh"
	resourceType       = "container_service"
)

var positiveIntegerPattern = regexp.MustCompile(`^[1-9][0-9]*$`)

// Resolution is the immutable request-budget capacity for one discovered
// LLM Proxy repository.
type Resolution struct {
	Ready          bool
	MaximumSeconds int
	Reasons        []string
}

type manifestDocument struct {
	Resources manifestResources `yaml:"mprlab_resources"`
}

type manifestResources struct {
	Items []manifestResource `yaml:"resources"`
}

type manifestResource struct {
	Type          string         `yaml:"type"`
	Name          string         `yaml:"name"`
	RuntimeAssets []runtimeAsset `yaml:"runtime_assets"`
}

type runtimeAsset struct {
	Path string `yaml:"path"`
}

// Resolve reads the one committed configuration declared by the canonical LLM
// Proxy container resource through the app-owned committed capacity reader.
func Resolve(
	ctx context.Context,
	repositories []appresources.RepositorySnapshot,
) (Resolution, error) {
	var selected appresources.RepositorySnapshot
	for _, repository := range repositories {
		if repository.ID() != repositoryID {
			continue
		}
		if selected != nil {
			return Resolution{}, errors.New("multiple canonical llm-proxy repositories discovered")
		}
		selected = repository
	}
	if selected == nil {
		return Resolution{}, errors.New("canonical llm-proxy repository was not discovered")
	}
	if !selected.Ready() {
		return Resolution{
			Ready:   false,
			Reasons: selected.ReadinessReasons(),
		}, nil
	}

	var manifest manifestDocument
	if unmarshalErr := yaml.Unmarshal([]byte(selected.ManifestYAML()), &manifest); unmarshalErr != nil {
		return Resolution{}, fmt.Errorf("parse committed llm-proxy deployment manifest: %w", unmarshalErr)
	}
	configurationDeclarations := 0
	for _, resource := range manifest.Resources.Items {
		if resource.Type != resourceType || resource.Name != serviceName {
			continue
		}
		for _, asset := range resource.RuntimeAssets {
			if asset.Path == configurationPath {
				configurationDeclarations++
			}
		}
	}
	if configurationDeclarations != 1 {
		return Resolution{}, fmt.Errorf(
			"llm-proxy container resource must declare exactly one %s runtime asset, found %d",
			configurationPath,
			configurationDeclarations,
		)
	}

	readerMode, readerModeErr := committedFileMode(ctx, selected, capacityReaderPath)
	if readerModeErr != nil {
		return Resolution{}, readerModeErr
	}
	if readerMode == "" {
		return Resolution{
			Ready:   false,
			Reasons: []string{"LLM Proxy capacity reader is not committed at HEAD: " + capacityReaderPath},
		}, nil
	}
	if readerMode != "100755" {
		return Resolution{
			Ready:   false,
			Reasons: []string{"LLM Proxy capacity reader must be committed executable: " + capacityReaderPath},
		}, nil
	}
	readerBytes, readerErr := committedFile(ctx, selected, capacityReaderPath)
	if readerErr != nil {
		return Resolution{}, readerErr
	}
	readerWorkingPath := filepath.Join(selected.Path(), filepath.FromSlash(capacityReaderPath))
	readerInfo, readerInfoErr := os.Lstat(readerWorkingPath)
	if readerInfoErr != nil || !readerInfo.Mode().IsRegular() || readerInfo.Mode()&os.ModeSymlink != 0 {
		return Resolution{
			Ready:   false,
			Reasons: []string{"LLM Proxy capacity reader is missing or not a regular file: " + capacityReaderPath},
		}, nil
	}
	if readerInfo.Mode().Perm() != 0o755 {
		return Resolution{
			Ready:   false,
			Reasons: []string{"LLM Proxy capacity reader must have mode 0755: " + capacityReaderPath},
		}, nil
	}
	workingReaderBytes, workingReaderErr := os.ReadFile(readerWorkingPath)
	if workingReaderErr != nil {
		return Resolution{}, fmt.Errorf("read llm-proxy capacity reader: %w", workingReaderErr)
	}
	if !bytes.Equal(readerBytes, workingReaderBytes) {
		return Resolution{
			Ready:   false,
			Reasons: []string{"LLM Proxy capacity reader differs from HEAD: " + capacityReaderPath},
		}, nil
	}
	configurationWorkingPath := filepath.Join(selected.Path(), filepath.FromSlash(configurationPath))
	command := exec.CommandContext(ctx, readerWorkingPath, configurationWorkingPath)
	maximumBytes, commandErr := command.Output()
	if commandErr != nil {
		if ctx.Err() != nil {
			return Resolution{}, ctx.Err()
		}
		return Resolution{}, fmt.Errorf("execute committed llm-proxy capacity reader: %w", commandErr)
	}
	maximumText := strings.TrimSpace(string(maximumBytes))
	if !positiveIntegerPattern.MatchString(maximumText) {
		return Resolution{}, errors.New("app-owned LLM Proxy capacity reader returned an invalid positive whole number")
	}
	maximumSeconds, maximumErr := strconv.Atoi(maximumText)
	if maximumErr != nil {
		return Resolution{}, fmt.Errorf("parse app-owned LLM Proxy capacity: %w", maximumErr)
	}
	return Resolution{
		Ready:          true,
		MaximumSeconds: maximumSeconds,
		Reasons:        []string{},
	}, nil
}

func committedFileMode(
	ctx context.Context,
	repository appresources.RepositorySnapshot,
	relativePath string,
) (string, error) {
	command := exec.CommandContext(
		ctx,
		"git",
		"-C",
		repository.Path(),
		"ls-tree",
		repository.HeadCommit(),
		"--",
		relativePath,
	)
	output, commandErr := command.Output()
	if commandErr != nil {
		if ctx.Err() != nil {
			return "", ctx.Err()
		}
		return "", fmt.Errorf("inspect committed llm-proxy %s: %w", relativePath, commandErr)
	}
	fields := strings.Fields(string(output))
	if len(fields) == 0 {
		return "", nil
	}
	if len(fields) != 4 || fields[1] != "blob" {
		return "", fmt.Errorf("invalid committed llm-proxy file identity: %s", relativePath)
	}
	return fields[0], nil
}

func committedFile(
	ctx context.Context,
	repository appresources.RepositorySnapshot,
	relativePath string,
) ([]byte, error) {
	command := exec.CommandContext(
		ctx,
		"git",
		"-C",
		repository.Path(),
		"show",
		repository.HeadCommit()+":"+relativePath,
	)
	contents, commandErr := command.Output()
	if commandErr != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, fmt.Errorf("read committed llm-proxy %s: %w", relativePath, commandErr)
	}
	return contents, nil
}

// Package tauthconfig assembles MPRLab's complete TAuth configuration from gateway-owned inputs.
package tauthconfig

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/MarcoPoloResearchLab/mprlab-gateway/internal/appresources"
	"gopkg.in/yaml.v3"
)

const (
	keyAllowInsecureHTTP           = "allow_insecure_http"
	keyCookieDomain                = "cookie_domain"
	keyCORSAllowedOriginExceptions = "cors_allowed_origin_exceptions"
	keyCORSAllowedOrigins          = "cors_allowed_origins"
	keyDisplayName                 = "display_name"
	keyGoogleWebClientID           = "google_web_client_id"
	keyGoogleNativeClients         = "google_native_clients"
	keyID                          = "id"
	keyJWTSigningKey               = "jwt_signing_key"
	keyNonceTTL                    = "nonce_ttl"
	keyRefreshCookieName           = "refresh_cookie_name"
	keyRefreshTTL                  = "refresh_ttl"
	keyServer                      = "server"
	keySessionCookieName           = "session_cookie_name"
	keySessionTTL                  = "session_ttl"
	keyTenantOrigins               = "tenant_origins"
	keyTenants                     = "tenants"
	keyPlatform                    = "platform"
	keyClientID                    = "client_id"
	keyRedirectURIs                = "redirect_uris"
	keyAppleOAuth                  = "apple_oauth"
	keyEnabled                     = "enabled"
	keyTeamID                      = "team_id"
	keyKeyID                       = "key_id"
	keyPrivateKeyBase64            = "private_key_base64"
	keyRedirectURI                 = "redirect_uri"
	resourceTypeTAuthTenant        = "tauth_tenant"
	messageMissingTAuthTenants     = "no canonical app-owned TAuth tenant resources found"
	messageTenantMustBeMapping     = "TAuth tenant resource must contain a tenant mapping"
	messageTenantOriginScheme      = "TAuth tenant origin must use http or https"
	outputFileMode                 = 0o600
	temporaryFilePattern           = ".tauth-config-*.yml"
)

var tenantIDPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9_-]{1,63}$`)
var environmentPlaceholderPattern = regexp.MustCompile(`^\$\{[A-Z][A-Z0-9_]*\}$`)
var cookieNamePattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$`)
var cookieDomainPattern = regexp.MustCompile(`^\.?[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$`)
var nativePlatformPattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{1,31}$`)

var allowedTenantKeys = stringSet(
	keyID,
	keyDisplayName,
	keyTenantOrigins,
	keyGoogleWebClientID,
	keyGoogleNativeClients,
	keyAppleOAuth,
	keyJWTSigningKey,
	keyCookieDomain,
	keySessionCookieName,
	keyRefreshCookieName,
	keySessionTTL,
	keyRefreshTTL,
	keyNonceTTL,
	keyAllowInsecureHTTP,
)

var allowedNativeGoogleClientKeys = stringSet(keyPlatform, keyClientID, keyRedirectURIs)

var allowedAppleOAuthKeys = stringSet(
	keyEnabled,
	keyClientID,
	keyTeamID,
	keyKeyID,
	keyPrivateKeyBase64,
	keyRedirectURI,
)

var requiredTenantScalarKeys = []string{
	keyID,
	keyDisplayName,
	keyGoogleWebClientID,
	keyJWTSigningKey,
	keyCookieDomain,
	keySessionCookieName,
	keyRefreshCookieName,
	keySessionTTL,
	keyRefreshTTL,
	keyNonceTTL,
	keyAllowInsecureHTTP,
}

type manifestDocument struct {
	Resources manifestResources `yaml:"mprlab_resources"`
}

type manifestResources struct {
	Resources []manifestResource `yaml:"resources"`
}

type manifestResource struct {
	Type   string               `yaml:"type"`
	Name   string               `yaml:"name"`
	Tenant yaml.Node            `yaml:"tenant"`
	Extra  map[string]yaml.Node `yaml:",inline"`
}

type tenantResource struct {
	ID                string
	Origins           []string
	NativeClientIDs   []string
	SessionCookieName string
	RefreshCookieName string
	Node              *yaml.Node
}

// Generate discovers canonical app resources, validates fleet-wide invariants, and writes one atomic config.
func Generate(ctx context.Context, repoParents []string, basePath string, outputPath string) (int, error) {
	discovery, discoveryErr := appresources.Discover(ctx, repoParents)
	if discoveryErr != nil {
		return 0, discoveryErr
	}
	tenantResources, resourceErr := tenantResourcesFromDiscovery(discovery)
	if resourceErr != nil {
		return 0, resourceErr
	}
	return writeTenantResources(basePath, outputPath, tenantResources)
}

// RenderSelected validates and renders only the selected app-owned TAuth tenants.
// The output is suitable for local-only target analysis and is never a complete
// fleet registry.
func RenderSelected(
	ctx context.Context,
	repoParents []string,
	dispatchTarget string,
	basePath string,
	outputPath string,
) (int, error) {
	discovery, discoveryErr := appresources.DiscoverSelected(
		ctx,
		repoParents,
		[]string{dispatchTarget},
		nil,
	)
	if discoveryErr != nil {
		return 0, discoveryErr
	}
	if readinessErr := requireReadyDiscovery(discovery); readinessErr != nil {
		return 0, readinessErr
	}
	tenantResources, resourceErr := tenantResourcesFromDiscovery(discovery)
	if resourceErr != nil {
		return 0, resourceErr
	}
	return writeTenantResources(basePath, outputPath, tenantResources)
}

// MergeDeployed replaces the selected app-owned tenants in one complete
// deployed registry while preserving every unselected tenant exactly.
func MergeDeployed(
	ctx context.Context,
	repoParents []string,
	dispatchTarget string,
	basePath string,
	existingPath string,
	outputPath string,
) (int, error) {
	discovery, discoveryErr := appresources.DiscoverSelected(
		ctx,
		repoParents,
		[]string{dispatchTarget},
		nil,
	)
	if discoveryErr != nil {
		return 0, discoveryErr
	}
	if readinessErr := requireReadyDiscovery(discovery); readinessErr != nil {
		return 0, readinessErr
	}
	selectedResources, selectedErr := tenantResourcesFromDiscovery(discovery)
	if selectedErr != nil {
		return 0, selectedErr
	}
	if selectedValidationErr := validateFleetTenantResources(selectedResources); selectedValidationErr != nil {
		return 0, selectedValidationErr
	}
	existingResources, existingErr := tenantResourcesFromConfig(existingPath)
	if existingErr != nil {
		return 0, existingErr
	}
	if existingValidationErr := validateFleetTenantResources(existingResources); existingValidationErr != nil {
		return 0, fmt.Errorf("deployed TAuth config is invalid: %w", existingValidationErr)
	}

	selectedByID := make(map[string]tenantResource, len(selectedResources))
	for _, selectedResource := range selectedResources {
		selectedByID[selectedResource.ID] = selectedResource
	}
	mergedResources := make([]tenantResource, 0, len(existingResources)+len(selectedResources))
	for _, existingResource := range existingResources {
		selectedResource, replace := selectedByID[existingResource.ID]
		if !replace {
			mergedResources = append(mergedResources, existingResource)
			continue
		}
		mergedResources = append(mergedResources, selectedResource)
		delete(selectedByID, existingResource.ID)
	}
	for _, selectedResource := range selectedResources {
		if _, appendSelected := selectedByID[selectedResource.ID]; appendSelected {
			mergedResources = append(mergedResources, selectedResource)
		}
	}
	return writeTenantResources(basePath, outputPath, mergedResources)
}

func requireReadyDiscovery(discovery interface {
	RepositorySnapshots() []appresources.RepositorySnapshot
}) error {
	for _, repository := range discovery.RepositorySnapshots() {
		if repository.Ready() {
			continue
		}
		return fmt.Errorf(
			"selected app repository %s is not ready: %s",
			repository.ID(),
			strings.Join(repository.ReadinessReasons(), "; "),
		)
	}
	return nil
}

func tenantResourcesFromDiscovery(discovery interface {
	ManifestPaths() []string
	ManifestYAML() map[string]string
}) ([]tenantResource, error) {
	tenantResources := make([]tenantResource, 0)
	manifestYAML := discovery.ManifestYAML()
	for _, manifestPath := range discovery.ManifestPaths() {
		manifest, loadErr := loadManifest(manifestPath, []byte(manifestYAML[manifestPath]))
		if loadErr != nil {
			return nil, loadErr
		}
		manifestTenantResources, resourceErr := tenantResourcesFromManifest(manifestPath, manifest)
		if resourceErr != nil {
			return nil, resourceErr
		}
		tenantResources = append(tenantResources, manifestTenantResources...)
	}
	if len(tenantResources) == 0 {
		return nil, errors.New(messageMissingTAuthTenants)
	}
	return tenantResources, nil
}

func tenantResourcesFromConfig(configPath string) ([]tenantResource, error) {
	fileInfo, statErr := os.Lstat(configPath)
	if statErr != nil {
		return nil, fmt.Errorf("inspect deployed TAuth config %s: %w", configPath, statErr)
	}
	if !fileInfo.Mode().IsRegular() {
		return nil, fmt.Errorf("deployed TAuth config must be a regular file: %s", configPath)
	}
	configBytes, readErr := os.ReadFile(configPath)
	if readErr != nil {
		return nil, fmt.Errorf("read deployed TAuth config %s: %w", configPath, readErr)
	}
	var document yaml.Node
	if unmarshalErr := yaml.Unmarshal(configBytes, &document); unmarshalErr != nil {
		return nil, fmt.Errorf("parse deployed TAuth config %s: %w", configPath, unmarshalErr)
	}
	rootNode, rootErr := documentRootMapping(&document)
	if rootErr != nil {
		return nil, fmt.Errorf("parse deployed TAuth config %s: %w", configPath, rootErr)
	}
	tenantsNode, tenantsPresent := mappingChild(rootNode, keyTenants)
	if !tenantsPresent || tenantsNode.Kind != yaml.SequenceNode || len(tenantsNode.Content) == 0 {
		return nil, fmt.Errorf("deployed TAuth config %s must define a non-empty tenants sequence", configPath)
	}
	tenantResources := make([]tenantResource, 0, len(tenantsNode.Content))
	for tenantIndex, tenantNode := range tenantsNode.Content {
		resourceName := fmt.Sprintf("deployed-tenant-%d", tenantIndex)
		tenant, tenantErr := parseTenantResource(configPath, resourceName, tenantNode)
		if tenantErr != nil {
			return nil, tenantErr
		}
		tenantResources = append(tenantResources, tenant)
	}
	return tenantResources, nil
}

func writeTenantResources(
	basePath string,
	outputPath string,
	tenantResources []tenantResource,
) (int, error) {
	if validationErr := validateFleetTenantResources(tenantResources); validationErr != nil {
		return 0, validationErr
	}
	assembledDocument, assemblyErr := assembleDocument(basePath, tenantResources)
	if assemblyErr != nil {
		return 0, assemblyErr
	}
	if writeErr := writeDocumentAtomically(outputPath, assembledDocument); writeErr != nil {
		return 0, writeErr
	}
	return len(tenantResources), nil
}

func loadManifest(manifestPath string, manifestBytes []byte) (manifestDocument, error) {
	var document manifestDocument
	if unmarshalErr := yaml.Unmarshal(manifestBytes, &document); unmarshalErr != nil {
		return manifestDocument{}, fmt.Errorf("parse app manifest %s: %w", manifestPath, unmarshalErr)
	}
	return document, nil
}

func tenantResourcesFromManifest(manifestPath string, document manifestDocument) ([]tenantResource, error) {
	tenantResources := make([]tenantResource, 0)
	for resourceIndex := range document.Resources.Resources {
		resource := &document.Resources.Resources[resourceIndex]
		if resource.Type != resourceTypeTAuthTenant {
			continue
		}
		if len(resource.Extra) != 0 {
			unsupportedFields := make([]string, 0, len(resource.Extra))
			for field := range resource.Extra {
				unsupportedFields = append(unsupportedFields, field)
			}
			sort.Strings(unsupportedFields)
			return nil, fmt.Errorf("app manifest %s TAuth tenant resource %s has unsupported fields: %s", manifestPath, resource.Name, strings.Join(unsupportedFields, ","))
		}
		tenantResourceValue, tenantErr := parseTenantResource(manifestPath, resource.Name, &resource.Tenant)
		if tenantErr != nil {
			return nil, tenantErr
		}
		tenantResources = append(tenantResources, tenantResourceValue)
	}
	return tenantResources, nil
}

func parseTenantResource(manifestPath string, resourceName string, tenantNode *yaml.Node) (tenantResource, error) {
	if tenantNode.Kind != yaml.MappingNode {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %s", manifestPath, resourceName, messageTenantMustBeMapping)
	}
	if mappingErr := validateMappingKeys(tenantNode, allowedTenantKeys, "TAuth tenant"); mappingErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, mappingErr)
	}
	for _, requiredKey := range requiredTenantScalarKeys {
		if _, scalarErr := requireNonEmptyScalar(tenantNode, requiredKey); scalarErr != nil {
			return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, scalarErr)
		}
	}

	tenantID, _ := requireNonEmptyScalar(tenantNode, keyID)
	if !tenantIDPattern.MatchString(tenantID) {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: TAuth tenant id %q must match %s", manifestPath, resourceName, tenantID, tenantIDPattern.String())
	}
	origins, originsErr := requireTenantOrigins(tenantNode)
	if originsErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, originsErr)
	}
	if placeholderErr := requireEnvironmentPlaceholder(tenantNode, keyGoogleWebClientID); placeholderErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, placeholderErr)
	}
	if placeholderErr := requireEnvironmentPlaceholder(tenantNode, keyJWTSigningKey); placeholderErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, placeholderErr)
	}
	if cookieDomainErr := validateCookieDomain(tenantNode); cookieDomainErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, cookieDomainErr)
	}
	for _, durationKey := range []string{keySessionTTL, keyRefreshTTL, keyNonceTTL} {
		if durationErr := validateDurationField(tenantNode, durationKey); durationErr != nil {
			return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, durationErr)
		}
	}
	if booleanErr := validateBooleanField(tenantNode, keyAllowInsecureHTTP); booleanErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, booleanErr)
	}
	nativeClientIDs, nativeClientsErr := validateNativeGoogleClients(tenantNode)
	if nativeClientsErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, nativeClientsErr)
	}
	if appleOAuthErr := validateAppleOAuth(tenantNode); appleOAuthErr != nil {
		return tenantResource{}, fmt.Errorf("app manifest %s resource %s: %w", manifestPath, resourceName, appleOAuthErr)
	}
	sessionCookieName, _ := requireNonEmptyScalar(tenantNode, keySessionCookieName)
	refreshCookieName, _ := requireNonEmptyScalar(tenantNode, keyRefreshCookieName)
	for cookieField, cookieName := range map[string]string{
		keySessionCookieName: sessionCookieName,
		keyRefreshCookieName: refreshCookieName,
	} {
		if !cookieNamePattern.MatchString(cookieName) {
			return tenantResource{}, fmt.Errorf("app manifest %s resource %s: TAuth tenant field %s must be a valid cookie name", manifestPath, resourceName, cookieField)
		}
	}
	return tenantResource{
		ID:                tenantID,
		Origins:           origins,
		NativeClientIDs:   nativeClientIDs,
		SessionCookieName: sessionCookieName,
		RefreshCookieName: refreshCookieName,
		Node:              cloneNode(tenantNode),
	}, nil
}

func stringSet(values ...string) map[string]struct{} {
	set := make(map[string]struct{}, len(values))
	for _, value := range values {
		set[value] = struct{}{}
	}
	return set
}

func validateMappingKeys(mappingNode *yaml.Node, allowedKeys map[string]struct{}, mappingName string) error {
	seenKeys := make(map[string]struct{}, len(mappingNode.Content)/2)
	for contentIndex := 0; contentIndex < len(mappingNode.Content); contentIndex += 2 {
		keyNode := mappingNode.Content[contentIndex]
		if keyNode.Kind != yaml.ScalarNode || keyNode.Value == "" || keyNode.Value != strings.TrimSpace(keyNode.Value) {
			return fmt.Errorf("%s fields must use non-empty scalar names", mappingName)
		}
		key := keyNode.Value
		if _, allowed := allowedKeys[key]; !allowed {
			return fmt.Errorf("unsupported %s field %q", mappingName, key)
		}
		if _, duplicate := seenKeys[key]; duplicate {
			return fmt.Errorf("duplicate %s field %q", mappingName, key)
		}
		seenKeys[key] = struct{}{}
	}
	return nil
}

func requireEnvironmentPlaceholder(mappingNode *yaml.Node, key string) error {
	value, valueErr := requireNonEmptyScalar(mappingNode, key)
	if valueErr != nil {
		return valueErr
	}
	if !environmentPlaceholderPattern.MatchString(value) {
		return fmt.Errorf("TAuth tenant field %s must use an environment placeholder", key)
	}
	return nil
}

func validateCookieDomain(tenantNode *yaml.Node) error {
	cookieDomain, cookieDomainErr := requireNonEmptyScalar(tenantNode, keyCookieDomain)
	if cookieDomainErr != nil {
		return cookieDomainErr
	}
	if !environmentPlaceholderPattern.MatchString(cookieDomain) && !cookieDomainPattern.MatchString(cookieDomain) {
		return fmt.Errorf("TAuth tenant field %s must be a domain or environment placeholder", keyCookieDomain)
	}
	return nil
}

func validateDurationField(tenantNode *yaml.Node, key string) error {
	durationValue, durationErr := requireNonEmptyScalar(tenantNode, key)
	if durationErr != nil {
		return durationErr
	}
	if environmentPlaceholderPattern.MatchString(durationValue) {
		return nil
	}
	parsedDuration, parseErr := time.ParseDuration(durationValue)
	if parseErr != nil || parsedDuration <= 0 {
		return fmt.Errorf("TAuth tenant field %s must be a positive duration or environment placeholder", key)
	}
	return nil
}

func validateBooleanField(tenantNode *yaml.Node, key string) error {
	valueNode, present := mappingChild(tenantNode, key)
	if !present || valueNode.Kind != yaml.ScalarNode {
		return fmt.Errorf("TAuth tenant field %s must be a boolean or environment placeholder", key)
	}
	value := valueNode.Value
	if value == "" || value != strings.TrimSpace(value) {
		return fmt.Errorf("TAuth tenant field %s must be a canonical boolean or environment placeholder", key)
	}
	if environmentPlaceholderPattern.MatchString(value) {
		return nil
	}
	if _, parseErr := strconv.ParseBool(value); parseErr != nil {
		return fmt.Errorf("TAuth tenant field %s must be a boolean or environment placeholder", key)
	}
	return nil
}

func validateNativeGoogleClients(tenantNode *yaml.Node) ([]string, error) {
	clientsNode, present := mappingChild(tenantNode, keyGoogleNativeClients)
	if !present {
		return []string{}, nil
	}
	if clientsNode.Kind != yaml.SequenceNode || len(clientsNode.Content) == 0 {
		return nil, fmt.Errorf("TAuth tenant field %s must be a non-empty sequence", keyGoogleNativeClients)
	}
	seenPlatforms := make(map[string]struct{}, len(clientsNode.Content))
	nativeClientIDs := make([]string, 0, len(clientsNode.Content))
	for clientIndex, clientNode := range clientsNode.Content {
		if clientNode.Kind != yaml.MappingNode {
			return nil, fmt.Errorf("TAuth tenant field %s item %d must be a mapping", keyGoogleNativeClients, clientIndex)
		}
		if mappingErr := validateMappingKeys(clientNode, allowedNativeGoogleClientKeys, "native Google client"); mappingErr != nil {
			return nil, mappingErr
		}
		platform, platformErr := requireNonEmptyScalar(clientNode, keyPlatform)
		if platformErr != nil || !nativePlatformPattern.MatchString(platform) {
			return nil, fmt.Errorf("native Google client field %s must be a valid platform", keyPlatform)
		}
		if _, duplicate := seenPlatforms[platform]; duplicate {
			return nil, fmt.Errorf("duplicate native Google client platform %q", platform)
		}
		seenPlatforms[platform] = struct{}{}
		if clientIDErr := requireEnvironmentPlaceholder(clientNode, keyClientID); clientIDErr != nil {
			return nil, clientIDErr
		}
		clientID, _ := requireNonEmptyScalar(clientNode, keyClientID)
		nativeClientIDs = append(nativeClientIDs, clientID)
		redirectsNode, redirectsPresent := mappingChild(clientNode, keyRedirectURIs)
		if !redirectsPresent {
			continue
		}
		if redirectsNode.Kind != yaml.SequenceNode || len(redirectsNode.Content) == 0 {
			return nil, fmt.Errorf("native Google client field %s must be a non-empty sequence", keyRedirectURIs)
		}
		seenRedirects := make(map[string]struct{}, len(redirectsNode.Content))
		for _, redirectNode := range redirectsNode.Content {
			redirectURI := redirectNode.Value
			if redirectNode.Kind != yaml.ScalarNode || redirectURI == "" || redirectURI != strings.TrimSpace(redirectURI) || validateRedirectURI(redirectURI) != nil {
				return nil, fmt.Errorf("native Google client field %s contains an invalid redirect URI", keyRedirectURIs)
			}
			if _, duplicate := seenRedirects[redirectURI]; duplicate {
				return nil, fmt.Errorf("duplicate native Google client redirect URI %q", redirectURI)
			}
			seenRedirects[redirectURI] = struct{}{}
		}
	}
	return nativeClientIDs, nil
}

func validateRedirectURI(rawValue string) error {
	if environmentPlaceholderPattern.MatchString(rawValue) {
		return nil
	}
	parsedURI, parseErr := url.Parse(rawValue)
	if parseErr != nil || parsedURI.Scheme == "" || parsedURI.Fragment != "" {
		return errors.New("invalid redirect URI")
	}
	if (parsedURI.Scheme == "http" || parsedURI.Scheme == "https") && parsedURI.Host == "" {
		return errors.New("invalid redirect URI")
	}
	if parsedURI.Host == "" && parsedURI.Path == "" && parsedURI.Opaque == "" {
		return errors.New("invalid redirect URI")
	}
	return nil
}

func validateAppleOAuth(tenantNode *yaml.Node) error {
	appleNode, present := mappingChild(tenantNode, keyAppleOAuth)
	if !present {
		return nil
	}
	if appleNode.Kind != yaml.MappingNode {
		return fmt.Errorf("TAuth tenant field %s must be a mapping", keyAppleOAuth)
	}
	if mappingErr := validateMappingKeys(appleNode, allowedAppleOAuthKeys, "Apple OAuth"); mappingErr != nil {
		return mappingErr
	}
	enabledValue, enabledValueErr := requireNonEmptyScalar(appleNode, keyEnabled)
	if enabledValueErr != nil {
		return enabledValueErr
	}
	enabled, enabledErr := strconv.ParseBool(enabledValue)
	if enabledErr != nil || !enabled {
		return fmt.Errorf("apple OAuth field %s must be true", keyEnabled)
	}
	for _, requiredKey := range []string{keyClientID, keyTeamID, keyKeyID, keyPrivateKeyBase64, keyRedirectURI} {
		if _, requiredErr := requireNonEmptyScalar(appleNode, requiredKey); requiredErr != nil {
			return requiredErr
		}
	}
	if placeholderErr := requireEnvironmentPlaceholder(appleNode, keyPrivateKeyBase64); placeholderErr != nil {
		return placeholderErr
	}
	redirectURI, _ := requireNonEmptyScalar(appleNode, keyRedirectURI)
	if redirectErr := validateRedirectURI(redirectURI); redirectErr != nil {
		return fmt.Errorf("apple OAuth field %s must be a valid redirect URI", keyRedirectURI)
	}
	return nil
}

func requireNonEmptyScalar(mappingNode *yaml.Node, key string) (string, error) {
	valueNode, present := mappingChild(mappingNode, key)
	if !present || valueNode.Kind != yaml.ScalarNode || valueNode.Value == "" || valueNode.Value != strings.TrimSpace(valueNode.Value) {
		return "", fmt.Errorf("TAuth tenant field %s must be one canonical non-empty scalar", key)
	}
	return valueNode.Value, nil
}

func requireTenantOrigins(tenantNode *yaml.Node) ([]string, error) {
	originsNode, present := mappingChild(tenantNode, keyTenantOrigins)
	if !present || originsNode.Kind != yaml.SequenceNode || len(originsNode.Content) == 0 {
		return nil, errors.New("TAuth tenant field tenant_origins must be a non-empty sequence")
	}

	origins := make([]string, 0, len(originsNode.Content))
	seenOrigins := make(map[string]struct{}, len(originsNode.Content))
	for _, originNode := range originsNode.Content {
		origin := originNode.Value
		parsedOrigin, parseErr := url.Parse(origin)
		validURLOrigin := parseErr == nil &&
			parsedOrigin.Host != "" &&
			(parsedOrigin.Scheme == "http" || parsedOrigin.Scheme == "https") &&
			(parsedOrigin.Path == "" || parsedOrigin.Path == "/") &&
			parsedOrigin.RawQuery == "" &&
			parsedOrigin.Fragment == "" &&
			parsedOrigin.User == nil
		if originNode.Kind != yaml.ScalarNode || origin == "" || origin != strings.TrimSpace(origin) || (!validURLOrigin && !environmentPlaceholderPattern.MatchString(origin)) {
			return nil, fmt.Errorf("%s: %q", messageTenantOriginScheme, origin)
		}
		if _, duplicate := seenOrigins[origin]; duplicate {
			return nil, fmt.Errorf("duplicate TAuth tenant origin %q", origin)
		}
		seenOrigins[origin] = struct{}{}
		origins = append(origins, origin)
	}
	return origins, nil
}

func validateFleetTenantResources(tenantResources []tenantResource) error {
	seenTenantIDs := make(map[string]struct{}, len(tenantResources))
	seenOrigins := make(map[string]string)
	seenCookieNames := make(map[string]string)
	seenNativeClientIDs := make(map[string]string)
	for _, tenant := range tenantResources {
		if _, duplicate := seenTenantIDs[tenant.ID]; duplicate {
			return fmt.Errorf("duplicate TAuth tenant id %q", tenant.ID)
		}
		seenTenantIDs[tenant.ID] = struct{}{}
		for _, origin := range tenant.Origins {
			if otherTenantID, duplicate := seenOrigins[origin]; duplicate {
				return fmt.Errorf("duplicate TAuth tenant origin %q for tenants %q and %q", origin, otherTenantID, tenant.ID)
			}
			seenOrigins[origin] = tenant.ID
		}
		for _, cookieName := range []string{tenant.SessionCookieName, tenant.RefreshCookieName} {
			if otherTenantID, duplicate := seenCookieNames[cookieName]; duplicate {
				return fmt.Errorf("duplicate TAuth cookie name %q for tenants %q and %q", cookieName, otherTenantID, tenant.ID)
			}
			seenCookieNames[cookieName] = tenant.ID
		}
		for _, nativeClientID := range tenant.NativeClientIDs {
			if otherTenantID, duplicate := seenNativeClientIDs[nativeClientID]; duplicate {
				return fmt.Errorf("duplicate native Google client id %q for tenants %q and %q", nativeClientID, otherTenantID, tenant.ID)
			}
			seenNativeClientIDs[nativeClientID] = tenant.ID
		}
	}
	return nil
}

func assembleDocument(basePath string, tenantResources []tenantResource) (*yaml.Node, error) {
	baseBytes, readErr := os.ReadFile(basePath)
	if readErr != nil {
		return nil, fmt.Errorf("read TAuth base config %s: %w", basePath, readErr)
	}
	var baseDocument yaml.Node
	if unmarshalErr := yaml.Unmarshal(baseBytes, &baseDocument); unmarshalErr != nil {
		return nil, fmt.Errorf("parse TAuth base config %s: %w", basePath, unmarshalErr)
	}
	rootNode, rootErr := documentRootMapping(&baseDocument)
	if rootErr != nil {
		return nil, fmt.Errorf("parse TAuth base config %s: %w", basePath, rootErr)
	}
	serverNode, serverPresent := mappingChild(rootNode, keyServer)
	if !serverPresent || serverNode.Kind != yaml.MappingNode {
		return nil, fmt.Errorf("TAuth base config %s must define a server mapping", basePath)
	}
	exceptionOrigins, exceptionErr := sequenceScalarValues(serverNode, keyCORSAllowedOriginExceptions)
	if exceptionErr != nil {
		return nil, fmt.Errorf("TAuth base config %s: %w", basePath, exceptionErr)
	}

	sort.Slice(tenantResources, func(leftIndex int, rightIndex int) bool {
		return tenantResources[leftIndex].ID < tenantResources[rightIndex].ID
	})
	allowedOrigins := append([]string{}, exceptionOrigins...)
	for _, tenant := range tenantResources {
		allowedOrigins = append(allowedOrigins, tenant.Origins...)
	}
	sort.Strings(allowedOrigins)
	setMappingChild(serverNode, keyCORSAllowedOrigins, stringSequenceNode(allowedOrigins))

	tenantSequenceNode := &yaml.Node{Kind: yaml.SequenceNode, Tag: "!!seq"}
	for _, tenant := range tenantResources {
		tenantSequenceNode.Content = append(tenantSequenceNode.Content, cloneNode(tenant.Node))
	}
	setMappingChild(rootNode, keyTenants, tenantSequenceNode)
	normalizeNodeStyles(&baseDocument)
	return &baseDocument, nil
}

func documentRootMapping(documentNode *yaml.Node) (*yaml.Node, error) {
	rootNode := documentNode
	if documentNode.Kind == yaml.DocumentNode {
		if len(documentNode.Content) != 1 {
			return nil, errors.New("document must contain one root mapping")
		}
		rootNode = documentNode.Content[0]
	}
	if rootNode.Kind != yaml.MappingNode {
		return nil, errors.New("document root must be a mapping")
	}
	return rootNode, nil
}

func sequenceScalarValues(mappingNode *yaml.Node, key string) ([]string, error) {
	sequenceNode, present := mappingChild(mappingNode, key)
	if !present || sequenceNode.Kind != yaml.SequenceNode || len(sequenceNode.Content) == 0 {
		return nil, fmt.Errorf("field %s must be a non-empty sequence", key)
	}
	values := make([]string, 0, len(sequenceNode.Content))
	for _, valueNode := range sequenceNode.Content {
		value := valueNode.Value
		if valueNode.Kind != yaml.ScalarNode || value == "" || value != strings.TrimSpace(value) {
			return nil, fmt.Errorf("field %s must contain non-empty scalars", key)
		}
		values = append(values, value)
	}
	return values, nil
}

func mappingChild(mappingNode *yaml.Node, key string) (*yaml.Node, bool) {
	if mappingNode == nil || mappingNode.Kind != yaml.MappingNode {
		return nil, false
	}
	for contentIndex := 0; contentIndex < len(mappingNode.Content); contentIndex += 2 {
		if mappingNode.Content[contentIndex].Value == key {
			return mappingNode.Content[contentIndex+1], true
		}
	}
	return nil, false
}

func setMappingChild(mappingNode *yaml.Node, key string, valueNode *yaml.Node) {
	for contentIndex := 0; contentIndex < len(mappingNode.Content); contentIndex += 2 {
		if mappingNode.Content[contentIndex].Value == key {
			mappingNode.Content[contentIndex+1] = valueNode
			return
		}
	}
	mappingNode.Content = append(mappingNode.Content,
		&yaml.Node{Kind: yaml.ScalarNode, Tag: "!!str", Value: key},
		valueNode,
	)
}

func stringSequenceNode(values []string) *yaml.Node {
	sequenceNode := &yaml.Node{Kind: yaml.SequenceNode, Tag: "!!seq"}
	for _, value := range values {
		sequenceNode.Content = append(sequenceNode.Content, &yaml.Node{Kind: yaml.ScalarNode, Tag: "!!str", Value: value})
	}
	return sequenceNode
}

func cloneNode(sourceNode *yaml.Node) *yaml.Node {
	clonedNode := *sourceNode
	clonedNode.Content = make([]*yaml.Node, 0, len(sourceNode.Content))
	for _, childNode := range sourceNode.Content {
		clonedNode.Content = append(clonedNode.Content, cloneNode(childNode))
	}
	return &clonedNode
}

func normalizeNodeStyles(node *yaml.Node) {
	node.Style = 0
	for _, childNode := range node.Content {
		normalizeNodeStyles(childNode)
	}
}

func writeDocumentAtomically(outputPath string, documentNode *yaml.Node) error {
	var outputBuffer bytes.Buffer
	encoder := yaml.NewEncoder(&outputBuffer)
	encoder.SetIndent(2)
	if encodeErr := encoder.Encode(documentNode); encodeErr != nil {
		return fmt.Errorf("encode assembled TAuth config: %w", encodeErr)
	}
	if closeErr := encoder.Close(); closeErr != nil {
		return fmt.Errorf("close assembled TAuth config encoder: %w", closeErr)
	}

	outputDirectory := filepath.Dir(outputPath)
	temporaryFile, createErr := os.CreateTemp(outputDirectory, temporaryFilePattern)
	if createErr != nil {
		return fmt.Errorf("create temporary TAuth config in %s: %w", outputDirectory, createErr)
	}
	temporaryPath := temporaryFile.Name()
	removeTemporary := true
	defer func() {
		if removeTemporary {
			_ = os.Remove(temporaryPath)
		}
	}()
	if chmodErr := temporaryFile.Chmod(outputFileMode); chmodErr != nil {
		_ = temporaryFile.Close()
		return fmt.Errorf("set temporary TAuth config permissions: %w", chmodErr)
	}
	if _, writeErr := temporaryFile.Write(outputBuffer.Bytes()); writeErr != nil {
		_ = temporaryFile.Close()
		return fmt.Errorf("write temporary TAuth config: %w", writeErr)
	}
	if syncErr := temporaryFile.Sync(); syncErr != nil {
		_ = temporaryFile.Close()
		return fmt.Errorf("sync temporary TAuth config: %w", syncErr)
	}
	if closeErr := temporaryFile.Close(); closeErr != nil {
		return fmt.Errorf("close temporary TAuth config: %w", closeErr)
	}
	if renameErr := os.Rename(temporaryPath, outputPath); renameErr != nil {
		return fmt.Errorf("replace assembled TAuth config %s: %w", outputPath, renameErr)
	}
	removeTemporary = false
	return nil
}

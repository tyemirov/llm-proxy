package deployrecap

import (
	"strings"
	"testing"
)

func TestParseSummarizesDeployLog(t *testing.T) {
	t.Parallel()

	logText := `
TASK [Report gateway image pull actions] ****************************************
ok: [tutosh] => {
    "msg": "host=tutosh phase=pull changed=True actions=[{\"what\": \"service\", \"id\": \"writer-api\", \"status\": \"Pulling\"}, {\"what\": \"service\", \"id\": \"tauth-api\", \"status\": \"Pulling\"}]"
}

TASK [Report gateway deploy actions] ********************************************
ok: [tutosh] => {
    "msg": "host=tutosh phase=deploy changed=True actions=[{\"what\": \"container\", \"id\": \"tauth-api\", \"status\": \"Recreate\"}, {\"what\": \"container\", \"id\": \"writer-api\", \"status\": \"Recreate\"}, {\"what\": \"container\", \"id\": \"tauth-api\", \"status\": \"Starting\"}, {\"what\": \"container\", \"id\": \"writer-api\", \"status\": \"Starting\"}]"
}

PLAY RECAP **********************************************************************
tutosh                     : ok=11   changed=2    unreachable=0    failed=0    skipped=10    rescued=0    ignored=0
`

	summary, err := Parse(strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse deploy recap: %v", err)
	}

	expected := "RECAP changed=2 skipped=10 hosts=tutosh(ok=11,changed=2,skipped=10) services=tauth-api,writer-api pulled=2 recreated=2 started=2"
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailsWithoutRecap(t *testing.T) {
	t.Parallel()

	_, err := Parse(strings.NewReader(`ok: [tutosh] => {"msg": "host=tutosh phase=deploy changed=True actions=[]"}`))
	if err == nil {
		t.Fatal("expected parse to fail without a deploy recap")
	}
}

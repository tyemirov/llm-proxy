package deployrecap

import (
	"strings"
	"testing"
)

func TestParseFailureSummarizesURIFailure(t *testing.T) {
	t.Parallel()

	logText := `
TASK [Verify gateway HTTP health checks through gateway routing] ***************
FAILED - RETRYING: [tutosh]: Verify gateway HTTP health checks through gateway routing (11 retries left).
fatal: [tutosh] (item=Writer API endpoint health) => {"attempts":12,"changed":false,"msg":"Status code was 502 and not [200, 308]: HTTP Error 502: Bad Gateway","redirected":false,"status":502,"url":"https://writer-api.mprlab.com/api/health"}

PLAY RECAP *********************************************************************
tutosh                     : ok=10   changed=0    unreachable=0    failed=1    skipped=0    rescued=0    ignored=0
`

	summary, err := ParseFailure("verify", strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse failure recap: %v", err)
	}

	expected := `RECAP status=failed phase="verify" task="Verify gateway HTTP health checks through gateway routing" host="tutosh" item="Writer API endpoint health" reason="Status code was 502 and not [200, 308]: HTTP Error 502: Bad Gateway (status=502 url=https://writer-api.mprlab.com/api/health)"`
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected failure summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailureSummarizesCommandFailure(t *testing.T) {
	t.Parallel()

	logText := `
TASK [Verify NameSignal API preflight through gateway routing] *****************
FAILED - RETRYING: [tutosh]: Verify NameSignal API preflight through gateway routing (1 retries left).
fatal: [tutosh]: FAILED! => {"attempts":2,"changed":false,"cmd":["curl","--silent"],"msg":"non-zero return code","rc":56,"stderr":"OpenSSL SSL_connect: SSL_ERROR_SYSCALL in connection to namesignal-api.mprlab.com:443 ","stdout":"HTTP_STATUS:000\n"}
`

	summary, err := ParseFailure("verify", strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse failure recap: %v", err)
	}

	expected := `RECAP status=failed phase="verify" task="Verify NameSignal API preflight through gateway routing" host="tutosh" reason="command failed (rc=56): OpenSSL SSL_connect: SSL_ERROR_SYSCALL in connection to namesignal-api.mprlab.com:443"`
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected failure summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailureSummarizesAssertFailure(t *testing.T) {
	t.Parallel()

	logText := `
TASK [Verify gateway services resolve to container IDs] ************************
failed: [tutosh] (item=writer-api) => {"assertion":"(item.stdout_lines | length) > 0","changed":false,"evaluated_to":false,"msg":"No container found for service writer-api on tutosh"}
`

	summary, err := ParseFailure("verify", strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse failure recap: %v", err)
	}

	expected := `RECAP status=failed phase="verify" task="Verify gateway services resolve to container IDs" host="tutosh" item="writer-api" reason="No container found for service writer-api on tutosh"`
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected failure summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailureSummarizesRecapOnlyFailure(t *testing.T) {
	t.Parallel()

	logText := `
PLAY RECAP *********************************************************************
tutosh                     : ok=8    changed=0    unreachable=1    failed=0    skipped=0    rescued=0    ignored=0
`

	summary, err := ParseFailure("preflight", strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse failure recap: %v", err)
	}

	expected := `RECAP status=failed phase="preflight" host="tutosh" reason="ansible recap reported unreachable=1 failed=0 without a task failure line"`
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected failure summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailureSummarizesNestedMakeFailure(t *testing.T) {
	t.Parallel()

	logText := `
TASK [Fail when gateway deployment parent directory is missing] ****************
ok: [tutosh] => {
    "changed": false,
    "msg": "All assertions passed"
}

make[2]: *** [preflight] Error 4
`

	summary, err := ParseFailure("preflight", strings.NewReader(logText))
	if err != nil {
		t.Fatalf("parse failure recap: %v", err)
	}

	expected := `RECAP status=failed phase="preflight" reason="make target preflight exited with error 4"`
	if got := summary.String(); got != expected {
		t.Fatalf("unexpected failure summary:\nwant: %s\ngot:  %s", expected, got)
	}
}

func TestParseFailureFailsWithoutFailureLine(t *testing.T) {
	t.Parallel()

	_, err := ParseFailure("verify", strings.NewReader(`TASK [noop] ***`))
	if err == nil {
		t.Fatal("expected parse failure to fail without a terminal failure line")
	}
}

package deployrecap

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"regexp"
	"strings"
)

type FailureSummary struct {
	Phase  string
	Task   string
	Host   string
	Item   string
	Reason string
}

var (
	taskPattern         = regexp.MustCompile(`^TASK \[(.+?)\] \*+`)
	failureLinePattern  = regexp.MustCompile(`^(fatal|failed|unreachable): \[([^\]]+)\](?: \((?:item=)?([^)]+)\))?(?:: FAILED!)? => (.+)$`)
	recapFailurePattern = regexp.MustCompile(`^\s*([^\s]+)\s*:\s*ok=\d+\s+changed=\d+\s+unreachable=(\d+)\s+failed=(\d+)`)
	makeErrorPattern    = regexp.MustCompile(`^make(?:\[\d+\])?: \*\*\* \[(?:[^:\]]+:\d+: )?([^\]]+)\] Error (\d+)`)
)

func ParseFailure(phase string, reader io.Reader) (FailureSummary, error) {
	lines, err := readLogLines(reader)
	if err != nil {
		return FailureSummary{}, err
	}

	currentTask := ""
	for index := 0; index < len(lines); index++ {
		line := lines[index]

		if taskMatch := taskPattern.FindStringSubmatch(line); len(taskMatch) == 2 {
			currentTask = strings.TrimSpace(taskMatch[1])
			continue
		}

		if strings.HasPrefix(strings.TrimSpace(line), "FAILED - RETRYING:") {
			continue
		}

		failureMatch := failureLinePattern.FindStringSubmatch(line)
		if len(failureMatch) != 5 {
			continue
		}

		payloadBlock := collectFailurePayload(lines, index)
		reason := summarizeFailurePayload(payloadBlock)
		if reason == "" {
			reason = strings.TrimSpace(line)
		}

		return FailureSummary{
			Phase:  strings.TrimSpace(phase),
			Task:   currentTask,
			Host:   strings.TrimSpace(failureMatch[2]),
			Item:   strings.TrimSpace(failureMatch[3]),
			Reason: reason,
		}, nil
	}

	if summary := parseRecapOnlyFailure(phase, lines); summary != nil {
		return *summary, nil
	}
	if summary := parseMakeFailure(phase, lines); summary != nil {
		return *summary, nil
	}

	return FailureSummary{}, fmt.Errorf("failure recap unavailable")
}

func (summary FailureSummary) String() string {
	parts := []string{
		fmt.Sprintf("RECAP status=failed phase=%q", summary.Phase),
	}
	if strings.TrimSpace(summary.Task) != "" {
		parts = append(parts, fmt.Sprintf("task=%q", summary.Task))
	}
	if strings.TrimSpace(summary.Host) != "" {
		parts = append(parts, fmt.Sprintf("host=%q", summary.Host))
	}
	if strings.TrimSpace(summary.Item) != "" {
		parts = append(parts, fmt.Sprintf("item=%q", summary.Item))
	}
	if strings.TrimSpace(summary.Reason) != "" {
		parts = append(parts, fmt.Sprintf("reason=%q", summary.Reason))
	}
	return strings.Join(parts, " ")
}

func readLogLines(reader io.Reader) ([]string, error) {
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 1024), 10*1024*1024)

	var lines []string
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return lines, nil
}

func collectFailurePayload(lines []string, start int) string {
	var block []string
	for index := start; index < len(lines); index++ {
		line := lines[index]
		if index > start {
			trimmed := strings.TrimSpace(line)
			if trimmed == "" || strings.HasPrefix(trimmed, "TASK [") || strings.HasPrefix(trimmed, "PLAY RECAP") {
				break
			}
		}
		block = append(block, line)
	}
	return strings.Join(block, "\n")
}

func summarizeFailurePayload(payload string) string {
	trimmed := strings.TrimSpace(payload)
	if trimmed == "" {
		return ""
	}

	jsonPayload := extractJSONObject(trimmed)
	if jsonPayload == "" {
		return trimmed
	}

	var raw map[string]json.RawMessage
	if err := json.Unmarshal([]byte(jsonPayload), &raw); err != nil {
		return trimmed
	}

	message := readJSONString(raw, "msg")
	status := readJSONNumber(raw, "status")
	url := readJSONString(raw, "url")
	returnCode := readJSONNumber(raw, "rc")
	stderr := compactWhitespace(readJSONString(raw, "stderr"))
	stdout := compactWhitespace(readJSONString(raw, "stdout"))

	switch {
	case strings.TrimSpace(message) == "":
		return summarizeCommandFailure(returnCode, status, url, stderr, stdout)
	case strings.TrimSpace(message) == "non-zero return code":
		return summarizeCommandFailure(returnCode, status, url, stderr, stdout)
	default:
		if status != "" && url != "" && !strings.Contains(message, url) {
			return fmt.Sprintf("%s (status=%s url=%s)", message, status, url)
		}
		return message
	}
}

func summarizeCommandFailure(returnCode string, status string, url string, stderr string, stdout string) string {
	var details []string
	if strings.TrimSpace(returnCode) != "" {
		details = append(details, fmt.Sprintf("rc=%s", returnCode))
	}
	if strings.TrimSpace(status) != "" {
		details = append(details, fmt.Sprintf("status=%s", status))
	}
	if strings.TrimSpace(url) != "" {
		details = append(details, fmt.Sprintf("url=%s", url))
	}

	var signal string
	switch {
	case strings.TrimSpace(stderr) != "":
		signal = stderr
	case strings.TrimSpace(stdout) != "":
		signal = stdout
	}

	prefix := "command failed"
	if len(details) > 0 {
		prefix = fmt.Sprintf("%s (%s)", prefix, strings.Join(details, " "))
	}
	if signal == "" {
		return prefix
	}
	return fmt.Sprintf("%s: %s", prefix, signal)
}

func extractJSONObject(payload string) string {
	start := strings.Index(payload, "{")
	end := strings.LastIndex(payload, "}")
	if start < 0 || end < 0 || end < start {
		return ""
	}
	return strings.TrimSpace(payload[start : end+1])
}

func readJSONString(values map[string]json.RawMessage, key string) string {
	raw, ok := values[key]
	if !ok {
		return ""
	}
	var value string
	if err := json.Unmarshal(raw, &value); err == nil {
		return strings.TrimSpace(value)
	}
	return ""
}

func readJSONNumber(values map[string]json.RawMessage, key string) string {
	raw, ok := values[key]
	if !ok {
		return ""
	}
	var value any
	if err := json.Unmarshal(raw, &value); err != nil {
		return ""
	}
	switch typed := value.(type) {
	case float64:
		return strings.TrimSuffix(strings.TrimSuffix(fmt.Sprintf("%.0f", typed), ".0"), ".")
	case string:
		return strings.TrimSpace(typed)
	default:
		return ""
	}
}

func compactWhitespace(value string) string {
	fields := strings.Fields(strings.TrimSpace(value))
	if len(fields) == 0 {
		return ""
	}
	return strings.Join(fields, " ")
}

func parseRecapOnlyFailure(phase string, lines []string) *FailureSummary {
	for _, line := range lines {
		match := recapFailurePattern.FindStringSubmatch(line)
		if len(match) != 4 {
			continue
		}
		unreachableCount := strings.TrimSpace(match[2])
		failedCount := strings.TrimSpace(match[3])
		if !countIsNonZero(unreachableCount) && !countIsNonZero(failedCount) {
			continue
		}
		return &FailureSummary{
			Phase:  strings.TrimSpace(phase),
			Host:   strings.TrimSpace(match[1]),
			Reason: fmt.Sprintf("ansible recap reported unreachable=%s failed=%s without a task failure line", unreachableCount, failedCount),
		}
	}
	return nil
}

func parseMakeFailure(phase string, lines []string) *FailureSummary {
	for _, line := range lines {
		match := makeErrorPattern.FindStringSubmatch(line)
		if len(match) != 3 {
			continue
		}
		return &FailureSummary{
			Phase:  strings.TrimSpace(phase),
			Reason: fmt.Sprintf("make target %s exited with error %s", strings.TrimSpace(match[1]), strings.TrimSpace(match[2])),
		}
	}
	return nil
}

func countIsNonZero(value string) bool {
	trimmed := strings.TrimSpace(value)
	return strings.TrimLeft(trimmed, "0") != ""
}

package deployrecap

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type HostSummary struct {
	Name    string
	OK      int
	Changed int
	Skipped int
}

type Summary struct {
	Hosts     []HostSummary
	Services  []string
	Changed   int
	Skipped   int
	Pulled    int
	Recreated int
	Started   int
}

type action struct {
	What   string `json:"what"`
	ID     string `json:"id"`
	Status string `json:"status"`
}

var (
	recapPattern   = regexp.MustCompile(`^\s*([^\s]+)\s*:\s*ok=(\d+)\s+changed=(\d+)\s+unreachable=\d+\s+failed=\d+\s+skipped=(\d+)`)
	phasePattern   = regexp.MustCompile(`phase=([a-z_]+)`)
	actionsPattern = regexp.MustCompile(`actions=(\[.*\])`)
)

func Parse(reader io.Reader) (Summary, error) {
	scanner := bufio.NewScanner(reader)
	services := make(map[string]struct{})
	summary := Summary{}

	for scanner.Scan() {
		line := scanner.Text()

		if host := parseRecapLine(line); host != nil {
			summary.Hosts = append(summary.Hosts, *host)
			summary.Changed += host.Changed
			summary.Skipped += host.Skipped
		}

		phaseMatch := phasePattern.FindStringSubmatch(line)
		actionsMatch := actionsPattern.FindStringSubmatch(line)
		if len(phaseMatch) < 2 || len(actionsMatch) < 2 {
			continue
		}

		actions, err := parseActions(actionsMatch[1])
		if err != nil {
			return Summary{}, err
		}

		for _, current := range actions {
			status := strings.ToLower(strings.TrimSpace(current.Status))
			switch {
			case phaseMatch[1] == "pull" && current.What == "service" && current.ID != "":
				services[current.ID] = struct{}{}
				if status == "pulling" {
					summary.Pulled++
				}
			case phaseMatch[1] == "deploy" && current.What == "container" && status == "recreate":
				summary.Recreated++
			case phaseMatch[1] == "deploy" && current.What == "container" && status == "starting":
				summary.Started++
			}
		}
	}

	if err := scanner.Err(); err != nil {
		return Summary{}, err
	}
	if len(summary.Hosts) == 0 {
		return Summary{}, fmt.Errorf("deploy recap unavailable")
	}

	summary.Services = make([]string, 0, len(services))
	for service := range services {
		summary.Services = append(summary.Services, service)
	}
	sort.Strings(summary.Services)

	return summary, nil
}

func (summary Summary) String() string {
	hostParts := make([]string, 0, len(summary.Hosts))
	for _, host := range summary.Hosts {
		hostParts = append(hostParts, fmt.Sprintf("%s(ok=%d,changed=%d,skipped=%d)", host.Name, host.OK, host.Changed, host.Skipped))
	}

	services := "none"
	if len(summary.Services) > 0 {
		services = strings.Join(summary.Services, ",")
	}

	return fmt.Sprintf(
		"RECAP changed=%d skipped=%d hosts=%s services=%s pulled=%d recreated=%d started=%d",
		summary.Changed,
		summary.Skipped,
		strings.Join(hostParts, ","),
		services,
		summary.Pulled,
		summary.Recreated,
		summary.Started,
	)
}

func parseRecapLine(line string) *HostSummary {
	match := recapPattern.FindStringSubmatch(line)
	if len(match) != 5 {
		return nil
	}

	okCount, okErr := strconv.Atoi(match[2])
	changedCount, changedErr := strconv.Atoi(match[3])
	skippedCount, skippedErr := strconv.Atoi(match[4])
	if okErr != nil || changedErr != nil || skippedErr != nil {
		return nil
	}

	return &HostSummary{
		Name:    match[1],
		OK:      okCount,
		Changed: changedCount,
		Skipped: skippedCount,
	}
}

func parseActions(raw string) ([]action, error) {
	var actions []action
	if err := json.Unmarshal([]byte(raw), &actions); err == nil {
		return actions, nil
	}

	unescaped, err := strconv.Unquote(`"` + raw + `"`)
	if err != nil {
		return nil, fmt.Errorf("unquote actions: %w", err)
	}
	if err := json.Unmarshal([]byte(unescaped), &actions); err != nil {
		return nil, fmt.Errorf("parse actions json: %w", err)
	}
	return actions, nil
}

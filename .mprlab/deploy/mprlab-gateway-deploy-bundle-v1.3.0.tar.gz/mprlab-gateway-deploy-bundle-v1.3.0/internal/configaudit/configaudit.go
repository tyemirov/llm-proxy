// Package configaudit validates gateway-owned Docker Compose boundaries.
package configaudit

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

var (
	serviceNamePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9_.-]*$`)
	dockerNamePattern  = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]*$`)
	tlsListenerPorts   = map[int]struct{}{443: {}, 465: {}, 587: {}, 8443: {}}
)

// Result contains deterministic contract violations.
type Result struct {
	Errors []string
}

func (result *Result) addError(message string, arguments ...any) {
	result.Errors = append(result.Errors, fmt.Sprintf(message, arguments...))
}

type scalarList []string

func (values *scalarList) UnmarshalYAML(node *yaml.Node) error {
	if node == nil || node.Tag == "!!null" {
		*values = nil
		return nil
	}
	switch node.Kind {
	case yaml.SequenceNode:
		decoded := make([]string, 0, len(node.Content))
		for _, child := range node.Content {
			if child.Kind != yaml.ScalarNode || child.Value == "" || child.Value != strings.TrimSpace(child.Value) {
				return errors.New("list entries must be canonical non-empty scalars")
			}
			decoded = append(decoded, child.Value)
		}
		*values = decoded
		return nil
	default:
		return errors.New("value must be one scalar list")
	}
}

type dependencySet []string

func (dependencies *dependencySet) UnmarshalYAML(node *yaml.Node) error {
	if node == nil || node.Tag == "!!null" {
		*dependencies = nil
		return nil
	}
	values := make([]string, 0)
	switch node.Kind {
	case yaml.SequenceNode:
		for _, child := range node.Content {
			if child.Kind != yaml.ScalarNode || child.Value == "" || child.Value != strings.TrimSpace(child.Value) {
				return errors.New("depends_on entries must be canonical non-empty service names")
			}
			values = append(values, child.Value)
		}
	case yaml.MappingNode:
		for index := 0; index < len(node.Content); index += 2 {
			key := node.Content[index]
			if key.Kind != yaml.ScalarNode || key.Value == "" || key.Value != strings.TrimSpace(key.Value) {
				return errors.New("depends_on keys must be canonical non-empty service names")
			}
			values = append(values, key.Value)
		}
	default:
		return errors.New("depends_on must be a service list or mapping")
	}
	*dependencies = values
	return nil
}

type composeDocument struct {
	Services map[string]composeService `yaml:"services"`
	Volumes  map[string]yaml.Node      `yaml:"volumes"`
}

type composeService struct {
	Image     string        `yaml:"image"`
	Build     yaml.Node     `yaml:"build"`
	DependsOn dependencySet `yaml:"depends_on"`
	EnvFiles  scalarList    `yaml:"env_file"`
	Volumes   scalarList    `yaml:"volumes"`
	Ports     scalarList    `yaml:"ports"`
	Expose    scalarList    `yaml:"expose"`
}

// Run audits one staged Compose file without parsing any product-owned schema.
func Run(composePath string, selectedServices []string) Result {
	result := Result{Errors: make([]string, 0)}
	document, composeDirectory, err := loadCompose(composePath)
	if err != nil {
		result.addError("compose contract: %v", err)
		return result
	}
	serviceNames := selectServiceNames(document, selectedServices, &result)
	validateDocument(document, composeDirectory, serviceNames, &result)
	sort.Strings(result.Errors)
	return result
}

// WriteSelectedCompose writes the explicitly selected service closure to one staged Compose file.
func WriteSelectedCompose(composePath string, selectedServices []string, destinationPath string) Result {
	result := Result{Errors: make([]string, 0)}
	if len(selectedServices) == 0 {
		result.addError("selected Compose output requires at least one selected service")
		return result
	}
	document, _, err := loadCompose(composePath)
	if err != nil {
		result.addError("compose contract: %v", err)
		return result
	}
	serviceNames := selectServiceNames(document, selectedServices, &result)
	if len(result.Errors) > 0 {
		sort.Strings(result.Errors)
		return result
	}
	rawDocument, rawDocumentErr := loadComposeNode(composePath)
	if rawDocumentErr != nil {
		result.addError("compose contract: %v", rawDocumentErr)
		return result
	}
	servicesNode, servicesNodeErr := composeServicesNode(rawDocument)
	if servicesNodeErr != nil {
		result.addError("compose contract: %v", servicesNodeErr)
		return result
	}
	selectedServiceNames := make(map[string]struct{}, len(serviceNames))
	for _, serviceName := range serviceNames {
		selectedServiceNames[serviceName] = struct{}{}
	}
	selectedContent := make([]*yaml.Node, 0, len(serviceNames)*2)
	for index := 0; index < len(servicesNode.Content); index += 2 {
		serviceNameNode := servicesNode.Content[index]
		serviceNode := servicesNode.Content[index+1]
		if serviceNameNode.Kind != yaml.ScalarNode {
			result.addError("compose services must use scalar names")
			continue
		}
		if _, selected := selectedServiceNames[serviceNameNode.Value]; selected {
			selectedContent = append(selectedContent, serviceNameNode, serviceNode)
		}
	}
	if len(result.Errors) > 0 {
		sort.Strings(result.Errors)
		return result
	}
	servicesNode.Content = selectedContent
	if writeErr := writeComposeNode(rawDocument, destinationPath); writeErr != nil {
		result.addError("selected Compose output: %v", writeErr)
	}
	sort.Strings(result.Errors)
	return result
}

func loadCompose(composePath string) (composeDocument, string, error) {
	file, composeDirectory, err := openComposeFile(composePath)
	if err != nil {
		return composeDocument{}, "", err
	}
	defer func() { _ = file.Close() }()

	decoder := yaml.NewDecoder(file)
	var document composeDocument
	if err := decoder.Decode(&document); err != nil {
		return composeDocument{}, "", fmt.Errorf("parse %s: %w", composePath, err)
	}
	var trailing yaml.Node
	trailingErr := decoder.Decode(&trailing)
	if trailingErr == nil {
		return composeDocument{}, "", fmt.Errorf("%s must contain exactly one YAML document", composePath)
	}
	if !errors.Is(trailingErr, io.EOF) {
		return composeDocument{}, "", fmt.Errorf("parse %s: %w", composePath, trailingErr)
	}
	return document, composeDirectory, nil
}

func loadComposeNode(composePath string) (*yaml.Node, error) {
	file, _, err := openComposeFile(composePath)
	if err != nil {
		return nil, err
	}
	defer func() { _ = file.Close() }()

	decoder := yaml.NewDecoder(file)
	var document yaml.Node
	if err := decoder.Decode(&document); err != nil {
		return nil, fmt.Errorf("parse %s: %w", composePath, err)
	}
	var trailing yaml.Node
	trailingErr := decoder.Decode(&trailing)
	if trailingErr == nil {
		return nil, fmt.Errorf("%s must contain exactly one YAML document", composePath)
	}
	if !errors.Is(trailingErr, io.EOF) {
		return nil, fmt.Errorf("parse %s: %w", composePath, trailingErr)
	}
	if document.Kind != yaml.DocumentNode || len(document.Content) != 1 || document.Content[0].Kind != yaml.MappingNode {
		return nil, errors.New("compose document must be one mapping")
	}
	return &document, nil
}

func openComposeFile(composePath string) (*os.File, string, error) {
	trimmedPath := strings.TrimSpace(composePath)
	if trimmedPath == "" || trimmedPath != composePath {
		return nil, "", errors.New("compose path must be one non-empty canonical string")
	}
	fileInfo, err := os.Lstat(trimmedPath)
	if err != nil {
		return nil, "", fmt.Errorf("inspect %s: %w", trimmedPath, err)
	}
	if !fileInfo.Mode().IsRegular() || fileInfo.Mode()&os.ModeSymlink != 0 {
		return nil, "", fmt.Errorf("%s must be a regular non-symlink file", trimmedPath)
	}
	file, err := os.Open(trimmedPath)
	if err != nil {
		return nil, "", fmt.Errorf("open %s: %w", trimmedPath, err)
	}
	return file, filepath.Dir(trimmedPath), nil
}

func composeServicesNode(document *yaml.Node) (*yaml.Node, error) {
	root := document.Content[0]
	for index := 0; index < len(root.Content); index += 2 {
		key := root.Content[index]
		value := root.Content[index+1]
		if key.Kind != yaml.ScalarNode {
			return nil, errors.New("compose document keys must be scalars")
		}
		if key.Value == "services" {
			if value.Kind != yaml.MappingNode || len(value.Content) == 0 || len(value.Content)%2 != 0 {
				return nil, errors.New("compose services must be one non-empty mapping")
			}
			return value, nil
		}
	}
	return nil, errors.New("compose services must be one non-empty mapping")
}

func writeComposeNode(document *yaml.Node, destinationPath string) error {
	if destinationPath == "" || destinationPath != strings.TrimSpace(destinationPath) || filepath.IsAbs(destinationPath) || filepath.Clean(destinationPath) != destinationPath || strings.Contains(destinationPath, `\`) || strings.HasPrefix(destinationPath, "../") || destinationPath == "." {
		return errors.New("path must be one canonical relative output path")
	}
	file, err := os.OpenFile(destinationPath, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		return fmt.Errorf("create %s: %w", destinationPath, err)
	}
	encoder := yaml.NewEncoder(file)
	encoder.SetIndent(2)
	encodeErr := encoder.Encode(document)
	closeErr := file.Close()
	if encodeErr != nil {
		return fmt.Errorf("write %s: %w", destinationPath, encodeErr)
	}
	if closeErr != nil {
		return fmt.Errorf("close %s: %w", destinationPath, closeErr)
	}
	return nil
}

func selectServiceNames(document composeDocument, selectedServices []string, result *Result) []string {
	if len(selectedServices) == 0 {
		serviceNames := make([]string, 0, len(document.Services))
		for serviceName := range document.Services {
			serviceNames = append(serviceNames, serviceName)
		}
		sort.Strings(serviceNames)
		return serviceNames
	}

	selected := make(map[string]struct{}, len(selectedServices))
	serviceNames := make([]string, 0, len(selectedServices))
	for _, serviceName := range selectedServices {
		if !serviceNamePattern.MatchString(serviceName) {
			result.addError("selected service name %q is not canonical", serviceName)
			continue
		}
		if _, duplicate := selected[serviceName]; duplicate {
			result.addError("selected service %s is duplicated", serviceName)
			continue
		}
		selected[serviceName] = struct{}{}
		if _, found := document.Services[serviceName]; !found {
			result.addError("selected service %s is not declared", serviceName)
			continue
		}
		serviceNames = append(serviceNames, serviceName)
	}
	sort.Strings(serviceNames)
	for _, serviceName := range serviceNames {
		for _, dependency := range document.Services[serviceName].DependsOn {
			if _, declared := document.Services[dependency]; !declared {
				continue
			}
			if _, included := selected[dependency]; !included {
				result.addError("selected service %s depends on unselected service %s", serviceName, dependency)
			}
		}
	}
	return serviceNames
}

func validateDocument(document composeDocument, composeDirectory string, serviceNames []string, result *Result) {
	if len(document.Services) == 0 {
		result.addError("compose services must be one non-empty mapping")
		return
	}
	for volumeName := range document.Volumes {
		if !dockerNamePattern.MatchString(volumeName) {
			result.addError("top-level volume name %q is not canonical", volumeName)
		}
	}
	caddyStorageSources := collectCaddyStorageSources(document.Services)

	for _, serviceName := range serviceNames {
		service := document.Services[serviceName]
		validateService(serviceName, service, document, composeDirectory, caddyStorageSources, result)
	}
}

func validateService(
	serviceName string,
	service composeService,
	document composeDocument,
	composeDirectory string,
	caddyStorageSources map[string]struct{},
	result *Result,
) {
	if !serviceNamePattern.MatchString(serviceName) {
		result.addError("service name %q is not canonical", serviceName)
	}
	image := strings.TrimSpace(service.Image)
	buildDeclared := service.Build.Kind != 0 && service.Build.Tag != "!!null"
	if image == "" || image != service.Image || buildDeclared {
		result.addError("service %s must declare one image and no build", serviceName)
	}

	seenDependencies := make(map[string]struct{}, len(service.DependsOn))
	for _, dependency := range service.DependsOn {
		if _, duplicate := seenDependencies[dependency]; duplicate {
			result.addError("service %s duplicates depends_on service %s", serviceName, dependency)
			continue
		}
		seenDependencies[dependency] = struct{}{}
		if _, found := document.Services[dependency]; !found {
			result.addError("service %s depends on unknown service %s", serviceName, dependency)
		}
	}

	seenEnvFiles := make(map[string]struct{}, len(service.EnvFiles))
	for _, envFile := range service.EnvFiles {
		if _, duplicate := seenEnvFiles[envFile]; duplicate {
			result.addError("service %s duplicates environment file %s", serviceName, envFile)
			continue
		}
		seenEnvFiles[envFile] = struct{}{}
		relativePath, pathErr := canonicalRelativePath(envFile)
		if pathErr != nil {
			result.addError("service %s environment file %s", serviceName, pathErr)
			continue
		}
		validateLocalSource(serviceName, "environment file", composeDirectory, relativePath, false, result)
	}

	for _, volume := range service.Volumes {
		validateVolume(serviceName, volume, document.Volumes, composeDirectory, caddyStorageSources, result)
	}
	if serviceName != "caddy" {
		for _, exposedPort := range service.Expose {
			validateApplicationPort(serviceName, exposedPort, false, result)
		}
		for _, publishedPort := range service.Ports {
			validateApplicationPort(serviceName, publishedPort, true, result)
		}
	}
}

func collectCaddyStorageSources(services map[string]composeService) map[string]struct{} {
	storageSources := make(map[string]struct{})
	caddyService, found := services["caddy"]
	if !found {
		return storageSources
	}
	for _, volume := range caddyService.Volumes {
		parts := strings.Split(volume, ":")
		if len(parts) < 2 || len(parts) > 3 || strings.TrimSpace(parts[0]) == "" {
			continue
		}
		if isCaddyOwnedTarget(parts[1]) {
			storageSources[parts[0]] = struct{}{}
		}
	}
	return storageSources
}

func canonicalRelativePath(value string) (string, error) {
	if value != strings.TrimSpace(value) || !strings.HasPrefix(value, "./") {
		return "", errors.New("must be one canonical ./-relative path")
	}
	relativePath := strings.TrimPrefix(value, "./")
	if relativePath == "" || relativePath == "." || path.Clean(relativePath) != relativePath || strings.HasPrefix(relativePath, "../") || strings.Contains(relativePath, `\`) {
		return "", errors.New("must be one canonical ./-relative path")
	}
	return filepath.FromSlash(relativePath), nil
}

func validateLocalSource(
	serviceName string,
	label string,
	composeDirectory string,
	relativePath string,
	allowDirectory bool,
	result *Result,
) {
	fullPath := filepath.Join(composeDirectory, relativePath)
	fileInfo, err := os.Lstat(fullPath)
	if err != nil {
		if os.IsNotExist(err) {
			result.addError("service %s %s is missing: ./%s", serviceName, label, filepath.ToSlash(relativePath))
			return
		}
		result.addError("service %s cannot inspect %s ./%s: %v", serviceName, label, filepath.ToSlash(relativePath), err)
		return
	}
	validType := fileInfo.Mode().IsRegular() || (allowDirectory && fileInfo.IsDir())
	if !validType || fileInfo.Mode()&os.ModeSymlink != 0 {
		result.addError("service %s %s must be a regular non-symlink%s: ./%s", serviceName, label, map[bool]string{true: " file or directory", false: " file"}[allowDirectory], filepath.ToSlash(relativePath))
	}
}

func validateVolume(
	serviceName string,
	volume string,
	declaredVolumes map[string]yaml.Node,
	composeDirectory string,
	caddyStorageSources map[string]struct{},
	result *Result,
) {
	parts := strings.Split(volume, ":")
	if len(parts) < 2 || len(parts) > 3 || strings.TrimSpace(parts[0]) == "" || !path.IsAbs(parts[1]) {
		result.addError("service %s volume %q must use canonical short source:target[:options] syntax", serviceName, volume)
		return
	}
	source := parts[0]
	target := parts[1]
	if strings.HasPrefix(source, ".") {
		relativePath, err := canonicalRelativePath(source)
		if err != nil {
			result.addError("service %s bind source %s", serviceName, err)
			return
		}
		validateLocalSource(serviceName, "bind source", composeDirectory, relativePath, true, result)
	} else {
		if path.IsAbs(source) || !dockerNamePattern.MatchString(source) {
			result.addError("service %s volume source %q must be a declared named volume or canonical ./-relative bind", serviceName, source)
			return
		}
		if _, found := declaredVolumes[source]; !found {
			result.addError("service %s uses undeclared named volume %s", serviceName, source)
		}
	}
	if serviceName != "caddy" && isCaddyStorage(source, target, caddyStorageSources) {
		result.addError("service %s must not mount Caddy-owned storage %s:%s", serviceName, source, target)
	}
}

func isCaddyStorage(source string, target string, caddyStorageSources map[string]struct{}) bool {
	if _, found := caddyStorageSources[source]; found {
		return true
	}
	normalizedSource := strings.ToLower(source)
	return strings.HasPrefix(normalizedSource, "caddy-") ||
		isCaddyPrivateTarget(target)
}

func isCaddyOwnedTarget(target string) bool {
	normalizedTarget := strings.ToLower(target)
	return normalizedTarget == "/data" ||
		normalizedTarget == "/config" ||
		strings.HasPrefix(normalizedTarget, "/etc/caddy")
}

func isCaddyPrivateTarget(target string) bool {
	normalizedTarget := strings.ToLower(target)
	return strings.HasPrefix(normalizedTarget, "/etc/caddy") ||
		strings.HasPrefix(normalizedTarget, "/data/caddy") ||
		strings.HasPrefix(normalizedTarget, "/config/caddy")
}

func validateApplicationPort(serviceName string, value string, published bool, result *Result) {
	normalizedValue := strings.TrimSpace(value)
	if normalizedValue != value {
		result.addError("service %s port %q must be canonical", serviceName, value)
		return
	}
	portMapping := strings.TrimSuffix(strings.TrimSuffix(normalizedValue, "/tcp"), "/udp")
	parts := strings.Split(portMapping, ":")
	containerPort, err := parsePort(parts[len(parts)-1])
	if err != nil {
		result.addError("service %s port %q must end in one numeric container port", serviceName, value)
		return
	}
	if _, tlsPort := tlsListenerPorts[containerPort]; tlsPort {
		result.addError("service %s must not own TLS listener port %d", serviceName, containerPort)
	}
	if !published || len(parts) < 2 {
		return
	}
	hostPort, hostPortErr := parsePort(parts[len(parts)-2])
	if hostPortErr == nil {
		if _, tlsPort := tlsListenerPorts[hostPort]; tlsPort {
			result.addError("service %s must not publish Caddy TLS listener port %d", serviceName, hostPort)
		}
	}
}

func parsePort(value string) (int, error) {
	portNumber, err := strconv.Atoi(value)
	if err != nil || portNumber < 1 || portNumber > 65535 {
		return 0, errors.New("port must be an integer from 1 through 65535")
	}
	return portNumber, nil
}

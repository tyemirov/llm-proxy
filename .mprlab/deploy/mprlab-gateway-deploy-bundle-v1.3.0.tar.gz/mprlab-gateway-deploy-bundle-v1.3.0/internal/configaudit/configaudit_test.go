package configaudit

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"
)

func TestRepoLLMProxyDeploymentContract(t *testing.T) {
	repoRoot := filepath.Clean(filepath.Join("..", ".."))
	composeBytes, err := os.ReadFile(filepath.Join(repoRoot, "docker-compose.yml"))
	if err != nil {
		t.Fatalf("read gateway Compose: %v", err)
	}
	var compose composeDocument
	if err := yaml.Unmarshal(composeBytes, &compose); err != nil {
		t.Fatalf("parse gateway Compose: %v", err)
	}
	service, found := compose.Services["llm-proxy"]
	if !found || strings.TrimSpace(service.Image) != "${MPRLAB_LLM_PROXY_IMAGE_REF:?MPRLAB_LLM_PROXY_IMAGE_REF is required}" {
		t.Fatalf("expected the gateway to require an explicit llm-proxy image reference, got %#v", service)
	}

	groupVarsDocument, err := os.ReadFile(filepath.Join(repoRoot, "deploy", "ansible", "inventory", "group_vars", "gateway.yml"))
	if err != nil {
		t.Fatalf("read gateway inventory: %v", err)
	}
	var groupVars struct {
		LLMProxyImageRef string            `yaml:"mprlab_llm_proxy_image_ref"`
		ComposeCLIEnv    map[string]string `yaml:"mprlab_compose_cli_env"`
		Profiles         map[string]struct {
			Services          []string `yaml:"services"`
			RuntimeAssetPaths []string `yaml:"runtime_asset_paths"`
		} `yaml:"mprlab_gateway_target_profiles"`
	}
	if err := yaml.Unmarshal(groupVarsDocument, &groupVars); err != nil {
		t.Fatalf("parse gateway inventory: %v", err)
	}
	if groupVars.LLMProxyImageRef != "ghcr.io/tyemirov/llm-proxy:latest" {
		t.Fatalf("unexpected aggregate llm-proxy image default: %q", groupVars.LLMProxyImageRef)
	}
	if groupVars.ComposeCLIEnv["MPRLAB_LLM_PROXY_IMAGE_REF"] != "{{ mprlab_llm_proxy_image_ref }}" {
		t.Fatalf("gateway Compose environment does not bind the selected llm-proxy image: %#v", groupVars.ComposeCLIEnv)
	}
	profile, found := groupVars.Profiles["llm-proxy"]
	if !found {
		t.Fatal("expected llm-proxy gateway target profile")
	}
	for _, serviceName := range []string{"caddy", "tauth-api", "llm-proxy"} {
		if !contains(profile.Services, serviceName) {
			t.Fatalf("llm-proxy target profile is missing service %s: %#v", serviceName, profile.Services)
		}
	}
	for _, assetPath := range []string{
		"../llm-proxy/.mprlab/deploy/.env",
		"../llm-proxy/configs/config.yml",
		"configs/.env.tauth",
		"configs/config.tauth.yml",
	} {
		if !contains(profile.RuntimeAssetPaths, assetPath) {
			t.Fatalf("llm-proxy target profile is missing runtime asset %s: %#v", assetPath, profile.RuntimeAssetPaths)
		}
	}
}

func TestRepoDeployObservesDeclaredContainerReadinessEvents(t *testing.T) {
	repoRoot := filepath.Clean(filepath.Join("..", ".."))
	groupVarsBytes, readGroupVarsErr := os.ReadFile(filepath.Join(repoRoot, "deploy", "ansible", "inventory", "group_vars", "gateway.yml"))
	if readGroupVarsErr != nil {
		t.Fatalf("read gateway inventory: %v", readGroupVarsErr)
	}
	var groupVars map[string]any
	if unmarshalErr := yaml.Unmarshal(groupVarsBytes, &groupVars); unmarshalErr != nil {
		t.Fatalf("parse gateway inventory: %v", unmarshalErr)
	}
	if _, found := groupVars["mprlab_gateway_deploy_port_wait_timeout_seconds"]; found {
		t.Fatal("gateway inventory must not model readiness as a deploy port-wait duration")
	}

	deployPlaybookBytes, readPlaybookErr := os.ReadFile(filepath.Join(repoRoot, "deploy", "ansible", "playbooks", "deploy.yml"))
	if readPlaybookErr != nil {
		t.Fatalf("read gateway deploy playbook: %v", readPlaybookErr)
	}
	var plays []struct {
		Name  string           `yaml:"name"`
		Vars  map[string]any   `yaml:"vars"`
		Tasks []map[string]any `yaml:"tasks"`
	}
	if unmarshalErr := yaml.Unmarshal(deployPlaybookBytes, &plays); unmarshalErr != nil {
		t.Fatalf("parse gateway deploy playbook: %v", unmarshalErr)
	}

	readinessPlayContracts := []struct {
		playName               string
		selectionTaskName      string
		readinessResourceFact  string
		hostGroup              string
		dispatchSelection      string
		resourceServiceNames   string
		serviceSelection       string
		observeTaskName        string
		waitTaskName           string
		readinessHostPortsFact string
	}{
		{
			playName:               "Deploy computercat stack",
			selectionTaskName:      "Select computercat container readiness event resources",
			readinessResourceFact:  "mprlab_computercat_container_readiness_resources_effective",
			hostGroup:              "computercat",
			dispatchSelection:      "mprlab_computercat_resource_dispatch_targets_effective",
			resourceServiceNames:   "mprlab_computercat_target_services_effective",
			serviceSelection:       "mprlab_computercat_deploy_services_effective",
			observeTaskName:        "Observe computercat container readiness events",
			waitTaskName:           "Wait for computercat published ports without readiness events",
			readinessHostPortsFact: "mprlab_computercat_readiness_event_host_ports_effective",
		},
		{
			playName:               "Deploy gateway stack",
			selectionTaskName:      "Select gateway container readiness event resources",
			readinessResourceFact:  "mprlab_gateway_container_readiness_resources_effective",
			hostGroup:              "gateway",
			dispatchSelection:      "mprlab_gateway_resource_dispatch_targets_effective",
			resourceServiceNames:   "mprlab_gateway_target_services_effective",
			serviceSelection:       "mprlab_gateway_deploy_services_effective",
			observeTaskName:        "Observe gateway container readiness events",
			waitTaskName:           "Wait for gateway published ports without readiness events",
			readinessHostPortsFact: "mprlab_gateway_readiness_event_host_ports_effective",
		},
	}

	for _, readinessPlayContract := range readinessPlayContracts {
		var readinessPlay *struct {
			Name  string           `yaml:"name"`
			Vars  map[string]any   `yaml:"vars"`
			Tasks []map[string]any `yaml:"tasks"`
		}
		for playIndex := range plays {
			if plays[playIndex].Name == readinessPlayContract.playName {
				readinessPlay = &plays[playIndex]
				break
			}
		}
		if readinessPlay == nil {
			t.Fatalf("deploy playbook is missing %s play", readinessPlayContract.playName)
		}
		if _, found := readinessPlay.Vars["mprlab_app_repo_parent_effective"]; !found {
			t.Fatalf("%s must define the app repository parent used to load readiness owners", readinessPlayContract.playName)
		}

		foundLoad := false
		foundSelection := false
		foundObserve := false
		foundEventPortExclusion := false
		for _, task := range readinessPlay.Tasks {
			switch task["name"] {
			case "Load app-owned container readiness resources":
				taskVars, ok := task["vars"].(map[string]any)
				if !ok {
					t.Fatalf("%s readiness loader must define task vars", readinessPlayContract.playName)
				}
				dispatchTargets, ok := taskVars["mprlab_app_resource_dispatch_targets"].(string)
				if !ok || !strings.Contains(dispatchTargets, readinessPlayContract.dispatchSelection) {
					t.Fatalf("%s readiness loader dispatch selection = %#v", readinessPlayContract.playName, taskVars["mprlab_app_resource_dispatch_targets"])
				}
				serviceNames, ok := taskVars["mprlab_app_resource_service_names"].(string)
				if !ok || !strings.Contains(serviceNames, readinessPlayContract.resourceServiceNames) {
					t.Fatalf("%s readiness loader service selection = %#v", readinessPlayContract.playName, taskVars["mprlab_app_resource_service_names"])
				}
				foundLoad = true
			case readinessPlayContract.selectionTaskName:
				setFact, ok := task["ansible.builtin.set_fact"].(map[string]any)
				if !ok {
					t.Fatalf("%s readiness selection must use ansible.builtin.set_fact", readinessPlayContract.playName)
				}
				selection, ok := setFact[readinessPlayContract.readinessResourceFact].(string)
				if !ok {
					t.Fatalf("%s readiness resource selection = %#v", readinessPlayContract.playName, setFact[readinessPlayContract.readinessResourceFact])
				}
				for _, expectedSelection := range []string{
					"mprlab_resource_plan_items_effective",
					"selectattr('1.host_group', 'equalto', '" + readinessPlayContract.hostGroup + "')",
					"selectattr('1.readiness_event', 'defined')",
					"selectattr('1.name', 'in', " + readinessPlayContract.serviceSelection + ")",
				} {
					if !strings.Contains(selection, expectedSelection) {
						t.Fatalf("%s readiness selection is missing %q: %s", readinessPlayContract.playName, expectedSelection, selection)
					}
				}
				foundSelection = true
			case readinessPlayContract.observeTaskName:
				script, ok := task["ansible.builtin.script"].(map[string]any)
				if !ok {
					t.Fatal("container readiness event observation must use ansible.builtin.script")
				}
				command, ok := script["cmd"].(string)
				if !ok || !strings.Contains(command, "observe-container-readiness-event.py") {
					t.Fatalf("container readiness event observer command = %#v", script["cmd"])
				}
				foundObserve = true
			case readinessPlayContract.waitTaskName:
				loop, ok := task["loop"].(string)
				if !ok || !strings.Contains(loop, "difference("+readinessPlayContract.readinessHostPortsFact+")") {
					t.Fatalf("published-port wait must exclude readiness-event-owned ports, got %#v", task["loop"])
				}
				foundEventPortExclusion = true
			}
		}
		if !foundLoad || !foundSelection || !foundObserve || !foundEventPortExclusion {
			t.Fatalf("%s readiness tasks load=%t select=%t observe=%t exclude_event_ports=%t", readinessPlayContract.playName, foundLoad, foundSelection, foundObserve, foundEventPortExclusion)
		}
	}
}

func TestRepoTargetDeployReplacesOwnedServiceBeforeReadinessAndDoesNotRewaitEventPorts(t *testing.T) {
	repoRoot := filepath.Clean(filepath.Join("..", ".."))
	deployPlaybookBytes, readDeployErr := os.ReadFile(filepath.Join(repoRoot, "deploy", "ansible", "playbooks", "deploy.yml"))
	if readDeployErr != nil {
		t.Fatalf("read gateway deploy playbook: %v", readDeployErr)
	}
	verifyPlaybookBytes, readVerifyErr := os.ReadFile(filepath.Join(repoRoot, "deploy", "ansible", "playbooks", "verify.yml"))
	if readVerifyErr != nil {
		t.Fatalf("read gateway verify playbook: %v", readVerifyErr)
	}

	var deployPlays []struct {
		Name  string           `yaml:"name"`
		Tasks []map[string]any `yaml:"tasks"`
	}
	if unmarshalErr := yaml.Unmarshal(deployPlaybookBytes, &deployPlays); unmarshalErr != nil {
		t.Fatalf("parse gateway deploy playbook: %v", unmarshalErr)
	}
	var gatewayDeployTasks []map[string]any
	for _, deployPlay := range deployPlays {
		if deployPlay.Name == "Deploy gateway stack" {
			gatewayDeployTasks = deployPlay.Tasks
			break
		}
	}
	if gatewayDeployTasks == nil {
		t.Fatal("deploy playbook is missing Deploy gateway stack play")
	}

	selectionTaskIndex := -1
	supportStartTaskIndex := -1
	replacementTaskIndex := -1
	readinessTaskIndex := -1
	for taskIndex, task := range gatewayDeployTasks {
		switch task["name"] {
		case "Select selected app-owned gateway replacement resources":
			setFact, ok := task["ansible.builtin.set_fact"].(map[string]any)
			if !ok {
				t.Fatal("selected app-owned gateway service selection must use ansible.builtin.set_fact")
			}
			selection, ok := setFact["mprlab_gateway_selected_app_resources_effective"].(string)
			if !ok {
				t.Fatalf("selected app-owned gateway resources = %#v", setFact["mprlab_gateway_selected_app_resources_effective"])
			}
			for _, requiredSelection := range []string{
				"mprlab_gateway_target_profile_effective_name",
				"selectattr('0.repo.dispatch_target', 'equalto', mprlab_gateway_target_profile_effective_name)",
				"selectattr('1.type', 'equalto', 'container_service')",
				"selectattr('1.host_group', 'equalto', 'gateway')",
				"selectattr('1.name', 'in', mprlab_gateway_deploy_services_effective)",
			} {
				if !strings.Contains(selection, requiredSelection) {
					t.Fatalf("selected app-owned gateway service selection is missing %q: %s", requiredSelection, selection)
				}
			}
			selectionTaskIndex = taskIndex
		case "Start gateway compose project":
			compose, ok := task["community.docker.docker_compose_v2"].(map[string]any)
			if !ok {
				t.Fatal("gateway support service start must use community.docker.docker_compose_v2")
			}
			services, ok := compose["services"].(string)
			if !ok || !strings.Contains(services, "mprlab_gateway_support_services_effective") {
				t.Fatalf("gateway support service start services = %#v", compose["services"])
			}
			dependencies, ok := compose["dependencies"].(string)
			if !ok || !strings.Contains(dependencies, "false if") {
				t.Fatalf("gateway support service start dependencies = %#v", compose["dependencies"])
			}
			supportStartTaskIndex = taskIndex
		case "Recreate selected app-owned gateway services":
			compose, ok := task["community.docker.docker_compose_v2"].(map[string]any)
			if !ok {
				t.Fatal("selected app-owned gateway replacement must use community.docker.docker_compose_v2")
			}
			if compose["recreate"] != "always" {
				t.Fatalf("selected app-owned gateway replacement recreate = %#v", compose["recreate"])
			}
			if compose["dependencies"] != false {
				t.Fatalf("selected app-owned gateway replacement dependencies = %#v", compose["dependencies"])
			}
			services, ok := compose["services"].(string)
			if !ok || !strings.Contains(services, "mprlab_gateway_selected_app_services_effective") {
				t.Fatalf("selected app-owned gateway replacement services = %#v", compose["services"])
			}
			replacementTaskIndex = taskIndex
		case "Observe gateway container readiness events":
			readinessTaskIndex = taskIndex
		}
	}
	if selectionTaskIndex < 0 || supportStartTaskIndex < 0 || replacementTaskIndex < 0 || readinessTaskIndex < 0 {
		t.Fatalf(
			"gateway replacement/readiness tasks selection=%d support_start=%d replacement=%d readiness=%d",
			selectionTaskIndex,
			supportStartTaskIndex,
			replacementTaskIndex,
			readinessTaskIndex,
		)
	}
	if !(selectionTaskIndex < supportStartTaskIndex && supportStartTaskIndex < replacementTaskIndex && replacementTaskIndex < readinessTaskIndex) {
		t.Fatalf(
			"gateway target replacement must precede readiness observation: selection=%d support_start=%d replacement=%d readiness=%d",
			selectionTaskIndex,
			supportStartTaskIndex,
			replacementTaskIndex,
			readinessTaskIndex,
		)
	}

	var verifyPlays []struct {
		Name  string           `yaml:"name"`
		Tasks []map[string]any `yaml:"tasks"`
	}
	if unmarshalErr := yaml.Unmarshal(verifyPlaybookBytes, &verifyPlays); unmarshalErr != nil {
		t.Fatalf("parse gateway verify playbook: %v", unmarshalErr)
	}
	var gatewayVerifyTasks []map[string]any
	for _, verifyPlay := range verifyPlays {
		if verifyPlay.Name == "Verify gateway deployment surfaces" {
			gatewayVerifyTasks = verifyPlay.Tasks
			break
		}
	}
	if gatewayVerifyTasks == nil {
		t.Fatal("verify playbook is missing Verify gateway deployment surfaces play")
	}

	foundVerificationResourceSelection := false
	foundEventPortExclusion := false
	for _, task := range gatewayVerifyTasks {
		switch task["name"] {
		case "Select gateway verification readiness event resources":
			setFact, ok := task["ansible.builtin.set_fact"].(map[string]any)
			if !ok {
				t.Fatal("gateway verification readiness selection must use ansible.builtin.set_fact")
			}
			selection, ok := setFact["mprlab_gateway_verification_readiness_resources_effective"].(string)
			if !ok || !strings.Contains(selection, "selectattr('1.readiness_event', 'defined')") {
				t.Fatalf("gateway verification readiness selection = %#v", setFact["mprlab_gateway_verification_readiness_resources_effective"])
			}
			foundVerificationResourceSelection = true
		case "Verify gateway published ports without readiness events":
			loop, ok := task["loop"].(string)
			if !ok || !strings.Contains(loop, "difference(mprlab_gateway_verification_readiness_host_ports_effective)") {
				t.Fatalf("gateway verification port check must exclude event-owned ports, got %#v", task["loop"])
			}
			foundEventPortExclusion = true
		case "Wait for gateway published ports":
			t.Fatal("gateway verification must not retain the blind published-port wait")
		}
	}
	if !foundVerificationResourceSelection || !foundEventPortExclusion {
		t.Fatalf(
			"gateway verification readiness resources=%t exclude_event_ports=%t",
			foundVerificationResourceSelection,
			foundEventPortExclusion,
		)
	}
}

func contains(values []string, expected string) bool {
	for _, value := range values {
		if value == expected {
			return true
		}
	}
	return false
}

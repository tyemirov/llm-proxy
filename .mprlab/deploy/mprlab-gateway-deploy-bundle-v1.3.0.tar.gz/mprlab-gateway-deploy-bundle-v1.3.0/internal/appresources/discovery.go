// Package appresources discovers committed app-owned deployment manifests.
package appresources

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"gopkg.in/yaml.v3"
)

const (
	manifestRelativePath        = ".mprlab/deploy/resources.yml"
	schemaVersionCurrent        = 1
	ignoredReasonDuplicateClone = "duplicate_clone"
	ignoredReasonLinkedWorktree = "linked_worktree"
)

var dispatchTargetPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9-]*$`)
var repositoryNamePattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]*$`)
var resourceTypePattern = regexp.MustCompile(`^[a-z][a-z0-9_]*$`)

// IsCanonicalDispatchTarget reports whether a value satisfies the current
// app-owned dispatch-target contract.
func IsCanonicalDispatchTarget(value string) bool {
	return dispatchTargetPattern.MatchString(value)
}

type repository struct {
	id                 string
	directory          string
	dispatchTarget     string
	path               string
	manifestPath       string
	manifestYAML       string
	manifest           manifestDocument
	headCommit         string
	gitCommonDirectory string
	originFingerprint  string
	readinessReasons   []string
}

type repositorySelection struct {
	dispatchTargets map[string]struct{}
	serviceNames    map[string]struct{}
}

type ignoredCheckout struct {
	path               string
	canonicalPath      string
	gitCommonDirectory string
	originFingerprint  string
	reason             string
}

type discovery struct {
	repositories     []repository
	ignoredCheckouts []ignoredCheckout
}

type repositoryJSON struct {
	ID                 string   `json:"id"`
	Directory          string   `json:"directory"`
	DispatchTarget     string   `json:"dispatch_target"`
	Path               string   `json:"path"`
	ManifestPath       string   `json:"manifest_path"`
	ManifestYAML       string   `json:"manifest_yaml"`
	HeadCommit         string   `json:"head_commit"`
	GitCommonDirectory string   `json:"git_common_directory"`
	OriginFingerprint  string   `json:"origin_fingerprint"`
	Ready              bool     `json:"ready"`
	ReadinessReasons   []string `json:"readiness_reasons"`
}

type ignoredCheckoutJSON struct {
	Path               string `json:"path"`
	CanonicalPath      string `json:"canonical_path,omitempty"`
	GitCommonDirectory string `json:"git_common_directory"`
	OriginFingerprint  string `json:"origin_fingerprint,omitempty"`
	Reason             string `json:"reason"`
}

type discoveryJSON struct {
	SchemaVersion    int                   `json:"schema_version"`
	Repositories     []repositoryJSON      `json:"repositories"`
	IgnoredCheckouts []ignoredCheckoutJSON `json:"ignored_checkouts"`
}

type manifestDocument struct {
	Resources manifestResources `yaml:"mprlab_resources"`
}

type manifestResources struct {
	SchemaVersion int                `yaml:"schema_version"`
	Repo          manifestRepository `yaml:"repo"`
	Items         []map[string]any   `yaml:"resources"`
}

type manifestRepository struct {
	ID             string `yaml:"id"`
	Directory      string `yaml:"directory"`
	DispatchTarget string `yaml:"dispatch_target"`
}

type checkoutCandidate struct {
	path               string
	gitDirectory       string
	gitCommonDirectory string
	repositoryOrigin   string
	primary            bool
}

// RepositorySnapshot exposes one immutable canonical repository without an invalid exported value.
type RepositorySnapshot interface {
	ID() string
	Directory() string
	DispatchTarget() string
	Path() string
	ManifestPath() string
	ManifestYAML() string
	HeadCommit() string
	Ready() bool
	ReadinessReasons() []string
}

// Discover returns an immutable inventory of every canonical checkout and its committed manifest bytes.
func Discover(ctx context.Context, repoParents []string) (discovery, error) {
	return discover(ctx, repoParents, nil)
}

// DiscoverSelected returns only the requested dispatch targets and repositories
// that own selected container services.
func DiscoverSelected(
	ctx context.Context,
	repoParents []string,
	dispatchTargets []string,
	serviceNames []string,
) (discovery, error) {
	selection, selectionErr := newRepositorySelection(dispatchTargets, serviceNames)
	if selectionErr != nil {
		return discovery{}, selectionErr
	}
	return discover(ctx, repoParents, &selection)
}

func discover(
	ctx context.Context,
	repoParents []string,
	selection *repositorySelection,
) (discovery, error) {
	canonicalParents, parentErr := canonicalRepoParents(repoParents)
	if parentErr != nil {
		return discovery{}, parentErr
	}
	candidates, candidateErr := discoverCheckoutCandidates(ctx, canonicalParents)
	if candidateErr != nil {
		return discovery{}, candidateErr
	}
	if selection != nil {
		selectedCandidates, selectionErr := selection.selectCheckoutCandidates(
			ctx,
			candidates,
		)
		if selectionErr != nil {
			return discovery{}, selectionErr
		}
		candidates = selectedCandidates
	}
	canonicalCandidates, ignoredCheckouts, selectionErr := selectCanonicalCheckouts(ctx, candidates)
	if selectionErr != nil {
		return discovery{}, selectionErr
	}

	discoveredInventory := discovery{
		repositories:     make([]repository, 0),
		ignoredCheckouts: ignoredCheckouts,
	}
	seenRepositoryIDs := make(map[string]string)
	seenDispatchTargets := make(map[string]string)
	for _, candidate := range canonicalCandidates {
		repository, present, repositoryErr := loadCanonicalRepository(ctx, candidate)
		if repositoryErr != nil {
			return discovery{}, repositoryErr
		}
		if !present {
			continue
		}
		if otherPath, duplicate := seenRepositoryIDs[repository.id]; duplicate {
			return discovery{}, fmt.Errorf("duplicate app repository id %q in %s and %s", repository.id, otherPath, repository.path)
		}
		if otherPath, duplicate := seenDispatchTargets[repository.dispatchTarget]; duplicate {
			return discovery{}, fmt.Errorf("duplicate app dispatch target %q in %s and %s", repository.dispatchTarget, otherPath, repository.path)
		}
		seenRepositoryIDs[repository.id] = repository.path
		seenDispatchTargets[repository.dispatchTarget] = repository.path
		discoveredInventory.repositories = append(discoveredInventory.repositories, repository)
	}
	if selection != nil {
		selectedRepositories, selectionErr := selection.selectRepositories(
			discoveredInventory.repositories,
		)
		if selectionErr != nil {
			return discovery{}, selectionErr
		}
		discoveredInventory.repositories = selectedRepositories
		discoveredInventory.ignoredCheckouts = selectIgnoredCheckouts(
			discoveredInventory.ignoredCheckouts,
			selectedRepositories,
		)
	}
	for repositoryIndex := range discoveredInventory.repositories {
		discoveredRepository := &discoveredInventory.repositories[repositoryIndex]
		readinessReasons, readinessErr := inspectRepositoryReadiness(
			ctx,
			discoveredRepository.path,
			discoveredRepository.manifestPath,
			discoveredRepository.headCommit,
			[]byte(discoveredRepository.manifestYAML),
			discoveredRepository.manifest,
		)
		if readinessErr != nil {
			return discovery{}, readinessErr
		}
		discoveredRepository.readinessReasons = readinessReasons
	}

	sort.Slice(discoveredInventory.repositories, func(leftIndex int, rightIndex int) bool {
		return discoveredInventory.repositories[leftIndex].id < discoveredInventory.repositories[rightIndex].id
	})
	sort.Slice(discoveredInventory.ignoredCheckouts, func(leftIndex int, rightIndex int) bool {
		return discoveredInventory.ignoredCheckouts[leftIndex].path < discoveredInventory.ignoredCheckouts[rightIndex].path
	})
	return discoveredInventory, nil
}

func newRepositorySelection(
	dispatchTargets []string,
	serviceNames []string,
) (repositorySelection, error) {
	selection := repositorySelection{
		dispatchTargets: make(map[string]struct{}, len(dispatchTargets)),
		serviceNames:    make(map[string]struct{}, len(serviceNames)),
	}
	for _, dispatchTarget := range dispatchTargets {
		if !dispatchTargetPattern.MatchString(dispatchTarget) {
			return repositorySelection{}, fmt.Errorf(
				"selected app dispatch target %q is invalid",
				dispatchTarget,
			)
		}
		if _, duplicate := selection.dispatchTargets[dispatchTarget]; duplicate {
			return repositorySelection{}, fmt.Errorf(
				"selected app dispatch target %q is duplicated",
				dispatchTarget,
			)
		}
		selection.dispatchTargets[dispatchTarget] = struct{}{}
	}
	for _, serviceName := range serviceNames {
		if !repositoryNamePattern.MatchString(serviceName) {
			return repositorySelection{}, fmt.Errorf(
				"selected container service %q is invalid",
				serviceName,
			)
		}
		if _, duplicate := selection.serviceNames[serviceName]; duplicate {
			return repositorySelection{}, fmt.Errorf(
				"selected container service %q is duplicated",
				serviceName,
			)
		}
		selection.serviceNames[serviceName] = struct{}{}
	}
	return selection, nil
}

func (selection repositorySelection) selectCheckoutCandidates(
	ctx context.Context,
	candidates []checkoutCandidate,
) ([]checkoutCandidate, error) {
	selectedGroupKeys := make(map[string]struct{})
	for _, candidate := range candidates {
		headManifestBytes, headManifestErr := runGitBytes(
			ctx,
			candidate.path,
			"show",
			"HEAD:"+manifestRelativePath,
		)
		if headManifestErr != nil {
			if ctx.Err() != nil {
				return nil, ctx.Err()
			}
			continue
		}
		var candidateManifest manifestDocument
		selectionManifestErr := yaml.Unmarshal(headManifestBytes, &candidateManifest)
		if selectionManifestErr != nil || selection.selectsManifest(candidateManifest) {
			selectedGroupKeys[candidate.identityGroupKey()] = struct{}{}
		}
	}

	selectedCandidates := make([]checkoutCandidate, 0, len(candidates))
	for _, candidate := range candidates {
		if _, selected := selectedGroupKeys[candidate.identityGroupKey()]; selected {
			selectedCandidates = append(selectedCandidates, candidate)
		}
	}
	return selectedCandidates, nil
}

func (selection repositorySelection) selectsManifest(manifest manifestDocument) bool {
	if _, selected := selection.dispatchTargets[manifest.Resources.Repo.DispatchTarget]; selected {
		return true
	}
	for _, resource := range manifest.Resources.Items {
		resourceType, _ := resource["type"].(string)
		resourceName, _ := resource["name"].(string)
		_, serviceSelected := selection.serviceNames[resourceName]
		if resourceType == "container_service" && serviceSelected {
			return true
		}
	}
	return false
}

func (selection repositorySelection) selectRepositories(
	repositories []repository,
) ([]repository, error) {
	selectedRepositories := make([]repository, 0, len(repositories))
	matchedDispatchTargets := make(map[string]struct{}, len(selection.dispatchTargets))
	for _, discoveredRepository := range repositories {
		_, dispatchTargetSelected := selection.dispatchTargets[discoveredRepository.dispatchTarget]
		if dispatchTargetSelected {
			matchedDispatchTargets[discoveredRepository.dispatchTarget] = struct{}{}
		}
		if selection.selectsManifest(discoveredRepository.manifest) {
			selectedRepositories = append(selectedRepositories, discoveredRepository)
		}
	}
	for dispatchTarget := range selection.dispatchTargets {
		if _, matched := matchedDispatchTargets[dispatchTarget]; !matched {
			return nil, fmt.Errorf(
				"no app deploy manifest matched selected dispatch target %q",
				dispatchTarget,
			)
		}
	}
	return selectedRepositories, nil
}

func selectIgnoredCheckouts(
	ignoredCheckouts []ignoredCheckout,
	selectedRepositories []repository,
) []ignoredCheckout {
	selectedPaths := make(map[string]struct{}, len(selectedRepositories))
	for _, selectedRepository := range selectedRepositories {
		selectedPaths[selectedRepository.path] = struct{}{}
	}
	selectedIgnoredCheckouts := make([]ignoredCheckout, 0, len(ignoredCheckouts))
	for _, ignored := range ignoredCheckouts {
		if _, selected := selectedPaths[ignored.canonicalPath]; selected {
			selectedIgnoredCheckouts = append(selectedIgnoredCheckouts, ignored)
		}
	}
	return selectedIgnoredCheckouts
}

func (discoveredRepository repository) ID() string {
	return discoveredRepository.id
}

func (discoveredRepository repository) Directory() string {
	return discoveredRepository.directory
}

func (discoveredRepository repository) DispatchTarget() string {
	return discoveredRepository.dispatchTarget
}

func (discoveredRepository repository) Path() string {
	return discoveredRepository.path
}

func (discoveredRepository repository) ManifestPath() string {
	return discoveredRepository.manifestPath
}

func (discoveredRepository repository) ManifestYAML() string {
	return discoveredRepository.manifestYAML
}

func (discoveredRepository repository) HeadCommit() string {
	return discoveredRepository.headCommit
}

func (discoveredRepository repository) Ready() bool {
	return len(discoveredRepository.readinessReasons) == 0
}

func (discoveredRepository repository) ReadinessReasons() []string {
	return append([]string{}, discoveredRepository.readinessReasons...)
}

// RepositorySnapshots returns detached immutable repository views in canonical order.
func (discoveredInventory discovery) RepositorySnapshots() []RepositorySnapshot {
	snapshots := make([]RepositorySnapshot, 0, len(discoveredInventory.repositories))
	for _, discoveredRepository := range discoveredInventory.repositories {
		snapshots = append(snapshots, discoveredRepository)
	}
	return snapshots
}

func selectCanonicalCheckouts(ctx context.Context, candidates []checkoutCandidate) ([]checkoutCandidate, []ignoredCheckout, error) {
	primaryPaths := make(map[string]string)
	primaryGroups := make(map[string][]checkoutCandidate)
	groupKeys := make([]string, 0)
	linkedCandidates := make([]checkoutCandidate, 0)
	for _, candidate := range candidates {
		if !candidate.primary {
			linkedCandidates = append(linkedCandidates, candidate)
			continue
		}
		if existingPath, duplicate := primaryPaths[candidate.gitCommonDirectory]; duplicate && existingPath != candidate.path {
			return nil, nil, fmt.Errorf("git repository %s has multiple primary checkouts %s and %s", candidate.gitCommonDirectory, existingPath, candidate.path)
		}
		primaryPaths[candidate.gitCommonDirectory] = candidate.path
		groupKey := candidate.identityGroupKey()
		if _, exists := primaryGroups[groupKey]; !exists {
			groupKeys = append(groupKeys, groupKey)
		}
		primaryGroups[groupKey] = append(primaryGroups[groupKey], candidate)
	}
	sort.Strings(groupKeys)

	canonicalCandidates := make([]checkoutCandidate, 0, len(primaryGroups))
	canonicalPathsByOrigin := make(map[string]string)
	ignoredCheckouts := make([]ignoredCheckout, 0)
	for _, groupKey := range groupKeys {
		groupCandidates := primaryGroups[groupKey]
		canonicalCandidate, present, selectionErr := selectCanonicalCheckout(ctx, groupCandidates)
		if selectionErr != nil {
			return nil, nil, selectionErr
		}
		if !present {
			continue
		}
		canonicalCandidates = append(canonicalCandidates, canonicalCandidate)
		if canonicalCandidate.repositoryOrigin != "" {
			canonicalPathsByOrigin[canonicalCandidate.repositoryOrigin] = canonicalCandidate.path
		}
		for _, candidate := range groupCandidates {
			if candidate.path == canonicalCandidate.path {
				continue
			}
			ignoredCheckouts = append(ignoredCheckouts, ignoredCheckout{
				path:               candidate.path,
				canonicalPath:      canonicalCandidate.path,
				gitCommonDirectory: candidate.gitCommonDirectory,
				originFingerprint:  fingerprintOrigin(candidate.repositoryOrigin),
				reason:             ignoredReasonDuplicateClone,
			})
		}
	}

	for _, candidate := range linkedCandidates {
		canonicalPath := primaryPaths[candidate.gitCommonDirectory]
		if originPath := canonicalPathsByOrigin[candidate.repositoryOrigin]; originPath != "" {
			canonicalPath = originPath
		}
		ignoredCheckouts = append(ignoredCheckouts, ignoredCheckout{
			path:               candidate.path,
			canonicalPath:      canonicalPath,
			gitCommonDirectory: candidate.gitCommonDirectory,
			originFingerprint:  fingerprintOrigin(candidate.repositoryOrigin),
			reason:             ignoredReasonLinkedWorktree,
		})
	}
	sort.Slice(canonicalCandidates, func(leftIndex int, rightIndex int) bool {
		return canonicalCandidates[leftIndex].path < canonicalCandidates[rightIndex].path
	})
	return canonicalCandidates, ignoredCheckouts, nil
}

func (candidate checkoutCandidate) identityGroupKey() string {
	if candidate.repositoryOrigin != "" {
		return candidate.repositoryOrigin
	}
	return "\x00" + candidate.gitCommonDirectory
}

func selectCanonicalCheckout(ctx context.Context, candidates []checkoutCandidate) (checkoutCandidate, bool, error) {
	matchingCandidates := make([]checkoutCandidate, 0, 1)
	for _, candidate := range candidates {
		headManifestBytes, headManifestErr := runGitBytes(ctx, candidate.path, "show", "HEAD:"+manifestRelativePath)
		if headManifestErr != nil {
			if ctx.Err() != nil {
				return checkoutCandidate{}, false, ctx.Err()
			}
			continue
		}
		manifestPath := filepath.Join(candidate.path, manifestRelativePath)
		manifest, manifestErr := parseManifest(manifestPath, headManifestBytes)
		if manifestErr != nil {
			continue
		}
		if manifest.Resources.Repo.Directory == filepath.Base(candidate.path) {
			matchingCandidates = append(matchingCandidates, candidate)
		}
	}
	if len(matchingCandidates) > 1 {
		return checkoutCandidate{}, false, fmt.Errorf(
			"git origin %q has multiple canonical checkouts %s and %s",
			fingerprintOrigin(matchingCandidates[0].repositoryOrigin),
			matchingCandidates[0].path,
			matchingCandidates[1].path,
		)
	}
	if len(matchingCandidates) == 1 {
		return matchingCandidates[0], true, nil
	}
	for _, candidate := range candidates {
		_, present, repositoryErr := loadCanonicalRepository(ctx, candidate)
		if repositoryErr != nil {
			return checkoutCandidate{}, false, repositoryErr
		}
		if present {
			return candidate, true, nil
		}
	}
	return checkoutCandidate{}, false, nil
}

// ManifestPaths returns a detached ordered list of committed app resource manifests.
func (discoveredInventory discovery) ManifestPaths() []string {
	manifestPaths := make([]string, 0, len(discoveredInventory.repositories))
	for _, discoveredRepository := range discoveredInventory.repositories {
		manifestPaths = append(manifestPaths, discoveredRepository.manifestPath)
	}
	return manifestPaths
}

// ManifestYAML returns detached immutable manifest text keyed by canonical path.
func (discoveredInventory discovery) ManifestYAML() map[string]string {
	manifestYAML := make(map[string]string, len(discoveredInventory.repositories))
	for _, discoveredRepository := range discoveredInventory.repositories {
		manifestYAML[discoveredRepository.manifestPath] = discoveredRepository.manifestYAML
	}
	return manifestYAML
}

// MarshalJSON emits the stable discovery CLI contract without exposing mutable domain fields.
func (discoveredInventory discovery) MarshalJSON() ([]byte, error) {
	repositories := make([]repositoryJSON, 0, len(discoveredInventory.repositories))
	for _, discoveredRepository := range discoveredInventory.repositories {
		repositories = append(repositories, repositoryJSON{
			ID:                 discoveredRepository.id,
			Directory:          discoveredRepository.directory,
			DispatchTarget:     discoveredRepository.dispatchTarget,
			Path:               discoveredRepository.path,
			ManifestPath:       discoveredRepository.manifestPath,
			ManifestYAML:       discoveredRepository.manifestYAML,
			HeadCommit:         discoveredRepository.headCommit,
			GitCommonDirectory: discoveredRepository.gitCommonDirectory,
			OriginFingerprint:  discoveredRepository.originFingerprint,
			Ready:              discoveredRepository.Ready(),
			ReadinessReasons:   discoveredRepository.ReadinessReasons(),
		})
	}
	ignoredCheckouts := make([]ignoredCheckoutJSON, 0, len(discoveredInventory.ignoredCheckouts))
	for _, discoveredCheckout := range discoveredInventory.ignoredCheckouts {
		ignoredCheckouts = append(ignoredCheckouts, ignoredCheckoutJSON{
			Path:               discoveredCheckout.path,
			CanonicalPath:      discoveredCheckout.canonicalPath,
			GitCommonDirectory: discoveredCheckout.gitCommonDirectory,
			OriginFingerprint:  discoveredCheckout.originFingerprint,
			Reason:             discoveredCheckout.reason,
		})
	}
	return json.Marshal(discoveryJSON{
		SchemaVersion:    schemaVersionCurrent,
		Repositories:     repositories,
		IgnoredCheckouts: ignoredCheckouts,
	})
}

func canonicalRepoParents(repoParents []string) ([]string, error) {
	canonicalParents := make([]string, 0, len(repoParents))
	seenParents := make(map[string]struct{}, len(repoParents))
	for _, repoParent := range repoParents {
		trimmedParent := strings.TrimSpace(repoParent)
		if trimmedParent == "" || trimmedParent != repoParent {
			return nil, errors.New("app repository parent must be one non-empty canonical path")
		}
		canonicalParent, canonicalErr := canonicalDirectory(trimmedParent)
		if canonicalErr != nil {
			return nil, fmt.Errorf("resolve app repository parent %s: %w", trimmedParent, canonicalErr)
		}
		if _, duplicate := seenParents[canonicalParent]; duplicate {
			return nil, fmt.Errorf("duplicate app repository parent: %s", canonicalParent)
		}
		seenParents[canonicalParent] = struct{}{}
		canonicalParents = append(canonicalParents, canonicalParent)
	}
	if len(canonicalParents) == 0 {
		return nil, errors.New("at least one app repository parent is required")
	}
	sort.Strings(canonicalParents)
	return canonicalParents, nil
}

func canonicalDirectory(directoryPath string) (string, error) {
	absolutePath, absoluteErr := filepath.Abs(directoryPath)
	if absoluteErr != nil {
		return "", absoluteErr
	}
	resolvedPath, resolveErr := filepath.EvalSymlinks(absolutePath)
	if resolveErr != nil {
		return "", resolveErr
	}
	directoryInfo, statErr := os.Stat(resolvedPath)
	if statErr != nil {
		return "", statErr
	}
	if !directoryInfo.IsDir() {
		return "", fmt.Errorf("%s must be a directory", resolvedPath)
	}
	return filepath.Clean(resolvedPath), nil
}

func discoverCheckoutCandidates(ctx context.Context, repoParents []string) ([]checkoutCandidate, error) {
	candidates := make([]checkoutCandidate, 0)
	seenPaths := make(map[string]struct{})
	for _, repoParent := range repoParents {
		directoryEntries, readErr := os.ReadDir(repoParent)
		if readErr != nil {
			return nil, fmt.Errorf("read app repository parent %s: %w", repoParent, readErr)
		}
		for _, directoryEntry := range directoryEntries {
			if !directoryEntry.IsDir() {
				continue
			}
			repoPath, pathErr := canonicalDirectory(filepath.Join(repoParent, directoryEntry.Name()))
			if pathErr != nil {
				return nil, fmt.Errorf("resolve app repository candidate %s: %w", filepath.Join(repoParent, directoryEntry.Name()), pathErr)
			}
			if _, duplicate := seenPaths[repoPath]; duplicate {
				continue
			}
			seenPaths[repoPath] = struct{}{}
			candidate, isCheckout, candidateErr := inspectCheckout(ctx, repoPath)
			if candidateErr != nil {
				return nil, candidateErr
			}
			if isCheckout {
				candidates = append(candidates, candidate)
			}
		}
	}
	sort.Slice(candidates, func(leftIndex int, rightIndex int) bool {
		return candidates[leftIndex].path < candidates[rightIndex].path
	})
	return candidates, nil
}

func inspectCheckout(ctx context.Context, repoPath string) (checkoutCandidate, bool, error) {
	insideOutput, insideErr := runGit(ctx, repoPath, "rev-parse", "--is-inside-work-tree")
	if insideErr != nil || strings.TrimSpace(insideOutput) != "true" {
		if ctx.Err() != nil {
			return checkoutCandidate{}, false, ctx.Err()
		}
		return checkoutCandidate{}, false, nil
	}
	topLevelOutput, topLevelErr := runGit(ctx, repoPath, "rev-parse", "--show-toplevel")
	if topLevelErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git top level for %s: %w", repoPath, topLevelErr)
	}
	topLevelPath, topLevelPathErr := canonicalDirectory(strings.TrimSpace(topLevelOutput))
	if topLevelPathErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git top level for %s: %w", repoPath, topLevelPathErr)
	}
	if topLevelPath != repoPath {
		return checkoutCandidate{}, false, nil
	}
	gitDirectoryOutput, gitDirectoryErr := runGit(ctx, repoPath, "rev-parse", "--path-format=absolute", "--git-dir")
	if gitDirectoryErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git directory for %s: %w", repoPath, gitDirectoryErr)
	}
	gitCommonOutput, gitCommonErr := runGit(ctx, repoPath, "rev-parse", "--path-format=absolute", "--git-common-dir")
	if gitCommonErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git common directory for %s: %w", repoPath, gitCommonErr)
	}
	gitDirectory, gitDirectoryResolveErr := canonicalDirectory(strings.TrimSpace(gitDirectoryOutput))
	if gitDirectoryResolveErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git directory for %s: %w", repoPath, gitDirectoryResolveErr)
	}
	gitCommonDirectory, gitCommonResolveErr := canonicalDirectory(strings.TrimSpace(gitCommonOutput))
	if gitCommonResolveErr != nil {
		return checkoutCandidate{}, false, fmt.Errorf("resolve Git common directory for %s: %w", repoPath, gitCommonResolveErr)
	}
	repositoryOrigin, originErr := exactRepositoryOrigin(ctx, repoPath)
	if originErr != nil {
		return checkoutCandidate{}, false, originErr
	}
	return checkoutCandidate{
		path:               repoPath,
		gitDirectory:       gitDirectory,
		gitCommonDirectory: gitCommonDirectory,
		repositoryOrigin:   repositoryOrigin,
		primary:            gitDirectory == gitCommonDirectory,
	}, true, nil
}

func loadCanonicalRepository(ctx context.Context, candidate checkoutCandidate) (repository, bool, error) {
	manifestPath := filepath.Join(candidate.path, manifestRelativePath)
	headCommitOutput, headCommitErr := runGit(
		ctx,
		candidate.path,
		"rev-parse",
		"--verify",
		"HEAD^{commit}",
	)
	if headCommitErr != nil {
		return repository{}, false, fmt.Errorf("resolve HEAD for %s: %w", candidate.path, headCommitErr)
	}
	headCommit := strings.TrimSpace(headCommitOutput)
	headManifestBytes, headManifestErr := runGitBytes(
		ctx,
		candidate.path,
		"show",
		headCommit+":"+manifestRelativePath,
	)
	if headManifestErr != nil {
		if _, statErr := os.Stat(manifestPath); statErr == nil {
			return repository{}, false, fmt.Errorf("deployment manifest is not committed at HEAD: %s", manifestPath)
		} else if !os.IsNotExist(statErr) {
			return repository{}, false, fmt.Errorf("inspect deployment manifest %s: %w", manifestPath, statErr)
		}
		return repository{}, false, nil
	}
	manifest, manifestErr := parseManifest(manifestPath, headManifestBytes)
	if manifestErr != nil {
		return repository{}, false, manifestErr
	}
	if candidate.repositoryOrigin == "" {
		return repository{}, false, fmt.Errorf("app repository %s must configure one exact origin remote", candidate.path)
	}
	if manifest.Resources.Repo.Directory != filepath.Base(candidate.path) {
		return repository{}, false, fmt.Errorf("app manifest %s repo.directory %q must equal primary checkout directory %q", manifestPath, manifest.Resources.Repo.Directory, filepath.Base(candidate.path))
	}
	return repository{
		id:                 manifest.Resources.Repo.ID,
		directory:          manifest.Resources.Repo.Directory,
		dispatchTarget:     manifest.Resources.Repo.DispatchTarget,
		path:               candidate.path,
		manifestPath:       manifestPath,
		manifestYAML:       string(headManifestBytes),
		manifest:           manifest,
		headCommit:         headCommit,
		gitCommonDirectory: candidate.gitCommonDirectory,
		originFingerprint:  fingerprintOrigin(candidate.repositoryOrigin),
	}, true, nil
}

func inspectRepositoryReadiness(
	ctx context.Context,
	repositoryPath string,
	manifestPath string,
	headCommit string,
	headManifestBytes []byte,
	manifest manifestDocument,
) ([]string, error) {
	readinessReasons, manifestErr := inspectWorkingManifest(manifestPath, headManifestBytes)
	if manifestErr != nil {
		return nil, manifestErr
	}
	for _, resource := range manifest.Resources.Items {
		resourceType, _ := resource["type"].(string)
		switch resourceType {
		case "container_service":
			runtimeAssets, _ := resource["runtime_assets"].([]any)
			for _, runtimeAssetValue := range runtimeAssets {
				runtimeAsset, _ := runtimeAssetValue.(map[string]any)
				runtimePath, runtimePathValid := canonicalManifestPath(runtimeAsset["path"])
				if !runtimePathValid {
					continue
				}
				if isEnvironmentPath(runtimePath) {
					environmentReasons, environmentErr := inspectRuntimeEnvironmentAsset(
						ctx,
						repositoryPath,
						headCommit,
						runtimePath,
						runtimeAsset,
					)
					if environmentErr != nil {
						return nil, environmentErr
					}
					readinessReasons = append(readinessReasons, environmentReasons...)
					continue
				}
				runtimeReasons, runtimeErr := inspectCommittedWorkingFile(
					ctx,
					repositoryPath,
					headCommit,
					runtimePath,
					"tracked runtime asset",
					0,
				)
				if runtimeErr != nil {
					return nil, runtimeErr
				}
				readinessReasons = append(readinessReasons, runtimeReasons...)
			}
		case "ansible_task_bundle":
			entrypoints, _ := resource["entrypoints"].(map[string]any)
			for _, entrypointValue := range entrypoints {
				entrypointPath, entrypointPathValid := canonicalManifestPath(entrypointValue)
				if !entrypointPathValid ||
					!strings.HasPrefix(entrypointPath, ".mprlab/deploy/") ||
					!strings.HasSuffix(entrypointPath, ".yml") {
					continue
				}
				entrypointReasons, entrypointErr := inspectCommittedWorkingFile(
					ctx,
					repositoryPath,
					headCommit,
					entrypointPath,
					"Ansible task entrypoint",
					0,
				)
				if entrypointErr != nil {
					return nil, entrypointErr
				}
				readinessReasons = append(readinessReasons, entrypointReasons...)
			}
		}
	}
	readinessReasons = uniqueSortedStrings(readinessReasons)
	return readinessReasons, nil
}

func inspectWorkingManifest(manifestPath string, headManifestBytes []byte) ([]string, error) {
	manifestInfo, manifestInfoErr := os.Lstat(manifestPath)
	if manifestInfoErr != nil {
		if os.IsNotExist(manifestInfoErr) {
			return []string{"deployment manifest is missing from the working tree: " + manifestRelativePath}, nil
		}
		return nil, fmt.Errorf("inspect committed deployment manifest %s: %w", manifestPath, manifestInfoErr)
	}
	if !manifestInfo.Mode().IsRegular() || manifestInfo.Mode()&os.ModeSymlink != 0 {
		return []string{"deployment manifest must be a regular non-symlink file: " + manifestRelativePath}, nil
	}
	workingManifestBytes, readErr := os.ReadFile(manifestPath)
	if readErr != nil {
		return nil, fmt.Errorf("read committed deployment manifest %s: %w", manifestPath, readErr)
	}
	if !bytes.Equal(headManifestBytes, workingManifestBytes) {
		return []string{"deployment manifest differs from HEAD: " + manifestRelativePath}, nil
	}
	return []string{}, nil
}

func inspectRuntimeEnvironmentAsset(
	ctx context.Context,
	repositoryPath string,
	headCommit string,
	runtimePath string,
	runtimeAsset map[string]any,
) ([]string, error) {
	reasons := make([]string, 0)
	assetInfo, assetInfoErr := os.Lstat(filepath.Join(repositoryPath, filepath.FromSlash(runtimePath)))
	switch {
	case os.IsNotExist(assetInfoErr):
		reasons = append(reasons, "runtime environment asset is missing: "+runtimePath)
	case assetInfoErr != nil:
		return nil, fmt.Errorf("inspect runtime environment asset %s: %w", runtimePath, assetInfoErr)
	case !assetInfo.Mode().IsRegular() || assetInfo.Mode()&os.ModeSymlink != 0:
		reasons = append(reasons, "runtime environment asset is not a regular non-symlink file: "+runtimePath)
	case assetInfo.Mode().Perm() != 0o600:
		reasons = append(reasons, fmt.Sprintf("runtime environment asset must have mode 0600: %s", runtimePath))
	}

	tracked, trackedErr := gitPathExistsAtCommit(
		ctx,
		repositoryPath,
		headCommit,
		runtimePath,
	)
	if trackedErr != nil {
		return nil, trackedErr
	}
	if tracked {
		reasons = append(reasons, "runtime environment asset must not be tracked: "+runtimePath)
	}
	ignored, ignoredErr := gitPathIsIgnored(ctx, repositoryPath, runtimePath)
	if ignoredErr != nil {
		return nil, ignoredErr
	}
	if !ignored {
		reasons = append(reasons, "runtime environment asset must be ignored: "+runtimePath)
	}

	examplePath, examplePathValid := canonicalManifestPath(runtimeAsset["example_path"])
	if !examplePathValid {
		return reasons, nil
	}
	exampleReasons, exampleErr := inspectCommittedWorkingFile(
		ctx,
		repositoryPath,
		headCommit,
		examplePath,
		"runtime environment example",
		0o644,
	)
	if exampleErr != nil {
		return nil, exampleErr
	}
	return append(reasons, exampleReasons...), nil
}

func inspectCommittedWorkingFile(
	ctx context.Context,
	repositoryPath string,
	headCommit string,
	relativePath string,
	label string,
	requiredMode os.FileMode,
) ([]string, error) {
	workingPath := filepath.Join(repositoryPath, filepath.FromSlash(relativePath))
	workingInfo, workingInfoErr := os.Lstat(workingPath)
	if workingInfoErr != nil {
		if os.IsNotExist(workingInfoErr) {
			return []string{fmt.Sprintf("%s is missing: %s", label, relativePath)}, nil
		}
		return nil, fmt.Errorf("inspect %s %s: %w", label, relativePath, workingInfoErr)
	}
	if !workingInfo.Mode().IsRegular() || workingInfo.Mode()&os.ModeSymlink != 0 {
		return []string{fmt.Sprintf("%s must be a non-symlink regular file: %s", label, relativePath)}, nil
	}
	reasons := make([]string, 0, 2)
	if requiredMode != 0 && workingInfo.Mode().Perm() != requiredMode {
		reasons = append(reasons, fmt.Sprintf("%s must have mode %04o: %s", label, requiredMode, relativePath))
	}
	headBytes, headErr := runGitBytes(
		ctx,
		repositoryPath,
		"show",
		headCommit+":"+relativePath,
	)
	if headErr != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return append(reasons, fmt.Sprintf("%s is not committed at HEAD: %s", label, relativePath)), nil
	}
	workingBytes, workingErr := os.ReadFile(workingPath)
	if workingErr != nil {
		return nil, fmt.Errorf("read %s %s: %w", label, relativePath, workingErr)
	}
	if !bytes.Equal(headBytes, workingBytes) {
		reasons = append(reasons, fmt.Sprintf("%s differs from HEAD: %s", label, relativePath))
	}
	return reasons, nil
}

func gitPathExistsAtCommit(
	ctx context.Context,
	repositoryPath string,
	headCommit string,
	relativePath string,
) (bool, error) {
	_, showErr := runGitBytes(
		ctx,
		repositoryPath,
		"show",
		headCommit+":"+relativePath,
	)
	if showErr == nil {
		return true, nil
	}
	if ctx.Err() != nil {
		return false, ctx.Err()
	}
	return false, nil
}

func gitPathIsIgnored(ctx context.Context, repositoryPath string, relativePath string) (bool, error) {
	command := exec.CommandContext(ctx, "git", "-C", repositoryPath, "check-ignore", "-q", "--", relativePath)
	commandErr := command.Run()
	if commandErr == nil {
		return true, nil
	}
	if ctx.Err() != nil {
		return false, ctx.Err()
	}
	var exitErr *exec.ExitError
	if errors.As(commandErr, &exitErr) {
		return false, nil
	}
	return false, fmt.Errorf("check ignored deployment path %s: %w", relativePath, commandErr)
}

func canonicalManifestPath(value any) (string, bool) {
	relativePath, isString := value.(string)
	if !isString || relativePath == "" || relativePath != strings.TrimSpace(relativePath) {
		return "", false
	}
	if strings.Contains(relativePath, `\`) || filepath.IsAbs(relativePath) {
		return "", false
	}
	cleanPath := filepath.ToSlash(filepath.Clean(filepath.FromSlash(relativePath)))
	if cleanPath != relativePath || cleanPath == "." || strings.HasPrefix(cleanPath, "../") {
		return "", false
	}
	return relativePath, true
}

func isEnvironmentPath(relativePath string) bool {
	baseName := filepath.Base(filepath.FromSlash(relativePath))
	return strings.HasPrefix(baseName, ".env") || strings.Contains(baseName, ".env.")
}

func uniqueSortedStrings(values []string) []string {
	uniqueValues := make(map[string]struct{}, len(values))
	for _, value := range values {
		uniqueValues[value] = struct{}{}
	}
	sortedValues := make([]string, 0, len(uniqueValues))
	for value := range uniqueValues {
		sortedValues = append(sortedValues, value)
	}
	sort.Strings(sortedValues)
	return sortedValues
}

func exactRepositoryOrigin(ctx context.Context, repoPath string) (string, error) {
	originBytes, originErr := runGitBytes(ctx, repoPath, "remote", "get-url", "--all", "origin")
	if originErr != nil {
		if ctx.Err() != nil {
			return "", ctx.Err()
		}
		return "", nil
	}
	originOutput := string(originBytes)
	origin := strings.TrimSuffix(originOutput, "\n")
	if origin == "" || strings.ContainsAny(origin, "\r\n") || origin != strings.TrimSpace(origin) {
		return "", nil
	}
	return origin, nil
}

func fingerprintOrigin(origin string) string {
	if origin == "" {
		return ""
	}
	digest := sha256.Sum256([]byte(origin))
	return fmt.Sprintf("sha256:%x", digest)
}

func parseManifest(manifestPath string, manifestBytes []byte) (manifestDocument, error) {
	var manifest manifestDocument
	decoder := yaml.NewDecoder(bytes.NewReader(manifestBytes))
	decoder.KnownFields(true)
	if decodeErr := decoder.Decode(&manifest); decodeErr != nil {
		return manifestDocument{}, fmt.Errorf("parse app manifest %s: %w", manifestPath, decodeErr)
	}
	var trailingDocument any
	trailingErr := decoder.Decode(&trailingDocument)
	if trailingErr == nil {
		return manifestDocument{}, fmt.Errorf("app manifest %s must contain exactly one YAML document", manifestPath)
	}
	if !errors.Is(trailingErr, io.EOF) {
		return manifestDocument{}, fmt.Errorf("parse app manifest %s: %w", manifestPath, trailingErr)
	}
	if manifest.Resources.SchemaVersion != schemaVersionCurrent {
		return manifestDocument{}, fmt.Errorf("app manifest %s must use schema_version %d", manifestPath, schemaVersionCurrent)
	}
	repositoryID := manifest.Resources.Repo.ID
	repositoryDirectory := manifest.Resources.Repo.Directory
	dispatchTarget := manifest.Resources.Repo.DispatchTarget
	if repositoryID == "" || repositoryID != strings.TrimSpace(repositoryID) ||
		repositoryDirectory == "" || repositoryDirectory != strings.TrimSpace(repositoryDirectory) ||
		dispatchTarget == "" || dispatchTarget != strings.TrimSpace(dispatchTarget) {
		return manifestDocument{}, fmt.Errorf("app manifest %s must define repo.id, repo.directory, and repo.dispatch_target", manifestPath)
	}
	if !repositoryNamePattern.MatchString(repositoryID) || !repositoryNamePattern.MatchString(repositoryDirectory) {
		return manifestDocument{}, fmt.Errorf("app manifest %s repo.id and repo.directory must use canonical repository names", manifestPath)
	}
	if len(manifest.Resources.Items) == 0 {
		return manifestDocument{}, fmt.Errorf("app manifest %s must define a non-empty resources list", manifestPath)
	}
	if !dispatchTargetPattern.MatchString(dispatchTarget) {
		return manifestDocument{}, fmt.Errorf("app manifest %s repo.dispatch_target %q is invalid", manifestPath, dispatchTarget)
	}
	seenResources := make(map[string]struct{}, len(manifest.Resources.Items))
	for resourceIndex, resource := range manifest.Resources.Items {
		resourceType, typeFound := resource["type"].(string)
		resourceName, nameFound := resource["name"].(string)
		if !typeFound || resourceType == "" || resourceType != strings.TrimSpace(resourceType) || !resourceTypePattern.MatchString(resourceType) {
			return manifestDocument{}, fmt.Errorf("app manifest %s resource %d must define one canonical type", manifestPath, resourceIndex)
		}
		if !nameFound || resourceName == "" || resourceName != strings.TrimSpace(resourceName) || !repositoryNamePattern.MatchString(resourceName) {
			return manifestDocument{}, fmt.Errorf("app manifest %s resource %d must define one canonical name", manifestPath, resourceIndex)
		}
		resourceIdentity := resourceType + ":" + resourceName
		if _, duplicate := seenResources[resourceIdentity]; duplicate {
			return manifestDocument{}, fmt.Errorf("app manifest %s duplicates resource %s", manifestPath, resourceIdentity)
		}
		seenResources[resourceIdentity] = struct{}{}
	}
	return manifest, nil
}

func runGit(ctx context.Context, repoPath string, arguments ...string) (string, error) {
	outputBytes, commandErr := runGitBytes(ctx, repoPath, arguments...)
	return string(outputBytes), commandErr
}

func runGitBytes(ctx context.Context, repoPath string, arguments ...string) ([]byte, error) {
	commandArguments := append([]string{"-C", repoPath}, arguments...)
	command := exec.CommandContext(ctx, "git", commandArguments...)
	outputBytes, commandErr := command.Output()
	if commandErr != nil {
		return nil, commandErr
	}
	return outputBytes, nil
}

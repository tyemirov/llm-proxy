#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF' >&2
Usage:
  scripts/caddy-image-metadata.sh signature
  scripts/caddy-image-metadata.sh json
  scripts/caddy-image-metadata.sh remote-signature IMAGE
  scripts/caddy-image-metadata.sh remote-has-amd64 IMAGE
EOF
}

repo_root=$(
  cd "$(dirname "${BASH_SOURCE[0]}")/.." >/dev/null 2>&1
  pwd
)
cd "$repo_root"

platforms=${CADDY_IMAGE_PLATFORMS:-linux/amd64}

compute_local_metadata() {
  dockerfile_sha256=$(
    shasum -a 256 Dockerfile.caddy | awk '{print $1}'
  )
  builder_digest=$(
    docker buildx imagetools inspect caddy:2-builder --format '{{json .Manifest}}' | jq -r '.digest'
  )
  runtime_digest=$(
    docker buildx imagetools inspect caddy:2-alpine --format '{{json .Manifest}}' | jq -r '.digest'
  )
  signature=$(
    printf '%s\n%s\n%s\n%s\n' "$dockerfile_sha256" "$builder_digest" "$runtime_digest" "$platforms" \
      | shasum -a 256 | awk '{print $1}'
  )
}

remote_image_json() {
  local image="$1"
  docker buildx imagetools inspect "$image" --format '{{json .Image}}' 2>/dev/null
}

case "${1:-}" in
  signature)
    compute_local_metadata
    printf '%s\n' "$signature"
    ;;
  json)
    compute_local_metadata
    jq -n \
      --arg signature "$signature" \
      --arg dockerfile_sha256 "$dockerfile_sha256" \
      --arg builder_digest "$builder_digest" \
      --arg runtime_digest "$runtime_digest" \
      --arg platforms "$platforms" \
      '{
        signature: $signature,
        dockerfile_sha256: $dockerfile_sha256,
        builder_digest: $builder_digest,
        runtime_digest: $runtime_digest,
        platforms: $platforms
      }'
    ;;
  remote-signature)
    if [ "$#" -ne 2 ]; then
      usage
      exit 1
    fi
    if remote_json=$(remote_image_json "$2"); then
      printf '%s' "$remote_json" | jq -r '
        if type == "object" and (.config? | type == "object") then
          .config.Labels["io.mprlab.caddy-build-signature"] // ""
        else
          .["linux/amd64"].config.Labels["io.mprlab.caddy-build-signature"] // ""
        end
      '
    else
      printf '\n'
    fi
    ;;
  remote-has-amd64)
    if [ "$#" -ne 2 ]; then
      usage
      exit 1
    fi
    if remote_json=$(remote_image_json "$2"); then
      printf '%s' "$remote_json" | jq -r '
        if type == "object" and (.config? | type == "object") then
          (.os == "linux" and .architecture == "amd64")
        else
          has("linux/amd64")
        end
      '
    else
      printf 'false\n'
    fi
    ;;
  *)
    usage
    exit 1
    ;;
esac

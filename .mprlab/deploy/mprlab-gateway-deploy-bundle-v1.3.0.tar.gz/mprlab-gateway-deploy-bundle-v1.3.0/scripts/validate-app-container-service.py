#!/usr/bin/env python3
"""Validate one app-declared container against gateway Compose and inventory."""

from __future__ import annotations

import json
import os
import re
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

import yaml


ALLOWED_RESOURCE_KEYS = {
    "type",
    "name",
    "host_group",
    "image",
    "image_variable",
    "ports",
    "compose_file",
    "compose_project",
    "gpu",
    "external_volumes",
    "runtime_assets",
    "readiness_event",
}
ALLOWED_RUNTIME_ASSET_KEYS = {"path", "destination", "mode", "example_path"}
ALLOWED_PORT_KEYS = {
    "container_port",
    "host_port",
    "host_port_variable",
    "protocol",
}
HOST_GROUP_CONTRACTS = {
    "gateway": ("gateway.yml", "mprlab_gateway_target_profiles"),
    "computercat": ("computercat.yml", "mprlab_computercat_target_profiles"),
}
IMAGE_VARIABLE_PATTERN = re.compile(r"^\$\{([A-Z][A-Z0-9_]*)[:?+\-].*\}$")
INVENTORY_LIST_REFERENCE_PATTERN = re.compile(
    r"^\{\{ ([a-z][a-z0-9_]*) \}\}$"
)
FILE_MODE_PATTERN = re.compile(r"^0[0-7]{3}$")
TLS_LISTENER_PORTS = frozenset({443, 465, 587, 8443})
DOTENV_ASSIGNMENT_PATTERN = re.compile(
    r"^(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*\s*="
)
READINESS_EVENT_PATTERN = re.compile(
    r"^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)*\.ready$"
)


class ContainerContractError(ValueError):
    """The app declaration or gateway implementation violates the contract."""


@dataclass(frozen=True)
class RuntimeAsset:
    path: str
    destination: str | None
    mode: str | None
    example_path: str | None

    @classmethod
    def from_raw(cls, raw: Any) -> RuntimeAsset:
        if not isinstance(raw, dict):
            raise ContainerContractError("runtime_assets entries must be objects")
        unknown_keys = sorted(set(raw) - ALLOWED_RUNTIME_ASSET_KEYS)
        if unknown_keys:
            raise ContainerContractError(
                f"runtime asset has unknown keys: {','.join(unknown_keys)}"
            )
        path = require_nonempty_string(raw.get("path"), "runtime asset path")
        pure_path = PurePosixPath(path)
        if pure_path.is_absolute() or ".." in pure_path.parts or pure_path.as_posix() != path:
            raise ContainerContractError(
                "runtime asset path must be one canonical app-relative path"
            )
        mode_raw = raw.get("mode")
        mode = None
        if mode_raw is not None:
            mode = require_nonempty_string(mode_raw, "runtime asset mode")
            if FILE_MODE_PATTERN.fullmatch(mode) is None:
                raise ContainerContractError(
                    "runtime asset mode must be a four-digit octal string"
                )
        environment_path = is_environment_path(pure_path)
        if environment_path and mode != "0600":
            raise ContainerContractError(
                f"runtime environment asset {path} must declare mode 0600"
            )
        example_path_raw = raw.get("example_path")
        example_path = None
        if environment_path:
            example_path = require_canonical_relative_path(
                example_path_raw, "runtime environment example_path"
            )
        elif example_path_raw is not None:
            raise ContainerContractError(
                "non-environment runtime assets must not declare example_path"
            )
        destination_raw = raw.get("destination")
        destination = None
        if destination_raw is not None:
            destination = require_canonical_relative_path(
                destination_raw, "runtime asset destination"
            )
        return cls(
            path=path,
            destination=destination,
            mode=mode,
            example_path=example_path,
        )


@dataclass(frozen=True)
class InventoryRuntimeAsset:
    source: str
    destination: str | None
    mode: str | None
    controller_source: str
    validation_source: str | None


@dataclass(frozen=True)
class PortExpectation:
    container_port: int
    host_port: int | None
    host_port_variable: str | None
    protocol: str

    @classmethod
    def from_raw(cls, raw: Any) -> PortExpectation:
        if not isinstance(raw, dict):
            raise ContainerContractError("ports entries must be objects")
        unknown_keys = sorted(set(raw) - ALLOWED_PORT_KEYS)
        if unknown_keys:
            raise ContainerContractError(
                f"port declaration has unknown keys: {','.join(unknown_keys)}"
            )
        container_port = require_port(raw.get("container_port"), "container_port")
        host_port = optional_port(raw.get("host_port"), "host_port")
        if container_port in TLS_LISTENER_PORTS:
            raise ContainerContractError(
                f"app container_port must not own Caddy TLS listener port {container_port}"
            )
        if host_port in TLS_LISTENER_PORTS:
            raise ContainerContractError(
                f"app host_port must not own Caddy TLS listener port {host_port}"
            )
        host_port_variable = optional_nonempty_string(
            raw.get("host_port_variable"), "host_port_variable"
        )
        if host_port_variable is not None and re.fullmatch(
            r"[A-Z][A-Z0-9_]*", host_port_variable
        ) is None:
            raise ContainerContractError(
                "host_port_variable must be a canonical env key"
            )
        if host_port_variable is not None and host_port is None:
            raise ContainerContractError(
                "host_port_variable requires an exact host_port"
            )
        protocol = raw.get("protocol", "tcp")
        if protocol not in {"tcp", "udp"}:
            raise ContainerContractError("port protocol must be tcp or udp")
        return cls(
            container_port=container_port,
            host_port=host_port,
            host_port_variable=host_port_variable,
            protocol=protocol,
        )


@dataclass(frozen=True)
class RepositoryContext:
    directory: str
    dispatch_target: str
    repo_path: Path

    @classmethod
    def from_raw(cls, raw: Any) -> RepositoryContext:
        if not isinstance(raw, dict):
            raise ContainerContractError("repository context must be an object")
        required_keys = {"directory", "dispatch_target", "repo_path"}
        if set(raw) != required_keys:
            raise ContainerContractError(
                "repository context must define directory, dispatch_target, and repo_path"
            )
        directory = require_nonempty_string(raw["directory"], "repository directory")
        dispatch_target = require_nonempty_string(
            raw["dispatch_target"], "repository dispatch_target"
        )
        repo_path = Path(require_nonempty_string(raw["repo_path"], "repository path"))
        if not repo_path.is_absolute() or repo_path.resolve() != repo_path:
            raise ContainerContractError("repository path must be canonical and absolute")
        if not repo_path.is_dir() or repo_path.name != directory:
            raise ContainerContractError(
                "repository path must identify the declared canonical directory"
            )
        return cls(
            directory=directory,
            dispatch_target=dispatch_target,
            repo_path=repo_path,
        )


@dataclass(frozen=True)
class ContainerExpectation:
    name: str
    host_group: str
    image: str | None
    image_variable: str | None
    ports: tuple[PortExpectation, ...]
    compose_file: str
    compose_project: str
    gpu: bool
    external_volumes: tuple[str, ...]
    runtime_assets: tuple[RuntimeAsset, ...]
    readiness_event: str | None

    @classmethod
    def from_raw(cls, raw: Any) -> ContainerExpectation:
        if not isinstance(raw, dict):
            raise ContainerContractError("container service declaration must be an object")
        unknown_keys = sorted(set(raw) - ALLOWED_RESOURCE_KEYS)
        if unknown_keys:
            raise ContainerContractError(
                f"container service declaration has unknown keys: {','.join(unknown_keys)}"
            )
        if raw.get("type") != "container_service":
            raise ContainerContractError(
                "container service declaration type must be container_service"
            )
        name = require_nonempty_string(raw.get("name"), "container service name")
        host_group = require_nonempty_string(raw.get("host_group"), "host_group")
        if host_group not in HOST_GROUP_CONTRACTS:
            raise ContainerContractError(
                f"host_group must be one of {','.join(sorted(HOST_GROUP_CONTRACTS))}"
            )
        image = optional_nonempty_string(raw.get("image"), "image")
        image_variable = optional_nonempty_string(
            raw.get("image_variable"), "image_variable"
        )
        if (image is None) == (image_variable is None):
            raise ContainerContractError(
                "container service must define exactly one of image or image_variable"
            )
        if image_variable is not None and re.fullmatch(
            r"[A-Z][A-Z0-9_]*", image_variable
        ) is None:
            raise ContainerContractError("image_variable must be a canonical env key")
        ports_raw = raw.get("ports")
        if not isinstance(ports_raw, list) or not ports_raw:
            raise ContainerContractError("ports must be one non-empty list")
        ports = tuple(PortExpectation.from_raw(port) for port in ports_raw)
        port_identities = [
            (port.container_port, port.protocol) for port in ports
        ]
        if len(port_identities) != len(set(port_identities)):
            raise ContainerContractError(
                "ports must not duplicate a container_port and protocol"
            )
        compose_file = require_canonical_relative_path(
            raw.get("compose_file"), "compose_file"
        )
        compose_project = require_nonempty_string(
            raw.get("compose_project"), "compose_project"
        )
        gpu = raw.get("gpu", False)
        if not isinstance(gpu, bool):
            raise ContainerContractError("gpu must be a boolean")
        external_volumes_raw = raw.get("external_volumes", [])
        if not isinstance(external_volumes_raw, list):
            raise ContainerContractError("external_volumes must be a list")
        external_volumes = tuple(
            require_docker_name(volume, "external volume")
            for volume in external_volumes_raw
        )
        if len(external_volumes) != len(set(external_volumes)):
            raise ContainerContractError(
                "external_volumes must not contain duplicate names"
            )
        runtime_assets_raw = raw.get("runtime_assets")
        if not isinstance(runtime_assets_raw, list):
            raise ContainerContractError("runtime_assets must be a list")
        runtime_assets = tuple(
            RuntimeAsset.from_raw(runtime_asset) for runtime_asset in runtime_assets_raw
        )
        runtime_paths = [runtime_asset.path for runtime_asset in runtime_assets]
        if len(runtime_paths) != len(set(runtime_paths)):
            raise ContainerContractError("runtime_assets must not contain duplicate paths")
        readiness_event = None
        if "readiness_event" in raw:
            readiness_event = require_nonempty_string(
                raw["readiness_event"], "readiness_event"
            )
        if (
            readiness_event is not None
            and READINESS_EVENT_PATTERN.fullmatch(readiness_event) is None
        ):
            raise ContainerContractError(
                "readiness_event must be a canonical event name ending in .ready"
            )
        return cls(
            name=name,
            host_group=host_group,
            image=image,
            image_variable=image_variable,
            ports=ports,
            compose_file=compose_file,
            compose_project=compose_project,
            gpu=gpu,
            external_volumes=external_volumes,
            runtime_assets=runtime_assets,
            readiness_event=readiness_event,
        )


def require_nonempty_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ContainerContractError(f"{field} must be one non-empty canonical string")
    return value


def optional_nonempty_string(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return require_nonempty_string(value, field)


def require_port(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 65535:
        raise ContainerContractError(f"{field} must be an integer from 1 through 65535")
    return value


def optional_port(value: Any, field: str) -> int | None:
    if value is None:
        return None
    return require_port(value, field)


def require_canonical_relative_path(value: Any, field: str) -> str:
    path = require_nonempty_string(value, field)
    pure_path = PurePosixPath(path)
    if pure_path.is_absolute() or ".." in pure_path.parts or pure_path.as_posix() != path:
        raise ContainerContractError(f"{field} must be one canonical relative path")
    return path


def require_docker_name(value: Any, field: str) -> str:
    name = require_nonempty_string(value, field)
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name) is None:
        raise ContainerContractError(f"{field} must be one canonical Docker name")
    return name


def is_environment_path(path: PurePosixPath) -> bool:
    return path.name.startswith(".env") or ".env." in path.name


def load_yaml_mapping(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise ContainerContractError(f"{label} is missing or is not a regular file: {path}")
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as error:
        raise ContainerContractError(f"cannot parse {label}: {path}") from error
    if not isinstance(payload, dict):
        raise ContainerContractError(f"{label} must contain one mapping: {path}")
    return payload


def string_list(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    values = value if isinstance(value, list) else [value]
    normalized: list[str] = []
    for entry in values:
        if isinstance(entry, dict) and field == "env_file":
            entry = entry.get("path")
        normalized.append(require_nonempty_string(entry, field))
    return tuple(normalized)


def compose_volume_sources(value: Any) -> tuple[str, ...]:
    sources: list[str] = []
    for mapping in string_list(value, "volumes"):
        source, separator, _ = mapping.partition(":")
        if separator and source:
            sources.append(source)
    return tuple(sources)


def parse_container_port(value: str, field: str) -> tuple[int, str]:
    port_text, separator, protocol = value.partition("/")
    resolved_protocol = protocol if separator else "tcp"
    if not port_text.isdigit() or resolved_protocol not in {"tcp", "udp"}:
        raise ContainerContractError(f"{field} must declare a numeric tcp or udp port")
    return require_port(int(port_text), field), resolved_protocol


def compose_container_ports(service: dict[str, Any]) -> set[tuple[int, str]]:
    ports: set[tuple[int, str]] = set()
    for exposed in string_list(service.get("expose"), "expose"):
        ports.add(parse_container_port(exposed, "Compose expose"))
    for mapping in string_list(service.get("ports"), "ports"):
        ports.add(parse_container_port(mapping.rsplit(":", 1)[-1], "Compose port target"))
    return ports


def compose_port_mappings(
    service: dict[str, Any], expectation: PortExpectation
) -> tuple[str, ...]:
    suffix = f":{expectation.container_port}"
    if expectation.protocol != "tcp":
        suffix += f"/{expectation.protocol}"
    return tuple(
        mapping
        for mapping in string_list(service.get("ports"), "ports")
        if mapping.endswith(suffix)
    )


def inventory_runtime_assets(
    inventory: dict[str, Any],
) -> dict[str, InventoryRuntimeAsset]:
    raw_assets = inventory.get("mprlab_runtime_assets")
    if not isinstance(raw_assets, list):
        raise ContainerContractError("inventory mprlab_runtime_assets must be a list")
    assets: dict[str, InventoryRuntimeAsset] = {}
    for raw_asset in raw_assets:
        if isinstance(raw_asset, str):
            source = raw_asset
            destination = None
            mode = None
            controller_source = "repository"
            validation_source = None
        elif isinstance(raw_asset, dict):
            unknown_keys = sorted(
                set(raw_asset)
                - {"src", "dest", "mode", "controller_source", "validation_src"}
            )
            if unknown_keys:
                raise ContainerContractError(
                    "inventory runtime asset has unknown keys: "
                    + ",".join(unknown_keys)
                )
            source = require_nonempty_string(raw_asset.get("src"), "inventory asset src")
            destination_raw = raw_asset.get("dest")
            destination = (
                require_canonical_relative_path(
                    destination_raw, "inventory asset destination"
                )
                if destination_raw is not None
                else None
            )
            mode_raw = raw_asset.get("mode")
            mode = str(mode_raw) if mode_raw is not None else None
            controller_source = raw_asset.get("controller_source", "repository")
            if controller_source not in {"repository", "remote"}:
                raise ContainerContractError(
                    "inventory runtime asset controller_source must be repository or remote"
                )
            validation_source_raw = raw_asset.get("validation_src")
            validation_source = (
                require_canonical_relative_path(
                    validation_source_raw, "inventory asset validation source"
                )
                if validation_source_raw is not None
                else None
            )
            if controller_source == "remote" and validation_source is None:
                raise ContainerContractError(
                    "remote inventory runtime assets must declare validation_src"
                )
            if controller_source == "repository" and validation_source is not None:
                raise ContainerContractError(
                    "repository inventory runtime assets must not declare validation_src"
                )
        else:
            raise ContainerContractError("inventory runtime assets must be strings or objects")
        if source in assets:
            raise ContainerContractError(f"inventory runtime asset is duplicated: {source}")
        assets[source] = InventoryRuntimeAsset(
            source=source,
            destination=destination,
            mode=mode,
            controller_source=controller_source,
            validation_source=validation_source,
        )
    return assets


def normalize_compose_source(value: str) -> str:
    source = value[2:] if value.startswith("./") else value
    pure_source = PurePosixPath(source)
    if pure_source.is_absolute() or pure_source.as_posix() != source:
        raise ContainerContractError(
            f"Compose runtime source must be one canonical relative path: {value}"
        )
    return source


def relative_controller_source(source_path: Path, gateway_root: Path) -> str:
    return PurePosixPath(os.path.relpath(source_path, gateway_root)).as_posix()


def run_git(repository_path: Path, *arguments: str) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        ["git", "-C", str(repository_path), *arguments],
        check=False,
        capture_output=True,
    )


def validate_runtime_asset_source(
    runtime_asset: RuntimeAsset,
    source_path: Path,
    repository: RepositoryContext,
) -> None:
    if not source_path.is_file() or source_path.is_symlink():
        raise ContainerContractError(
            f"runtime asset source is missing or not a regular file: {runtime_asset.path}"
        )
    tracked_result = run_git(
        repository.repo_path,
        "ls-files",
        "--error-unmatch",
        "--",
        runtime_asset.path,
    )
    environment_asset = is_environment_path(PurePosixPath(runtime_asset.path))
    if environment_asset:
        if tracked_result.returncode == 0:
            raise ContainerContractError(
                f"runtime environment asset must not be tracked: {runtime_asset.path}"
            )
        ignored_result = run_git(
            repository.repo_path, "check-ignore", "-q", "--", runtime_asset.path
        )
        if ignored_result.returncode != 0:
            raise ContainerContractError(
                f"runtime environment asset must be ignored: {runtime_asset.path}"
            )
        file_mode = stat.S_IMODE(source_path.stat().st_mode)
        if file_mode != 0o600:
            raise ContainerContractError(
                f"runtime environment asset must have mode 0600: {runtime_asset.path}"
            )
        validate_runtime_environment_example(runtime_asset, repository)
        return
    if tracked_result.returncode != 0:
        raise ContainerContractError(
            f"non-secret runtime asset must be tracked: {runtime_asset.path}"
        )
    status_result = run_git(
        repository.repo_path,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
        "--",
        runtime_asset.path,
    )
    if status_result.returncode != 0 or status_result.stdout.strip():
        raise ContainerContractError(
            f"tracked runtime asset must match HEAD: {runtime_asset.path}"
        )


def validate_runtime_environment_example(
    runtime_asset: RuntimeAsset,
    repository: RepositoryContext,
) -> None:
    if runtime_asset.example_path is None:
        raise ContainerContractError(
            f"runtime environment asset must declare example_path: {runtime_asset.path}"
        )
    example_path = repository.repo_path / runtime_asset.example_path
    if not example_path.is_file() or example_path.is_symlink():
        raise ContainerContractError(
            "runtime environment example is missing or not a regular file: "
            f"{runtime_asset.example_path}"
        )
    tracked_result = run_git(
        repository.repo_path,
        "ls-files",
        "--error-unmatch",
        "--",
        runtime_asset.example_path,
    )
    if tracked_result.returncode != 0:
        raise ContainerContractError(
            f"runtime environment example must be tracked: {runtime_asset.example_path}"
        )
    status_result = run_git(
        repository.repo_path,
        "status",
        "--porcelain=v1",
        "--untracked-files=all",
        "--",
        runtime_asset.example_path,
    )
    if status_result.returncode != 0 or status_result.stdout.strip():
        raise ContainerContractError(
            "runtime environment example must match HEAD: "
            f"{runtime_asset.example_path}"
        )
    if stat.S_IMODE(example_path.stat().st_mode) != 0o644:
        raise ContainerContractError(
            f"runtime environment example must have mode 0644: {runtime_asset.example_path}"
        )
    try:
        example_lines = example_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise ContainerContractError(
            f"runtime environment example must be UTF-8 text: {runtime_asset.example_path}"
        ) from error
    if not any(
        DOTENV_ASSIGNMENT_PATTERN.match(line.strip()) for line in example_lines
    ):
        raise ContainerContractError(
            "runtime environment example must declare at least one variable: "
            f"{runtime_asset.example_path}"
        )


def validate_image(expectation: ContainerExpectation, service: dict[str, Any]) -> None:
    compose_image = require_nonempty_string(service.get("image"), "Compose image")
    if expectation.image is not None:
        if compose_image != expectation.image:
            raise ContainerContractError("Compose image does not match app declaration")
        return
    image_match = IMAGE_VARIABLE_PATTERN.fullmatch(compose_image)
    if image_match is None or image_match.group(1) != expectation.image_variable:
        raise ContainerContractError(
            "Compose image variable does not match app declaration"
        )


def validate_runtime_assets(
    expectation: ContainerExpectation,
    repository: RepositoryContext,
    service: dict[str, Any],
    inventory: dict[str, Any],
    target_profile: dict[str, Any],
    gateway_root: Path,
) -> None:
    expected_sources: set[str] = set()
    inventory_assets = inventory_runtime_assets(inventory)
    target_asset_paths = set(
        string_list(target_profile.get("runtime_asset_paths"), "runtime_asset_paths")
    )
    compose_inputs = {
        normalize_compose_source(compose_input)
        for compose_input in string_list(service.get("env_file"), "env_file")
    }
    compose_inputs.update(
        normalize_compose_source(compose_input)
        for compose_input in compose_volume_sources(service.get("volumes"))
    )
    for runtime_asset in expectation.runtime_assets:
        source_path = repository.repo_path / runtime_asset.path
        validate_runtime_asset_source(runtime_asset, source_path, repository)
        gateway_source = relative_controller_source(source_path, gateway_root)
        compose_source = runtime_asset.destination or gateway_source
        expected_sources.add(gateway_source)
        if compose_source not in compose_inputs:
            raise ContainerContractError(
                f"Compose does not consume declared runtime asset destination {compose_source}"
            )
        if gateway_source not in inventory_assets:
            raise ContainerContractError(
                f"inventory does not transport declared runtime asset {gateway_source}"
            )
        inventory_asset = inventory_assets[gateway_source]
        if inventory_asset.destination != runtime_asset.destination:
            raise ContainerContractError(
                f"inventory destination does not match runtime asset {gateway_source}"
            )
        if inventory_asset.mode != runtime_asset.mode:
            raise ContainerContractError(
                f"inventory mode does not match runtime asset {gateway_source}"
            )
        if inventory_asset.controller_source != "repository":
            raise ContainerContractError(
                f"app-owned runtime asset must use repository controller source {gateway_source}"
            )
        if gateway_source not in target_asset_paths:
            raise ContainerContractError(
                f"target profile does not select runtime asset {gateway_source}"
            )

    consumed_app_sources = {
        source
        for source, inventory_asset in inventory_assets.items()
        if source.startswith(
            relative_controller_source(repository.repo_path, gateway_root) + "/"
        )
        and (inventory_asset.destination or source) in compose_inputs
    }
    if consumed_app_sources != expected_sources:
        raise ContainerContractError(
            "Compose app-owned runtime inputs do not match runtime_assets"
        )


def validate_gpu(expectation: ContainerExpectation, service: dict[str, Any]) -> None:
    compose_gpu = service.get("gpus") not in (None, False, [], "")
    if compose_gpu != expectation.gpu:
        raise ContainerContractError(
            "Compose GPU contract does not match app declaration"
        )


def validate_external_volumes(
    expectation: ContainerExpectation,
    service: dict[str, Any],
    compose: dict[str, Any],
    target_profile: dict[str, Any],
) -> None:
    compose_volumes = compose.get("volumes", {})
    if not isinstance(compose_volumes, dict):
        raise ContainerContractError("Compose volumes must be a mapping")
    consumed_external_volumes: set[str] = set()
    for source in compose_volume_sources(service.get("volumes")):
        definition = compose_volumes.get(source)
        if not isinstance(definition, dict) or definition.get("external") is not True:
            continue
        volume_name = definition.get("name", source)
        consumed_external_volumes.add(
            require_docker_name(volume_name, "Compose external volume name")
        )
    if consumed_external_volumes != set(expectation.external_volumes):
        raise ContainerContractError(
            "Compose external volumes do not match app declaration"
        )
    target_external_volumes = set(
        string_list(target_profile.get("external_volumes"), "external_volumes")
    )
    undeployed_volumes = set(expectation.external_volumes) - target_external_volumes
    if undeployed_volumes:
        raise ContainerContractError(
            "target profile does not provision declared external volumes: "
            + ",".join(sorted(undeployed_volumes))
        )


def environment_file_value(path: Path, variable: str) -> str | None:
    if not path.is_file() or path.is_symlink():
        return None
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise ContainerContractError(f"cannot read Compose environment file: {path}") from error
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.removeprefix("export ").strip() != variable:
            continue
        normalized_value = value.strip()
        if (
            len(normalized_value) >= 2
            and normalized_value[0] == normalized_value[-1]
            and normalized_value[0] in {'"', "'"}
        ):
            normalized_value = normalized_value[1:-1]
        return normalized_value
    return None


def resolve_compose_variable(
    variable: str, inventory: dict[str, Any], gateway_root: Path
) -> str:
    compose_cli_env = inventory.get("mprlab_compose_cli_env", {})
    if not isinstance(compose_cli_env, dict):
        raise ContainerContractError("inventory mprlab_compose_cli_env must be a mapping")
    if variable in compose_cli_env:
        return require_nonempty_string(
            str(compose_cli_env[variable]), f"Compose variable {variable}"
        )
    for environment_path in string_list(
        inventory.get("mprlab_compose_env_files"), "mprlab_compose_env_files"
    ):
        resolved_value = environment_file_value(gateway_root / environment_path, variable)
        if resolved_value is not None:
            return resolved_value
    raise ContainerContractError(f"Compose host port variable is unresolved: {variable}")


def resolve_inventory_list(
    value: Any, inventory: dict[str, Any], field: str
) -> list[Any]:
    if isinstance(value, list):
        return value
    if not isinstance(value, str):
        raise ContainerContractError(
            f"{field} must be a list or one exact inventory list reference"
        )
    reference_match = INVENTORY_LIST_REFERENCE_PATTERN.fullmatch(value)
    if reference_match is None:
        raise ContainerContractError(
            f"{field} must be a list or one exact inventory list reference"
        )
    reference_name = reference_match.group(1)
    referenced_value = inventory.get(reference_name)
    if not isinstance(referenced_value, list):
        raise ContainerContractError(
            f"{field} references a missing or non-list inventory value: {reference_name}"
        )
    return referenced_value


def resolve_verify_host_ports(
    target_profile: dict[str, Any], inventory: dict[str, Any]
) -> set[int]:
    values = resolve_inventory_list(
        target_profile.get("verify_host_ports", []),
        inventory,
        "target profile verify_host_ports",
    )
    ports: list[int] = []
    for value in values:
        if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 65535:
            raise ContainerContractError(
                "target profile verify_host_ports must contain only integer ports from 1 through 65535"
            )
        ports.append(value)
    if len(ports) != len(set(ports)):
        raise ContainerContractError(
            "target profile verify_host_ports must not contain duplicate ports"
        )
    return set(ports)


def validate_ports(
    expectations: tuple[PortExpectation, ...],
    service: dict[str, Any],
    target_profile: dict[str, Any],
    inventory: dict[str, Any],
    gateway_root: Path,
) -> None:
    declared_ports = {
        (expectation.container_port, expectation.protocol)
        for expectation in expectations
    }
    if compose_container_ports(service) != declared_ports:
        raise ContainerContractError(
            "Compose service ports do not match app declaration"
        )
    verify_ports = resolve_verify_host_ports(target_profile, inventory)
    for expectation in expectations:
        mappings = compose_port_mappings(service, expectation)
        if expectation.host_port is None:
            if mappings:
                raise ContainerContractError(
                    "Compose publishes an app-declared internal port"
                )
            continue
        if len(mappings) != 1:
            raise ContainerContractError(
                "Compose must publish each declared host port exactly once"
            )
        mapping = mappings[0]
        if expectation.host_port_variable is not None:
            if f"${{{expectation.host_port_variable}" not in mapping:
                raise ContainerContractError(
                    "Compose port does not use declared host_port_variable"
                )
            resolved_host_port = resolve_compose_variable(
                expectation.host_port_variable, inventory, gateway_root
            )
            if resolved_host_port != str(expectation.host_port):
                raise ContainerContractError(
                    "Compose host port variable does not match declared host_port"
                )
        elif re.search(
            rf"(?:^|:){expectation.host_port}:{expectation.container_port}(?:/{expectation.protocol})?$",
            mapping,
        ) is None:
            raise ContainerContractError(
                "Compose port does not use declared host_port"
            )
        if expectation.host_port not in verify_ports:
            raise ContainerContractError(
                "target profile does not verify declared host_port"
            )


def validate_contract(
    expectation: ContainerExpectation,
    repository: RepositoryContext,
    gateway_root: Path,
) -> None:
    if not gateway_root.is_absolute() or gateway_root.resolve() != gateway_root:
        raise ContainerContractError("gateway root must be canonical and absolute")
    inventory_filename, profile_key = HOST_GROUP_CONTRACTS[expectation.host_group]
    inventory_path = (
        gateway_root
        / "deploy"
        / "ansible"
        / "inventory"
        / "group_vars"
        / inventory_filename
    )
    inventory = load_yaml_mapping(inventory_path, "gateway inventory")
    compose_files = set(string_list(inventory.get("mprlab_compose_files"), "compose files"))
    if expectation.compose_file not in compose_files:
        raise ContainerContractError(
            "compose_file is not selected by the declared host inventory"
        )
    inventory_project = require_nonempty_string(
        inventory.get("mprlab_compose_project_name"), "inventory Compose project"
    )
    if expectation.compose_project != inventory_project:
        raise ContainerContractError(
            "compose_project does not match the declared host inventory"
        )
    compose = load_yaml_mapping(gateway_root / expectation.compose_file, "Compose file")
    services = compose.get("services")
    if not isinstance(services, dict) or expectation.name not in services:
        raise ContainerContractError(
            f"Compose service is missing for app declaration: {expectation.name}"
        )
    service = services[expectation.name]
    if not isinstance(service, dict):
        raise ContainerContractError("Compose service must be a mapping")
    validate_image(expectation, service)

    profiles = inventory.get(profile_key)
    if not isinstance(profiles, dict):
        raise ContainerContractError(f"inventory {profile_key} must be a mapping")
    target_profile = profiles.get(repository.dispatch_target)
    if not isinstance(target_profile, dict):
        raise ContainerContractError(
            f"inventory target profile is missing: {repository.dispatch_target}"
        )
    profile_services = set(string_list(target_profile.get("services"), "profile services"))
    if expectation.name not in profile_services:
        raise ContainerContractError(
            f"target profile does not select Compose service {expectation.name}"
        )
    compose_profiles = set(string_list(service.get("profiles"), "Compose profiles"))
    target_compose_profiles = set(
        string_list(target_profile.get("compose_profiles"), "target Compose profiles")
    )
    if compose_profiles != target_compose_profiles:
        raise ContainerContractError(
            "Compose service profiles do not match target profile compose_profiles"
        )
    validate_runtime_assets(
        expectation,
        repository,
        service,
        inventory,
        target_profile,
        gateway_root,
    )
    validate_gpu(expectation, service)
    validate_external_volumes(expectation, service, compose, target_profile)
    validate_ports(expectation.ports, service, target_profile, inventory, gateway_root)


def main(arguments: list[str]) -> int:
    if len(arguments) != 3:
        raise ContainerContractError(
            "usage: validate-app-container-service.py RESOURCE_JSON REPOSITORY_JSON GATEWAY_ROOT"
        )
    try:
        resource_raw = json.loads(arguments[0])
        repository_raw = json.loads(arguments[1])
    except json.JSONDecodeError as error:
        raise ContainerContractError("resource and repository inputs must be JSON") from error
    expectation = ContainerExpectation.from_raw(resource_raw)
    repository = RepositoryContext.from_raw(repository_raw)
    validate_contract(expectation, repository, Path(arguments[2]))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except ContainerContractError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1) from error

#!/usr/bin/env bash
set -euo pipefail

usage() {
  printf '%s\n' 'usage: validate-llm-proxy-timeout-contract.sh <caddy-globals-path> <proxy-max-seconds>' >&2
}

if [[ $# -ne 2 ]]; then
  usage
  exit 2
fi

caddy_globals_path="$1"
proxy_max_seconds="$2"

if [[ ! -f "${caddy_globals_path}" || -L "${caddy_globals_path}" ]]; then
  printf 'error: Caddy globals must be a regular, non-symlink file: %s\n' "${caddy_globals_path}" >&2
  exit 1
fi
if [[ ! "${proxy_max_seconds}" =~ ^[1-9][0-9]*$ ]]; then
  printf 'error: proxy maximum must be a positive whole number of seconds (got: %s)\n' "${proxy_max_seconds}" >&2
  exit 1
fi

parsed_values="$(
  awk '
    function record(field, value) {
      counts[field]++
      values[field] = value
    }

    {
      line = $0
      sub(/[[:space:]]*#.*/, "", line)

      if (depth == 0 && line ~ /^[[:space:]]*\{[[:space:]]*$/) {
        global_options_depth = depth + 1
      }
      if (global_options_depth > 0 &&
        depth == global_options_depth &&
        line ~ /^[[:space:]]*servers[[:space:]]*\{[[:space:]]*$/) {
        default_servers_depth = depth + 1
      }
      if (default_servers_depth > 0 &&
        depth == default_servers_depth &&
        line ~ /^[[:space:]]*timeouts[[:space:]]*\{[[:space:]]*$/) {
        server_timeouts_depth = depth + 1
      }
      if (depth == 0 &&
        line ~ /^[[:space:]]*\(llm_proxy_transport\)[[:space:]]*\{[[:space:]]*$/) {
        llm_proxy_snippet_depth = depth + 1
      }
      if (llm_proxy_snippet_depth > 0 &&
        depth == llm_proxy_snippet_depth &&
        line ~ /^[[:space:]]*transport[[:space:]]+http[[:space:]]*\{[[:space:]]*$/) {
        llm_proxy_transport_depth = depth + 1
      }

      field_count = split(line, fields, /[[:space:]]+/)
      first = ""
      second = ""
      for (idx = 1; idx <= field_count; idx++) {
        if (fields[idx] == "") {
          continue
        }
        if (first == "") {
          first = fields[idx]
        } else if (second == "") {
          second = fields[idx]
        }
      }

      if (server_timeouts_depth > 0 && depth == server_timeouts_depth && first == "write") {
        record("server_write", second)
      }
      if (llm_proxy_transport_depth > 0 &&
        depth == llm_proxy_transport_depth &&
        first == "response_header_timeout") {
        record("response_header_timeout", second)
      }
      if (llm_proxy_transport_depth > 0 &&
        depth == llm_proxy_transport_depth &&
        first == "read_timeout") {
        record("read_timeout", second)
      }

      brace_line = line
      opening_braces = gsub(/\{/, "{", brace_line)
      brace_line = line
      closing_braces = gsub(/\}/, "}", brace_line)
      depth += opening_braces - closing_braces
      if (depth < 0) {
        printf "error: Caddy globals contain an unmatched closing brace\n" > "/dev/stderr"
        exit 1
      }

      if (server_timeouts_depth > 0 && depth < server_timeouts_depth) {
        server_timeouts_depth = 0
      }
      if (default_servers_depth > 0 && depth < default_servers_depth) {
        default_servers_depth = 0
      }
      if (global_options_depth > 0 && depth < global_options_depth) {
        global_options_depth = 0
      }
      if (llm_proxy_transport_depth > 0 && depth < llm_proxy_transport_depth) {
        llm_proxy_transport_depth = 0
      }
      if (llm_proxy_snippet_depth > 0 && depth < llm_proxy_snippet_depth) {
        llm_proxy_snippet_depth = 0
      }
    }

    END {
      if (depth != 0) {
        printf "error: Caddy globals contain unbalanced braces\n" > "/dev/stderr"
        failed = 1
      }
      required[1] = "server_write"
      required[2] = "response_header_timeout"
      required[3] = "read_timeout"
      for (idx = 1; idx <= 3; idx++) {
        field = required[idx]
        if (counts[field] != 1) {
          printf "error: expected exactly one %s timeout, found %d\n", field, counts[field] > "/dev/stderr"
          failed = 1
        }
      }
      if (failed) {
        exit 1
      }
      for (idx = 1; idx <= 3; idx++) {
        field = required[idx]
        printf "%s=%s\n", field, values[field]
      }
    }
  ' "${caddy_globals_path}"
)"

while IFS='=' read -r timeout_name timeout_value; do
  if [[ ! "${timeout_value}" =~ ^[1-9][0-9]*s$ ]]; then
    printf 'error: %s must use canonical positive integer seconds (got: %s)\n' "${timeout_name}" "${timeout_value}" >&2
    exit 1
  fi
  timeout_seconds="${timeout_value%s}"
  if (( timeout_seconds <= proxy_max_seconds )); then
    printf 'error: %s (%ss) must be strictly greater than proxy maximum (%ss)\n' \
      "${timeout_name}" "${timeout_seconds}" "${proxy_max_seconds}" >&2
    exit 1
  fi
done <<<"${parsed_values}"

printf 'llm-proxy gateway timeout contract OK: proxy_max=%ss\n' "${proxy_max_seconds}"

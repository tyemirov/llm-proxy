#!/usr/bin/env python3

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile


ATTESTATION_NAME = "BUNDLE-ATTESTATION.json"
MANIFEST_NAME = "BUNDLE-MANIFEST.txt"
VERSION_NAME = "VERSION"
SCHEMA_VERSION = 1
RELEASE_VERSION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
SOURCE_COMMIT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
CONFIG_PATHS = (
    "configs/.env.sample",
    "configs/computercat.env.sample",
    "configs/config.tauth.base.yml",
    "configs/tauth.env.sample",
)
ROOT_PATHS = (
    "deploy/ansible/ansible.cfg",
    "deploy/ansible/requirements.yml",
    "deploy/ansible/app-controller-closure.txt",
    "deploy/ansible/playbooks",
    "deploy/ansible/templates",
    "deploy/ansible/inventory/group_vars",
    "Caddyfile",
    "caddy",
    "docker-compose.yml",
    "docker-compose.computercat.yml",
    "Dockerfile.caddy",
    "bin/mprlab-gateway-deploy-app",
    "bin/mprlab-gateway-deploy-target",
    "scripts/caddy-image-metadata.sh",
    "scripts/deploy-bundle-artifact.py",
    "scripts/observe-container-readiness-event.py",
    "scripts/render-local-compose.py",
    "scripts/validate-llm-proxy-timeout-contract.sh",
    "scripts/validate-app-caddy-route.py",
    "scripts/validate-app-container-service.py",
    "scripts/validate-app-health-check.py",
    "scripts/with-app-controller-identity",
    "scripts/with-app-resource-snapshot.sh",
    "cmd/deployfailure",
    "cmd/deployrecap",
    "cmd/appresources",
    "cmd/configaudit",
    "cmd/llmproxycapacity",
    "cmd/tauthconfig",
    "cmd/tauthtargetconfig",
    "internal/appresources",
    "internal/configaudit",
    "internal/llmproxycontract",
    "internal/tauthconfig",
    "internal/deployrecap",
    "go.mod",
    "go.sum",
)
REQUIRED_PATHS = (
    VERSION_NAME,
    MANIFEST_NAME,
    ATTESTATION_NAME,
    "deploy/ansible/ansible.cfg",
    "deploy/ansible/requirements.yml",
    "deploy/ansible/app-controller-closure.txt",
    "deploy/ansible/playbooks/preflight.yml",
    "deploy/ansible/playbooks/snapshot-tauth-config.yml",
    "deploy/ansible/playbooks/plan-resources.yml",
    "deploy/ansible/playbooks/deploy.yml",
    "deploy/ansible/playbooks/verify.yml",
    "deploy/ansible/playbooks/validate-app-resources.yml",
    "deploy/ansible/playbooks/dispatch-app-resources.yml",
    "deploy/ansible/playbooks/tasks/deploy-github-pages-make-target.yml",
    "deploy/ansible/playbooks/tasks/load-app-pages-resources.yml",
    "deploy/ansible/playbooks/tasks/load-app-verification-resources.yml",
    "deploy/ansible/playbooks/tasks/load-app-ansible-resources.yml",
    "deploy/ansible/playbooks/tasks/select-app-resource-manifests.yml",
    "deploy/ansible/playbooks/tasks/validate-app-ansible-task-bundle.yml",
    "deploy/ansible/playbooks/tasks/dispatch-app-ansible-task-bundles.yml",
    "deploy/ansible/inventory/group_vars/all.yml",
    "deploy/ansible/inventory/group_vars/gateway.yml",
    "deploy/ansible/inventory/group_vars/computercat.yml",
    "deploy/ansible/templates/compose.env.j2",
    "Caddyfile",
    "caddy/globals.caddy",
    "docker-compose.yml",
    "docker-compose.computercat.yml",
    *CONFIG_PATHS,
    "bin/mprlab-gateway-deploy-app",
    "bin/mprlab-gateway-deploy-target",
    "scripts/caddy-image-metadata.sh",
    "scripts/validate-llm-proxy-timeout-contract.sh",
    "scripts/deploy-bundle-artifact.py",
    "scripts/observe-container-readiness-event.py",
    "scripts/render-local-compose.py",
    "scripts/validate-app-caddy-route.py",
    "scripts/validate-app-container-service.py",
    "scripts/validate-app-health-check.py",
    "scripts/with-app-controller-identity",
    "scripts/with-app-resource-snapshot.sh",
    "cmd/deployfailure/main.go",
    "cmd/deployrecap/main.go",
    "cmd/appresources/main.go",
    "cmd/configaudit/main.go",
    "cmd/llmproxycapacity/main.go",
    "cmd/tauthconfig/main.go",
    "cmd/tauthtargetconfig/main.go",
    "internal/appresources/discovery.go",
    "internal/llmproxycontract/contract.go",
    "internal/tauthconfig/tauthconfig.go",
    "go.mod",
    "go.sum",
)
FORBIDDEN_PATHS = (
    "deploy/ansible/inventory/hosts.yml",
    "configs/.proxies.txt",
    "configs/proxies.txt",
    "configs/adc.json",
    "deploy/ansible/playbooks/tasks/deploy-github-pages-workflow.yml",
    "deploy/ansible/playbooks/tasks/resolve-github-pages-workflow-ref.yml",
    ".git",
)


class ArtifactError(ValueError):
    pass


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode(
        "utf-8"
    )


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def run_git(repo_root: Path, *arguments: str, input_bytes: bytes | None = None) -> bytes:
    result = subprocess.run(
        ["git", "-C", str(repo_root), *arguments],
        input=input_bytes,
        check=False,
        capture_output=True,
    )
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", errors="replace").strip()
        raise ArtifactError(f"git {' '.join(arguments)} failed: {detail}")
    return result.stdout


def validate_identity(release_version: str, source_commit: str) -> None:
    if RELEASE_VERSION_PATTERN.fullmatch(release_version) is None:
        raise ArtifactError(f"invalid release version: {release_version}")
    if SOURCE_COMMIT_PATTERN.fullmatch(source_commit) is None:
        raise ArtifactError(f"invalid source commit: {source_commit}")


def selected_path(path: str) -> bool:
    if path in CONFIG_PATHS:
        return True
    if path.startswith("configs/"):
        return False
    return any(path == root or path.startswith(f"{root}/") for root in ROOT_PATHS)


def canonical_relative_path(raw_path: str) -> str:
    path = PurePosixPath(raw_path)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ArtifactError(f"non-canonical bundle path: {raw_path}")
    normalized = path.as_posix()
    if normalized != raw_path or raw_path.startswith("./"):
        raise ArtifactError(f"non-canonical bundle path: {raw_path}")
    return normalized


def working_tree_files(repo_root: Path) -> dict[str, tuple[bytes, int]]:
    selected: dict[str, tuple[bytes, int]] = {}
    candidates: list[Path] = []
    for raw_root in ROOT_PATHS:
        source = repo_root / raw_root
        if source.is_symlink():
            raise ArtifactError(f"bundle source must not be a symlink: {raw_root}")
        if source.is_file():
            candidates.append(source)
        elif source.is_dir():
            candidates.extend(path for path in sorted(source.rglob("*")) if path.is_file())
        else:
            raise ArtifactError(f"bundle source missing: {raw_root}")
    config_root = repo_root / "configs"
    candidates.extend(
        path
        for path in sorted(config_root.iterdir())
        if path.is_file() and selected_path(path.relative_to(repo_root).as_posix())
    )
    for path in candidates:
        if path.is_symlink():
            raise ArtifactError(
                f"bundle source must not be a symlink: {path.relative_to(repo_root)}"
            )
        relative = canonical_relative_path(path.relative_to(repo_root).as_posix())
        if not selected_path(relative):
            continue
        mode = stat.S_IMODE(path.stat().st_mode)
        selected[relative] = (path.read_bytes(), mode)
    return selected


def committed_files(repo_root: Path, source_commit: str) -> dict[str, tuple[bytes, int]]:
    run_git(repo_root, "cat-file", "-e", f"{source_commit}^{{commit}}")
    tree = run_git(repo_root, "ls-tree", "-r", "-z", source_commit)
    selected: dict[str, tuple[bytes, int]] = {}
    for raw_entry in tree.split(b"\0"):
        if not raw_entry:
            continue
        metadata, raw_path = raw_entry.split(b"\t", 1)
        raw_mode, object_type, object_id = metadata.decode("ascii").split(" ")
        path = canonical_relative_path(raw_path.decode("utf-8"))
        if object_type != "blob" or not selected_path(path):
            continue
        if raw_mode == "120000":
            raise ArtifactError(f"bundle source must not be a symlink: {path}")
        mode = 0o755 if raw_mode == "100755" else 0o644
        selected[path] = (
            run_git(repo_root, "cat-file", "blob", object_id),
            mode,
        )
    for root in ROOT_PATHS:
        if not any(path == root or path.startswith(f"{root}/") for path in selected):
            raise ArtifactError(f"committed bundle source missing: {root}")
    return selected


def file_entry(path: str, payload: bytes, mode: int) -> dict[str, object]:
    return {
        "path": path,
        "mode": mode,
        "size": len(payload),
        "sha256": sha256(payload),
    }


def content_digest(entries: list[dict[str, object]]) -> str:
    return sha256(canonical_json(entries))


def tar_info(path: str, mode: int, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(path)
    info.mode = mode
    info.size = size
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    return info


def write_archive(archive_path: Path, root_name: str, files: dict[str, tuple[bytes, int]]) -> None:
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = archive_path.with_name(f".{archive_path.name}.{os.getpid()}.tmp")
    with temporary.open("wb") as output:
        with gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for relative, (payload, mode) in sorted(files.items()):
                    archive.addfile(
                        tar_info(f"{root_name}/{relative}", mode, len(payload)),
                        io.BytesIO(payload),
                    )
    os.replace(temporary, archive_path)


def build(args: argparse.Namespace) -> None:
    repo_root = args.repo_root.resolve(strict=True)
    validate_identity(args.release_version, args.source_commit)
    run_git(repo_root, "cat-file", "-e", f"{args.source_commit}^{{commit}}")
    source_mode = os.environ.get("DEPLOY_BUNDLE_SOURCE_MODE", "0")
    if source_mode not in {"0", "1"}:
        raise ArtifactError("DEPLOY_BUNDLE_SOURCE_MODE must be 0 or 1")
    if source_mode == "1":
        files = working_tree_files(repo_root)
        source_kind = "working-tree"
    else:
        files = committed_files(repo_root, args.source_commit)
        source_kind = "commit"

    files[VERSION_NAME] = (f"{args.release_version}\n".encode("utf-8"), 0o644)
    manifest_payload = ("\n".join(sorted(files)) + "\n").encode("utf-8")
    files[MANIFEST_NAME] = (manifest_payload, 0o644)
    entries = [
        file_entry(path, payload, mode)
        for path, (payload, mode) in sorted(files.items())
    ]
    attestation = {
        "schemaVersion": SCHEMA_VERSION,
        "releaseVersion": args.release_version,
        "sourceCommit": args.source_commit,
        "sourceKind": source_kind,
        "contentDigest": content_digest(entries),
        "files": entries,
    }
    files[ATTESTATION_NAME] = (canonical_json(attestation), 0o644)
    root_name = f"mprlab-gateway-deploy-bundle-{args.release_version}"
    write_archive(args.archive.resolve(), root_name, files)
    print(args.archive)


def read_archive(archive_path: Path) -> tuple[str, dict[str, tuple[bytes, int]]]:
    if not archive_path.is_file():
        raise ArtifactError(f"deploy bundle archive not found: {archive_path}")
    files: dict[str, tuple[bytes, int]] = {}
    root_name = ""
    with tarfile.open(archive_path, mode="r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts or len(path.parts) < 2:
                raise ArtifactError(f"non-canonical archive member: {member.name}")
            if not root_name:
                root_name = path.parts[0]
            if path.parts[0] != root_name:
                raise ArtifactError("deploy bundle must contain exactly one top-level directory")
            if not member.isfile():
                raise ArtifactError(f"deploy bundle member must be a regular file: {member.name}")
            relative = canonical_relative_path(PurePosixPath(*path.parts[1:]).as_posix())
            if relative in files:
                raise ArtifactError(f"duplicate deploy bundle path: {relative}")
            stream = archive.extractfile(member)
            if stream is None:
                raise ArtifactError(f"cannot read deploy bundle member: {member.name}")
            files[relative] = (stream.read(), stat.S_IMODE(member.mode))
    if not root_name:
        raise ArtifactError("deploy bundle is empty")
    return root_name, files


def require_paths(files: dict[str, tuple[bytes, int]]) -> None:
    for required in REQUIRED_PATHS:
        if required not in files:
            raise ArtifactError(f"deploy bundle missing {required}")
    for forbidden in FORBIDDEN_PATHS:
        if forbidden in files or any(path.startswith(f"{forbidden}/") for path in files):
            raise ArtifactError(f"deploy bundle includes forbidden path {forbidden}")
    for path in files:
        if path.startswith("configs/.env") and path != "configs/.env.sample":
            raise ArtifactError(f"deploy bundle includes local env file {path}")
        if path.startswith("configs/") and (
            path.endswith(".json") or PurePosixPath(path).name in {".proxies.txt", "proxies.txt"}
        ):
            raise ArtifactError(f"deploy bundle includes local credential material {path}")


def parse_attestation(payload: bytes) -> dict[str, object]:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ArtifactError("deploy bundle attestation is invalid JSON") from error
    if not isinstance(value, dict):
        raise ArtifactError("deploy bundle attestation must be an object")
    return value


def verify(args: argparse.Namespace) -> None:
    validate_identity(args.release_version, args.source_commit)
    root_name, files = read_archive(args.archive.resolve(strict=True))
    expected_root_name = f"mprlab-gateway-deploy-bundle-{args.release_version}"
    if root_name != expected_root_name:
        raise ArtifactError(
            "deploy bundle top-level directory does not match release identity"
        )
    require_paths(files)
    attestation = parse_attestation(files[ATTESTATION_NAME][0])
    if attestation.get("schemaVersion") != SCHEMA_VERSION:
        raise ArtifactError(f"deploy bundle must use attestation schema {SCHEMA_VERSION}")
    if attestation.get("releaseVersion") != args.release_version:
        raise ArtifactError("deploy bundle release version does not match expected identity")
    if attestation.get("sourceCommit") != args.source_commit:
        raise ArtifactError("deploy bundle source commit does not match expected identity")
    source_kind = attestation.get("sourceKind")
    if source_kind not in {"commit", "working-tree"}:
        raise ArtifactError("deploy bundle source kind is not canonical")
    if args.require_committed_source and source_kind != "commit":
        raise ArtifactError("deploy bundle release artifact must come from committed source")
    raw_entries = attestation.get("files")
    if not isinstance(raw_entries, list):
        raise ArtifactError("deploy bundle attestation files must be a list")
    expected_entries = [
        file_entry(path, payload, mode)
        for path, (payload, mode) in sorted(files.items())
        if path != ATTESTATION_NAME
    ]
    if raw_entries != expected_entries:
        raise ArtifactError("deploy bundle content does not match its attestation")
    if attestation.get("contentDigest") != content_digest(expected_entries):
        raise ArtifactError("deploy bundle content digest does not match its attestation")
    manifest_paths = files[MANIFEST_NAME][0].decode("utf-8").splitlines()
    expected_manifest_paths = sorted(path for path in files if path not in {ATTESTATION_NAME, MANIFEST_NAME})
    if manifest_paths != expected_manifest_paths:
        raise ArtifactError("deploy bundle manifest does not match its content")
    version = files[VERSION_NAME][0].decode("utf-8")
    if version != f"{args.release_version}\n":
        raise ArtifactError("deploy bundle VERSION does not match expected identity")
    for executable in (
        "bin/mprlab-gateway-deploy-app",
        "bin/mprlab-gateway-deploy-target",
        "scripts/with-app-controller-identity",
    ):
        if files[executable][1] & 0o111 == 0:
            raise ArtifactError(f"deploy bundle executable bit is missing: {executable}")
    print(f"deploy bundle OK: {args.archive}")


def parser() -> argparse.ArgumentParser:
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parent.parent,
    )
    subparsers = argument_parser.add_subparsers(dest="command", required=True)
    build_parser = subparsers.add_parser("build")
    build_parser.add_argument("archive", type=Path)
    build_parser.add_argument("--release-version", required=True)
    build_parser.add_argument("--source-commit", required=True)
    build_parser.set_defaults(operation=build)
    verify_parser = subparsers.add_parser("verify")
    verify_parser.add_argument("archive", type=Path)
    verify_parser.add_argument("--release-version", required=True)
    verify_parser.add_argument("--source-commit", required=True)
    verify_parser.add_argument("--require-committed-source", action="store_true")
    verify_parser.set_defaults(operation=verify)
    return argument_parser


def main() -> int:
    arguments = parser().parse_args()
    try:
        arguments.operation(arguments)
    except (ArtifactError, OSError, UnicodeError) as error:
        print(f"error: {error}", file=os.sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

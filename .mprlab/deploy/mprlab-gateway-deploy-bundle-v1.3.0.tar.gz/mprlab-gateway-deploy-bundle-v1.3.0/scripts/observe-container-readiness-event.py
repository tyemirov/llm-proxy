#!/usr/bin/env python3
"""Observe one canonical readiness event from the current container start."""

import json
import queue
import re
import subprocess
import sys
import threading
from typing import Any, Pattern, Sequence, Tuple


EVENT_PATTERN = re.compile(r"^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)*\.ready$")
CONTAINER_ID_PATTERN = re.compile(r"^[0-9a-f]{12,64}$")


class ReadinessError(RuntimeError):
    """The container terminated or changed before becoming ready."""


def inspect_state(docker_cli: str, container_id: str) -> Tuple[bool, str]:
    result = subprocess.run(
        [
            docker_cli,
            "inspect",
            "--format",
            "{{json .State}}",
            container_id,
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise ReadinessError(f"cannot inspect container {container_id}: {detail}")
    try:
        state = json.loads(result.stdout)
    except json.JSONDecodeError as error:
        raise ReadinessError(
            f"container {container_id} returned invalid state JSON"
        ) from error
    if not isinstance(state, dict):
        raise ReadinessError(f"container {container_id} state must be an object")
    running = state.get("Running")
    started_at = state.get("StartedAt")
    if not isinstance(running, bool) or not isinstance(started_at, str) or not started_at:
        raise ReadinessError(
            f"container {container_id} state must include Running and StartedAt"
        )
    return running, started_at


def event_line_pattern(event_name: str) -> Pattern[str]:
    return re.compile(r"(?:^|\s)event=" + re.escape(event_name) + r"(?:\s|$)")


def observe_logs(
    process: Any, event_name: str, observations: Any
) -> None:
    expected_event = event_line_pattern(event_name)
    assert process.stdout is not None
    for line in process.stdout:
        if expected_event.search(line):
            observations.put(("ready", line.rstrip()))
            return
    return_code = process.wait()
    observations.put(("logs_closed", f"docker logs exited with status {return_code}"))


def observe_exit(process: Any, observations: Any) -> None:
    stdout, stderr = process.communicate()
    if process.returncode != 0:
        detail = stderr.strip() or stdout.strip()
        observations.put(
            ("wait_failed", f"docker wait exited with status {process.returncode}: {detail}")
        )
        return
    observations.put(("container_exit", stdout.strip()))


def stop_process(process: Any) -> None:
    if process.poll() is None:
        process.kill()
    process.wait()


def observe(docker_cli: str, container_id: str, event_name: str) -> None:
    running, started_at = inspect_state(docker_cli, container_id)
    if not running:
        raise ReadinessError(f"container {container_id} is not running")

    logs_process = subprocess.Popen(
        [
            docker_cli,
            "logs",
            "--follow",
            "--since",
            started_at,
            container_id,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    wait_process = subprocess.Popen(
        [docker_cli, "wait", container_id],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    observations = queue.Queue()
    threading.Thread(
        target=observe_logs,
        args=(logs_process, event_name, observations),
        daemon=True,
    ).start()
    threading.Thread(
        target=observe_exit,
        args=(wait_process, observations),
        daemon=True,
    ).start()

    try:
        observation, detail = observations.get()
        if observation != "ready":
            raise ReadinessError(
                f"container {container_id} ended before event {event_name}: {detail}"
            )
        current_running, current_started_at = inspect_state(docker_cli, container_id)
        if not current_running or current_started_at != started_at:
            raise ReadinessError(
                f"container {container_id} changed start after event {event_name}"
            )
        print(f"container={container_id} event={event_name} state=ready")
    finally:
        stop_process(logs_process)
        stop_process(wait_process)


def main(arguments: Sequence[str]) -> int:
    if len(arguments) != 3:
        raise ReadinessError(
            "usage: observe-container-readiness-event.py DOCKER_CLI CONTAINER_ID EVENT"
        )
    docker_cli, container_id, event_name = arguments
    if not docker_cli.startswith("/"):
        raise ReadinessError("Docker CLI must be an absolute path")
    if CONTAINER_ID_PATTERN.fullmatch(container_id) is None:
        raise ReadinessError("container ID must be one canonical hexadecimal identifier")
    if EVENT_PATTERN.fullmatch(event_name) is None:
        raise ReadinessError("event must be one canonical readiness event name")
    observe(docker_cli, container_id, event_name)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except ReadinessError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)

#!/usr/bin/env python3
"""Validate one app-owned public health-check declaration."""

from __future__ import annotations

import json
import sys
from typing import Any
from urllib.parse import urlsplit


ALLOWED_KEYS = {"type", "name", "path", "url", "status_codes"}


class HealthCheckContractError(ValueError):
    """The app health-check declaration violates the canonical contract."""


def require_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise HealthCheckContractError(f"{field} must be one canonical string")
    return value


def validate(raw: Any) -> None:
    if not isinstance(raw, dict):
        raise HealthCheckContractError("health_check resource must be an object")
    unknown_keys = sorted(set(raw) - ALLOWED_KEYS)
    if unknown_keys:
        raise HealthCheckContractError(
            "health_check resource has unknown keys: " + ",".join(unknown_keys)
        )
    if raw.get("type") != "health_check":
        raise HealthCheckContractError("resource type must be health_check")
    require_string(raw.get("name"), "health_check name")
    path = require_string(raw.get("path"), "health_check path")
    if not path.startswith("/") or "?" in path or "#" in path or any(
        character.isspace() for character in path
    ):
        raise HealthCheckContractError(
            "health_check path must be one absolute HTTP path"
        )
    url = require_string(raw.get("url"), "health_check url")
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path != path
    ):
        raise HealthCheckContractError(
            "health_check url must be HTTPS and contain the declared path only"
        )
    status_codes_raw = raw.get("status_codes", [200])
    if not isinstance(status_codes_raw, list) or not status_codes_raw:
        raise HealthCheckContractError("status_codes must be one non-empty list")
    status_codes: list[int] = []
    for status_code in status_codes_raw:
        if (
            isinstance(status_code, bool)
            or not isinstance(status_code, int)
            or not 100 <= status_code <= 599
        ):
            raise HealthCheckContractError(
                "status_codes entries must be HTTP status integers"
            )
        status_codes.append(status_code)
    if len(status_codes) != len(set(status_codes)):
        raise HealthCheckContractError("status_codes must not contain duplicates")


def main(arguments: list[str]) -> int:
    if len(arguments) != 1:
        raise HealthCheckContractError(
            "usage: validate-app-health-check.py RESOURCE_JSON"
        )
    try:
        raw = json.loads(arguments[0])
    except json.JSONDecodeError as error:
        raise HealthCheckContractError("health_check input must be JSON") from error
    validate(raw)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except HealthCheckContractError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1) from error

#!/usr/bin/env python3
"""Validate one app-declared public route against its gateway Caddy snippet."""

from __future__ import annotations

import json
import re
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit


HOST_PATTERN = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$")
SNIPPET_PATTERN = re.compile(r"^[A-Za-z0-9_.-]+[.]caddy$")
UPSTREAM_PATTERN = re.compile(
    r"^(?:(?:h2c|http|https)://)?[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?:([1-9][0-9]{0,4})$"
)
ALLOWED_ROUTE_KEYS = {
    "type",
    "name",
    "host",
    "upstream",
    "snippet",
}


class RouteContractError(ValueError):
    """The app expectation or gateway implementation violates the route contract."""


@dataclass(frozen=True)
class RouteExpectation:
    name: str
    hosts: tuple[str, ...]
    upstream: str
    snippet: str

    @classmethod
    def from_raw(cls, raw: Any) -> RouteExpectation:
        if not isinstance(raw, dict):
            raise RouteContractError("route declaration must be an object")
        unknown_keys = sorted(set(raw) - ALLOWED_ROUTE_KEYS)
        if unknown_keys:
            raise RouteContractError(
                f"route declaration has unknown keys: {','.join(unknown_keys)}"
            )
        if raw.get("type") != "caddy_route":
            raise RouteContractError("route declaration type must be caddy_route")

        name = require_nonempty_string(raw.get("name"), "name")
        hosts = (require_host(raw.get("host"), "host"),)

        upstream = require_nonempty_string(raw.get("upstream"), "upstream")
        if upstream != upstream.lower():
            raise RouteContractError("upstream must use canonical lowercase names")
        upstream_match = UPSTREAM_PATTERN.fullmatch(upstream)
        if upstream_match is None or int(upstream_match.group(1)) > 65535:
            raise RouteContractError(
                "upstream must be host:port or h2c|http|https://host:port with port 1 through 65535"
            )

        snippet = require_nonempty_string(raw.get("snippet"), "snippet")
        if SNIPPET_PATTERN.fullmatch(snippet) is None:
            raise RouteContractError("snippet must be one canonical .caddy filename")

        return cls(
            name=name,
            hosts=hosts,
            upstream=upstream,
            snippet=snippet,
        )


@dataclass(frozen=True)
class CaddySiteBlock:
    hosts: frozenset[str]
    body: tuple[str, ...]

    def routes_to(self, upstream: str, proxy_imports: frozenset[str]) -> bool:
        for line in self.body:
            tokens = tokenize_directive(line)
            if not tokens:
                continue
            if tokens[0] == "reverse_proxy" and upstream in tokens[1:]:
                return True
            if (
                tokens[0] == "import"
                and len(tokens) > 2
                and tokens[1] in proxy_imports
                and upstream in tokens[2:]
            ):
                return True
        return False

def require_nonempty_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise RouteContractError(f"{field} must be one non-empty canonical string")
    return value


def require_host(value: Any, field: str) -> str:
    host = require_nonempty_string(value, field)
    if (
        HOST_PATTERN.fullmatch(host) is None
        or host != host.lower()
        or ".." in host
        or ".-" in host
        or "-." in host
    ):
        raise RouteContractError(f"{field} contains an invalid host: {host}")
    return host


def strip_comment(line: str) -> str:
    quoted = False
    escaped = False
    result: list[str] = []
    for character in line:
        if escaped:
            result.append(character)
            escaped = False
            continue
        if character == "\\" and quoted:
            result.append(character)
            escaped = True
            continue
        if character == '"':
            quoted = not quoted
            result.append(character)
            continue
        if character == "#" and not quoted:
            break
        result.append(character)
    return "".join(result).strip()


def tokenize_directive(line: str) -> tuple[str, ...]:
    clean_line = strip_comment(line)
    if not clean_line or clean_line in {"{", "}"}:
        return ()
    try:
        return tuple(shlex.split(clean_line, comments=False, posix=True))
    except ValueError as error:
        raise RouteContractError(f"invalid Caddy directive syntax: {line.strip()}") from error


def brace_delta(line: str) -> int:
    clean_line = strip_comment(line)
    return clean_line.count("{") - clean_line.count("}")


def normalize_site_address(address: str) -> str | None:
    candidate = address.strip().rstrip(",")
    if not candidate or candidate.startswith("(") or "*" in candidate:
        return None
    if "://" in candidate:
        hostname = urlsplit(candidate).hostname
        return hostname.lower() if hostname else None
    candidate = candidate.split("/", 1)[0]
    if candidate.startswith("["):
        return None
    if ":" in candidate:
        candidate = candidate.rsplit(":", 1)[0]
    return candidate.lower() if HOST_PATTERN.fullmatch(candidate) else None


def parse_blocks(text: str, *, named: bool) -> tuple[CaddySiteBlock, ...] | dict[str, tuple[str, ...]]:
    sites: list[CaddySiteBlock] = []
    named_blocks: dict[str, tuple[str, ...]] = {}
    header = ""
    body: list[str] = []
    depth = 0

    for original_line in text.splitlines():
        line = strip_comment(original_line)
        if depth == 0:
            if not line or "{" not in line:
                continue
            before_open, after_open = line.split("{", 1)
            if after_open.strip():
                raise RouteContractError("Caddy block opening lines must not contain directives")
            header = before_open.strip()
            body = []
            depth = brace_delta(line)
            if depth != 1:
                raise RouteContractError(f"invalid Caddy block header: {original_line.strip()}")
            continue

        next_depth = depth + brace_delta(line)
        if next_depth < 0:
            raise RouteContractError("Caddy snippet contains an unmatched closing brace")
        if next_depth == 0:
            if named:
                match = re.fullmatch(r"\(([A-Za-z0-9_.-]+)\)", header)
                if match:
                    named_blocks[match.group(1)] = tuple(body)
            else:
                addresses = re.split(r"[\s,]+", header)
                hosts = frozenset(
                    host
                    for address in addresses
                    if (host := normalize_site_address(address)) is not None
                )
                if hosts:
                    sites.append(CaddySiteBlock(hosts=hosts, body=tuple(body)))
            header = ""
            body = []
        else:
            body.append(original_line)
        depth = next_depth

    if depth != 0:
        raise RouteContractError("Caddy snippet contains an unterminated block")
    return named_blocks if named else tuple(sites)


def discover_proxy_imports(globals_path: Path) -> frozenset[str]:
    named_blocks = parse_blocks(globals_path.read_text(encoding="utf-8"), named=True)
    assert isinstance(named_blocks, dict)
    return frozenset(
        name
        for name, body in named_blocks.items()
        if any(
            (tokens := tokenize_directive(line))
            and tokens[0] == "reverse_proxy"
            and "{args[0]}" in tokens[1:]
            for line in body
        )
    )


def require_tracked_file(gateway_root: Path, relative_path: Path) -> Path:
    absolute_path = gateway_root / relative_path
    try:
        absolute_path.lstat()
    except FileNotFoundError as error:
        raise RouteContractError(
            f"requires tracked gateway snippet {relative_path.as_posix()}"
        ) from error
    if not absolute_path.is_file() or absolute_path.is_symlink():
        raise RouteContractError(
            f"requires a regular non-symlink gateway snippet {relative_path.as_posix()}"
        )
    git_metadata = gateway_root / ".git"
    bundle_manifest = gateway_root / "BUNDLE-MANIFEST.txt"
    if git_metadata.exists():
        tracked = subprocess.run(
            [
                "git",
                "-C",
                str(gateway_root),
                "ls-files",
                "--error-unmatch",
                "--",
                relative_path.as_posix(),
            ],
            check=False,
            capture_output=True,
            text=True,
        )
        if tracked.returncode != 0 or tracked.stdout.strip() != relative_path.as_posix():
            raise RouteContractError(
                f"requires tracked gateway snippet {relative_path.as_posix()}"
            )
    elif bundle_manifest.is_file() and not bundle_manifest.is_symlink():
        packaged_paths = frozenset(
            line.strip()
            for line in bundle_manifest.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
        if relative_path.as_posix() not in packaged_paths:
            raise RouteContractError(
                f"requires packaged gateway snippet {relative_path.as_posix()}"
            )
    else:
        raise RouteContractError(
            "gateway route validation requires Git tracked-file authority or BUNDLE-MANIFEST.txt"
        )
    return absolute_path


def validate_route(expectation: RouteExpectation, gateway_root: Path) -> None:
    relative_snippet = Path("caddy/sites") / expectation.snippet
    snippet_path = require_tracked_file(gateway_root, relative_snippet)
    globals_path = require_tracked_file(gateway_root, Path("caddy/globals.caddy"))
    proxy_imports = discover_proxy_imports(globals_path)
    parsed_sites = parse_blocks(snippet_path.read_text(encoding="utf-8"), named=False)
    assert isinstance(parsed_sites, tuple)

    for host in expectation.hosts:
        host_blocks = tuple(block for block in parsed_sites if host in block.hosts)
        if not host_blocks:
            raise RouteContractError(
                f"declared host {host} is not implemented by {relative_snippet.as_posix()}"
            )
        if not any(
            block.routes_to(expectation.upstream, proxy_imports) for block in host_blocks
        ):
            raise RouteContractError(
                f"declared host {host} does not route to declared upstream {expectation.upstream} "
                f"in {relative_snippet.as_posix()}"
            )

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate-app-caddy-route.py '<route-json>'", file=sys.stderr)
        return 2
    gateway_root = Path(__file__).resolve().parent.parent
    try:
        route = RouteExpectation.from_raw(json.loads(sys.argv[1]))
        validate_route(route, gateway_root)
    except (json.JSONDecodeError, RouteContractError) as error:
        print(f"caddy_route.invalid: {error}", file=sys.stderr)
        return 1
    print(f"caddy_route.valid: {route.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

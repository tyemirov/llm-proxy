#!/usr/bin/env python3

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from typing import Any


class ComposeRenderError(ValueError):
    pass


service_name_pattern = re.compile(r"^[a-z0-9][a-z0-9_.-]*$")


@dataclass(frozen=True)
class RuntimeAsset:
    source: str
    destination: str
    mode: int | None
    controller_source: str
    validation_source: str | None

    @classmethod
    def from_raw(cls, raw: Any) -> "RuntimeAsset":
        if not isinstance(raw, dict):
            raise ComposeRenderError("runtime assets must be objects")
        unknown_keys = sorted(
            set(raw) - {"src", "dest", "mode", "controller_source", "validation_src"}
        )
        if unknown_keys:
            raise ComposeRenderError(
                "runtime asset has unknown keys: " + ",".join(unknown_keys)
            )
        source = require_nonempty_string(raw.get("src"), "runtime asset src")
        destination = canonical_relative_path(
            raw.get("dest", source), "runtime asset destination"
        )
        raw_mode = raw.get("mode")
        mode = None if raw_mode is None else parse_mode(raw_mode)
        controller_source = raw.get("controller_source", "repository")
        if controller_source not in {"repository", "remote"}:
            raise ComposeRenderError(
                "runtime asset controller_source must be repository or remote"
            )
        raw_validation_source = raw.get("validation_src")
        validation_source = (
            None
            if raw_validation_source is None
            else canonical_relative_path(
                raw_validation_source, "runtime asset validation source"
            )
        )
        if controller_source == "remote" and validation_source is None:
            raise ComposeRenderError(
                "remote runtime assets must declare validation_src"
            )
        if controller_source == "repository" and validation_source is not None:
            raise ComposeRenderError(
                "repository runtime assets must not declare validation_src"
            )
        return cls(
            source=source,
            destination=destination,
            mode=mode,
            controller_source=controller_source,
            validation_source=validation_source,
        )


def require_nonempty_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ComposeRenderError(f"{field} must be one non-empty string")
    return value


def canonical_relative_path(value: Any, field: str) -> str:
    raw_path = require_nonempty_string(value, field)
    path = PurePosixPath(raw_path)
    if path.is_absolute() or ".." in path.parts or path.as_posix() != raw_path:
        raise ComposeRenderError(f"{field} must be one canonical relative path")
    return raw_path


def parse_mode(value: Any) -> int:
    mode = require_nonempty_string(str(value), "runtime asset mode")
    if len(mode) != 4 or mode[0] != "0" or any(character not in "01234567" for character in mode):
        raise ComposeRenderError("runtime asset mode must be a four-digit octal string")
    return int(mode, 8)


def load_json_list(raw: str, field: str) -> list[Any]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as error:
        raise ComposeRenderError(f"{field} must be valid JSON") from error
    if not isinstance(value, list):
        raise ComposeRenderError(f"{field} must be a JSON list")
    return value


def load_paths(raw: str, field: str) -> tuple[str, ...]:
    return tuple(canonical_relative_path(value, field) for value in load_json_list(raw, field))


def load_profiles(raw: str) -> tuple[str, ...]:
    profiles = tuple(
        require_nonempty_string(value, "Compose profile")
        for value in load_json_list(raw, "profiles")
    )
    if len(profiles) != len(set(profiles)):
        raise ComposeRenderError("Compose profiles must be unique")
    return profiles


def load_services(raw: str) -> tuple[str, ...]:
    services = tuple(
        require_nonempty_string(value, "Compose service")
        for value in load_json_list(raw, "services")
    )
    if len(services) != len(set(services)):
        raise ComposeRenderError("Compose services must be unique")
    invalid_services = tuple(
        service for service in services if service_name_pattern.fullmatch(service) is None
    )
    if invalid_services:
        raise ComposeRenderError(
            "Compose services must use canonical service names: "
            + ",".join(invalid_services)
        )
    return services


def load_assets(raw: str) -> tuple[RuntimeAsset, ...]:
    assets = tuple(
        RuntimeAsset.from_raw(value) for value in load_json_list(raw, "runtime assets")
    )
    destinations = [asset.destination for asset in assets]
    if len(destinations) != len(set(destinations)):
        raise ComposeRenderError("runtime asset destinations must be unique")
    return assets


def stage_assets(source_root: Path, staging_root: Path, assets: tuple[RuntimeAsset, ...]) -> set[str]:
    destinations: set[str] = set()
    for asset in assets:
        source_path = source_root / (asset.validation_source or asset.source)
        if not source_path.is_file() or source_path.is_symlink():
            raise ComposeRenderError(
                "runtime asset source is missing or is not a regular file: "
                f"{asset.validation_source or asset.source}"
            )
        destination_path = staging_root / asset.destination
        destination_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.copyfile(source_path, destination_path)
        source_mode = stat.S_IMODE(source_path.stat().st_mode)
        os.chmod(destination_path, asset.mode if asset.mode is not None else source_mode)
        destinations.add(asset.destination)
    return destinations


def require_selected(paths: tuple[str, ...], destinations: set[str], field: str) -> None:
    missing = sorted(set(paths) - destinations)
    if missing:
        raise ComposeRenderError(
            f"{field} are not selected runtime asset destinations: {','.join(missing)}"
        )


def render(arguments: argparse.Namespace) -> int:
    source_root = arguments.source_root.resolve(strict=True)
    if not source_root.is_dir():
        raise ComposeRenderError("source root must be a directory")
    assets = load_assets(arguments.runtime_assets)
    compose_files = load_paths(arguments.compose_files, "Compose files")
    env_files = load_paths(arguments.env_files, "Compose env files")
    profiles = load_profiles(arguments.profiles)
    services = load_services(arguments.services)

    with tempfile.TemporaryDirectory(prefix="mprlab-compose-") as temporary_directory:
        staging_root = Path(temporary_directory)
        destinations = stage_assets(source_root, staging_root, assets)
        require_selected(compose_files, destinations, "Compose files")
        require_selected(env_files, destinations, "Compose env files")
        audit_compose_files = compose_files
        command = [arguments.docker_cli, "compose"]
        for profile in profiles:
            command.extend(("--profile", profile))
        for env_file in env_files:
            command.extend(("--env-file", env_file))
        for compose_file in compose_files:
            command.extend(("-f", compose_file))
        if services:
            if arguments.configaudit_binary is None:
                raise ComposeRenderError(
                    "Compose service selection requires configaudit binary"
                )
            if len(compose_files) != 1:
                raise ComposeRenderError(
                    "Compose service selection requires exactly one Compose file"
                )
            selected_compose_path = staging_root / "selected-compose.yml"
            selection_command = [
                str(arguments.configaudit_binary),
                "--compose-file",
                compose_files[0],
                "--write-selected-compose",
                selected_compose_path.name,
            ]
            for service in services:
                selection_command.extend(("--service", service))
            selection_result = subprocess.run(
                selection_command,
                cwd=staging_root,
                check=False,
                stdout=subprocess.DEVNULL,
            )
            if selection_result.returncode != 0:
                return selection_result.returncode
            command = [arguments.docker_cli, "compose"]
            for profile in profiles:
                command.extend(("--profile", profile))
            for env_file in env_files:
                command.extend(("--env-file", env_file))
            command.extend(("-f", selected_compose_path.name))
            audit_compose_files = (selected_compose_path.name,)
        command.extend(("config", f"--{arguments.render}"))
        compose_result = subprocess.run(command, cwd=staging_root, check=False)
        if compose_result.returncode != 0 or arguments.configaudit_binary is None:
            return compose_result.returncode
        for compose_file in audit_compose_files:
            audit_command = [
                str(arguments.configaudit_binary),
                "--compose-file",
                compose_file,
            ]
            audit_result = subprocess.run(
                audit_command,
                cwd=staging_root,
                check=False,
                stdout=subprocess.DEVNULL,
            )
            if audit_result.returncode != 0:
                return audit_result.returncode
        return 0


def parse_arguments(arguments: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage selected runtime assets and render the deploy-time Compose model."
    )
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--runtime-assets", required=True)
    parser.add_argument("--compose-files", required=True)
    parser.add_argument("--env-files", required=True)
    parser.add_argument("--profiles", required=True)
    parser.add_argument("--services", required=True)
    parser.add_argument("--docker-cli", required=True)
    parser.add_argument("--configaudit-binary", type=Path)
    parser.add_argument(
        "--render", choices=("quiet", "images", "services"), default="quiet"
    )
    return parser.parse_args(arguments)


def main(arguments: list[str]) -> int:
    return render(parse_arguments(arguments))


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except ComposeRenderError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1) from error

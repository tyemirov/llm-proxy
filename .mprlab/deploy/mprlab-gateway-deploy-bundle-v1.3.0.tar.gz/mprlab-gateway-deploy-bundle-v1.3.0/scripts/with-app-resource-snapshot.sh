#!/usr/bin/env bash
set -euo pipefail

source_parent="${MPRLAB_APP_REPO_PARENT:?MPRLAB_APP_REPO_PARENT is required}"
dispatch_target="${MPRLAB_APP_DISPATCH_TARGET:?MPRLAB_APP_DISPATCH_TARGET is required}"
snapshot_python="${MPRLAB_APP_SNAPSHOT_PYTHON:?MPRLAB_APP_SNAPSHOT_PYTHON is required}"
gateway_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"

[[ "${dispatch_target}" =~ ^[a-z0-9][a-z0-9-]*$ ]] || {
  printf 'invalid MPRLAB_APP_DISPATCH_TARGET: %s\n' "${dispatch_target}" >&2
  exit 2
}
[[ $# -gt 0 ]] || {
  printf '%s\n' 'app resource snapshot requires a transaction command' >&2
  exit 2
}

source_parent="$(realpath "${source_parent}")"
[[ -d "${source_parent}" ]] || {
  printf 'invalid MPRLAB_APP_REPO_PARENT: %s\n' "${source_parent}" >&2
  exit 2
}
[[ -x "${snapshot_python}" ]] || {
  printf 'invalid MPRLAB_APP_SNAPSHOT_PYTHON: %s\n' "${snapshot_python}" >&2
  exit 2
}

selected_repository_output="$("${snapshot_python}" - "${source_parent}" "${dispatch_target}" <<'PY'
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import yaml

parent = Path(sys.argv[1]).resolve(strict=True)
target = sys.argv[2]
directory_pattern = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
dispatch_target_line_pattern = re.compile(
    rb"^    dispatch_target: ([a-z0-9][a-z0-9-]*)$"
)
matches: list[tuple[Path, str]] = []


def shallow_dispatch_targets(manifest_bytes: bytes) -> set[str]:
    targets: set[str] = set()
    inside_resources = False
    inside_repo = False
    for line in manifest_bytes.splitlines():
        if line == b"mprlab_resources:":
            inside_resources = True
            inside_repo = False
            continue
        if not inside_resources:
            continue
        if line and not line.startswith(b" "):
            inside_resources = False
            inside_repo = False
            continue
        if line == b"  repo:":
            inside_repo = True
            continue
        if (
            inside_repo
            and line.startswith(b"  ")
            and not line.startswith(b"    ")
            and line.strip()
        ):
            inside_repo = False
        if not inside_repo:
            continue
        target_match = dispatch_target_line_pattern.fullmatch(line)
        if target_match is not None:
            targets.add(target_match.group(1).decode("ascii"))
    return targets

for manifest in sorted(parent.glob("*/.mprlab/deploy/resources.yml")):
    repository = manifest.parents[2]
    if repository.name.startswith(".") or repository.parent != parent or not manifest.is_file():
        continue
    git_check = subprocess.run(
        ["git", "-C", str(repository), "rev-parse", "--is-inside-work-tree"],
        check=False,
        capture_output=True,
        text=True,
    )
    if git_check.returncode != 0 or git_check.stdout.strip() != "true":
        continue
    manifest_bytes = manifest.read_bytes()
    if target not in shallow_dispatch_targets(manifest_bytes):
        continue
    try:
        manifest_text = manifest_bytes.decode("utf-8")
        document = yaml.safe_load(manifest_text)
    except (UnicodeDecodeError, yaml.YAMLError) as error:
        raise SystemExit(
            f"invalid selected app resource manifest {manifest}: malformed YAML"
        ) from error
    try:
        repository_contract = document["mprlab_resources"]["repo"]
        declared_target = repository_contract["dispatch_target"]
        declared_directory = repository_contract["directory"]
    except (KeyError, TypeError) as error:
        raise SystemExit(
            f"invalid selected app resource manifest {manifest}: missing repo contract"
        ) from error
    if declared_target != target:
        continue
    if (
        not isinstance(declared_directory, str)
        or directory_pattern.fullmatch(declared_directory) is None
    ):
        raise SystemExit(
            f"invalid app resource manifest {manifest}: non-canonical repo.directory"
        )
    if declared_directory != repository.name:
        continue
    matches.append((repository, declared_directory))

if len(matches) != 1:
    raise SystemExit(
        f"dispatch target {target!r} must select exactly one canonical app repository; got {len(matches)}"
    )

print(matches[0][0])
print(matches[0][1])
PY
)"

selected_repository_count=0
source_repository=""
repository_directory=""
while IFS= read -r selected_repository_line; do
  selected_repository_count=$((selected_repository_count + 1))
  case "${selected_repository_count}" in
    1) source_repository="${selected_repository_line}" ;;
    2) repository_directory="${selected_repository_line}" ;;
  esac
done <<<"${selected_repository_output}"

[[ "${selected_repository_count}" -eq 2 && -n "${source_repository}" && -n "${repository_directory}" ]] || {
  printf '%s\n' 'app resource snapshot resolver returned an invalid repository identity' >&2
  exit 2
}
source_common_directory="$(git -C "${source_repository}" rev-parse --path-format=absolute --git-common-dir)"
source_common_directory="$(realpath "${source_common_directory}")"

requested_commit="${MPRLAB_APP_RESOURCE_COMMIT:-}"
if [[ -n "${requested_commit}" && ! "${requested_commit}" =~ ^[0-9a-f]{40}$ ]]; then
  printf 'invalid MPRLAB_APP_RESOURCE_COMMIT: %s\n' "${requested_commit}" >&2
  exit 2
fi
commit="$(git -C "${source_repository}" rev-parse --verify "${requested_commit:-HEAD}^{commit}")"
[[ "${commit}" =~ ^[0-9a-f]{40}$ ]] || {
  printf '%s\n' 'selected app resource commit is not one exact commit' >&2
  exit 2
}
if [[ -n "${requested_commit}" && "${commit}" != "${requested_commit}" ]]; then
  printf 'selected app resource commit resolved to %s, expected %s\n' "${commit}" "${requested_commit}" >&2
  exit 2
fi
resource_tree="$(git -C "${source_repository}" rev-parse --verify "${commit}^{tree}")"
[[ "${resource_tree}" =~ ^[0-9a-f]{40}$ ]] || {
  printf '%s\n' 'selected app resource tree is not one exact tree' >&2
  exit 2
}

task_timeout="$("${snapshot_python}" - "${source_repository}" "${commit}" "${dispatch_target}" "${repository_directory}" <<'PY'
from __future__ import annotations

import subprocess
import sys

import yaml


repository = sys.argv[1]
commit = sys.argv[2]
dispatch_target = sys.argv[3]
repository_directory = sys.argv[4]
manifest_result = subprocess.run(
    ["git", "-C", repository, "show", f"{commit}:.mprlab/deploy/resources.yml"],
    check=False,
    capture_output=True,
    text=True,
)
if manifest_result.returncode != 0:
    raise SystemExit("selected app commit does not contain .mprlab/deploy/resources.yml")
document = yaml.safe_load(manifest_result.stdout)
try:
    resource_document = document["mprlab_resources"]
    repository_contract = resource_document["repo"]
    resources = resource_document["resources"]
except (KeyError, TypeError) as error:
    raise SystemExit("selected app commit has an invalid resource manifest") from error
if not isinstance(repository_contract, dict):
    raise SystemExit("selected app commit has an invalid repo contract")
if repository_contract.get("dispatch_target") != dispatch_target:
    raise SystemExit("selected app commit resource manifest changed dispatch_target")
if repository_contract.get("directory") != repository_directory:
    raise SystemExit("selected app commit resource manifest changed repo.directory")
if not isinstance(resources, list):
    raise SystemExit("selected app commit resource manifest resources must be a list")
task_bundles = [
    resource
    for resource in resources
    if isinstance(resource, dict) and resource.get("type") == "ansible_task_bundle"
]
if len(task_bundles) != 1:
    raise SystemExit("selected app commit must define exactly one ansible_task_bundle")
timeout_seconds = task_bundles[0].get("timeout_seconds")
if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 86400:
    raise SystemExit("selected app commit ansible_task_bundle.timeout_seconds must be an integer from 1 through 86400")
print(timeout_seconds)
PY
)"
[[ "${task_timeout}" =~ ^[1-9][0-9]{0,4}$ ]] && ((task_timeout <= 86400)) || {
  printf '%s\n' 'selected app commit returned an invalid task-bundle timeout' >&2
  exit 2
}

controller_state_directory="${source_common_directory}/mprlab-app-controller-state/${dispatch_target}"
[[ -z "${MPRLAB_APP_TASK_BUNDLE_TIMEOUT_SECONDS+x}" ]] || {
  printf '%s\n' 'MPRLAB_APP_TASK_BUNDLE_TIMEOUT_SECONDS is manifest-owned and must not be set before snapshot selection' >&2
  exit 2
}
for internal_variable in \
  MPRLAB_APP_CONTROLLER_ACTIVE \
  MPRLAB_APP_CONTROLLER_ID \
  MPRLAB_APP_CONTROLLER_STATE_DIRECTORY \
  MPRLAB_APP_CONTROLLER_EXPECTED_COMMIT \
  MPRLAB_APP_CONTROLLER_EXPECTED_TREE \
  MPRLAB_APP_CONTROLLER_EXPECTED_REPOSITORY_DIRECTORY \
  MPRLAB_APP_CONTROLLER_EXPECTED_SOURCE_REPO_PATH \
  MPRLAB_APP_CONTROLLER_EXPECTED_GIT_COMMON_DIR \
  MPRLAB_APP_TRANSACTION_ID \
  MPRLAB_APP_FENCING_EPOCH; do
  [[ -z "${!internal_variable+x}" ]] || {
    printf 'internal app controller variable is forbidden before acquisition: %s\n' "${internal_variable}" >&2
    exit 2
  }
done

export MPRLAB_APP_RESOURCE_COMMIT="${commit}"
export MPRLAB_APP_TASK_BUNDLE_TIMEOUT_SECONDS="${task_timeout}"
export MPRLAB_APP_CONTROLLER_STATE_DIRECTORY="${controller_state_directory}"
export MPRLAB_APP_CONTROLLER_EXPECTED_COMMIT="${commit}"
export MPRLAB_APP_CONTROLLER_EXPECTED_TREE="${resource_tree}"
export MPRLAB_APP_CONTROLLER_EXPECTED_REPOSITORY_DIRECTORY="${repository_directory}"
export MPRLAB_APP_CONTROLLER_EXPECTED_SOURCE_REPO_PATH="${source_repository}"
export MPRLAB_APP_CONTROLLER_EXPECTED_GIT_COMMON_DIR="${source_common_directory}"
exec "${gateway_root}/scripts/with-app-controller-identity" \
  bin/mprlab-gateway-deploy-app
